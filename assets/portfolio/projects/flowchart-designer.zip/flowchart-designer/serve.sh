#!/bin/sh
python -m SimpleHTTPServer 9000
