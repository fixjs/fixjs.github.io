﻿dpf.locales = {
  'Activities': 'فعالیت ها',
  'States': 'وضعیت ها',
  'Roles': 'نقش ها',
  'Variables': 'متغیر ها',

  'eActivity': 'فعالیت',
  'eDecision': 'تصمیم گیری',
  'eDecisionActivity': 'فعالیت همراه با تصمیم',
  'eEnd': 'پایان',
  'eStart': 'آغاز',

  'Rotate CCW': 'گردش پادساعتگرد',
  'Rotate CW': 'گردش ساعتگرد',
  'Flip V': 'چرخش عمودی',
  'Flip H': 'چرخش افقی',
  'Lock': 'قفل کردن',
  'Undo': 'بازگشت',
  'Redo': 'انجام دوباره',
  'Mode:normal': 'وضعیت عادی',
  'Mode:conn-add': 'وضعیت مدیریت اتصال',

  'No items': 'هیچ فعالیتی تعریف نشده است'
};