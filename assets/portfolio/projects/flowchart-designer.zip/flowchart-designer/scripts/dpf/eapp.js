﻿/**
 * DouranPortal eApplicationDesigner
 *
 * @author    Mehran Hatami hatami@douran.com
 * @version   2.0
 * @url       http://www.douran.com
 *
 */

dpf.eapp = {
  isFrmOverLoaded: false,
  collapse: function () {
    $find('eAppSplitter').GetPanes()[0].collapse();
  },
  overKey: '__frmover__',
  OnDragOverFrame: function OnDragOverFrame() {
    var wfFrame = null;
    if (dpf[dpf.eapp.overKey] === undefined) {
      wfFrame = document.getElementById('wfFrame');
      frmover = dpf[dpf.eapp.overKey] = document.createElement('div');

      var rect = dpf.getRectangle(wfFrame);
      frmover.style.width = rect.width + 'px';
      frmover.style.height = rect.height + 'px';
      frmover.style.top = rect.top + 'px';
      frmover.style.left = rect.left + 'px';
      frmover.style.position = 'absolute';
      frmover.style.backgroundColor = 'transparent';

      document.body.appendChild(frmover);
    } else {
      frmover = dpf[dpf.eapp.overKey];
    }

    frmover.style.display = '';

    //var frm = document.createElement();
  },
  OnClientDragging: function OnClientDragging() {
    if (!dpf.eapp.isFrmOverLoaded) {
      dpf.eapp.isFrmOverLoaded = true;
      dpf.eapp.OnDragOverFrame();
    }
    window.status = 'OnClientDragging';
  },
  OnClientDropped: function OnClientDropped(paletteList, data) {
    var e = data.get_domEvent();
    if (dpf[dpf.eapp.overKey] !== undefined) {
      dpf[dpf.eapp.overKey].style.display = 'none';
    }
    var sourceItem = data.get_sourceItem();

    var palettePane = $find('p3');
    var leftX = palettePane.get_collapsed() ? ($find('p4').get_element().clientWidth + 4) : palettePane.get_element().clientWidth + 4;
    var topY = jQuery('#headerCell').height();

    dpf.eapp.add(sourceItem.get_value(), e.clientX - leftX, e.clientY - topY);
    dpf.eapp.isFrmOverLoaded = false;
  },
  cboeApplicationsSelectedIndexChanged: function (selectedNode, args) {
    var index = parseInt(selectedNode.get_value());
    if (index == -1) {
      var eAppTree = $find('eApplicationTree');
      if (eAppTree.get_nodes().get_count()) {
        eAppTree.get_nodes().clear();
      }
      return;
    }

    HomePage.GeteApplicationInfo(dpf.qs.MId, index, function (res) {
      window._res = res;

      var eAppTree = $find('eApplicationTree');
      if (eAppTree.get_nodes().get_count()) eAppTree.get_nodes().clear();
      dpf.telerik._createNodesFromData(eAppTree, res.value);
      dpf.eapp.createeApplicationFlow(eAppTree, res.value);
    });
  },
  treeToolbarOnClientButtonClicked: function () {
    alert('treeToolbarOnClientButtonClicked');
    _targs = arguments;
  },
  flowToolbarOnClientButtonClicked: function () {
    alert('flowToolbarOnClientButtonClicked');
    _ttargs = arguments;
  },
  flowToolbarOnClientLoad: function (eAppFlowToolBar) {
    var items = eAppFlowToolBar.get_items();
    for (var i = 0; i < items.get_count(); i++) {
      var item = items.getItem(i);
      item.set_toolTip(dpf.getLocalizeString(item.get_value()));
      var tipElement = jQuery(item.get_element()).find('.rtbWrap');
      if (tipElement.length)
        tipElement[0].setAttribute('title', dpf.getLocalizeString(item.get_value()));
    }
  },
  init: function () {
    dpf.init();
    appendPaletteAndTree();
    setHeight();
  },
  createeApplicationFlow: function (eAppTree, items) {
    var activities = this.getItemsByType(items, 'Activity');
    if (activities.length) {
      var eStartBlockId = dpf.eapp.add('eStart');
      this.processActivityFlow(activities[0], dpf.eapp.findBlock(eStartBlockId));
    }
  },
  processActivityFlow: function (activityItem, beforeBlock) {
    if (activityItem.items.length === 0) {
      dpf.eapp.add('eEnd');
    }
    if (activityItem.items.length === 1) {
      dpf.eapp.add('eActivity');
    } else if (activityItem.items.length > 1) {
      dpf.eapp.add('eDecisionActivity');
    }
  },
  getItemsByType: function (items, type) {
    var fItems = (arguments.length == 3 && (arguments[2] instanceof Array)) ? arguments[2] : [];
    for (var i = 0; i < items.length; i++) {
      if (items[i].type && items[i].type == type) {
        fItems.push(items[i]);
      }
      arguments.callee.call(dpf.eapp, items[i].items, type, fItems);
    }
    if (arguments.length == 2) return fItems;
  }
};

dpf.eapp.init();

function setHeight() {

}

function appendPaletteAndTree() {

}


dpf.telerik._createNodesFromData = function (radTree, json) {
  if (!radTree.get_childListElement()) {
    radTree._createChildListElement();
    radTree._createChildControls();
  }

  if (!json) {
    return;
  }

  (function (radTree, json, nodes) {

    for (var d = 0, e = json.length; d < e; d++) {
      var g = new Telerik.Web.UI.RadTreeNode();

      if (json[d].text) {
        g.set_text(dpf.getLocalizeString(json[d].text));
      }
      if (json[d].value) {
        g.set_value(json[d].value);
      }
      if (json[d].type) {
        g.get_attributes().setAttribute('type', json[d].type);
      } else {

      }

      nodes.add(g);

      if (json[d].items && json[d].items.length) {
        arguments.callee.call(dpf.telerik, radTree, json[d].items, g.get_nodes());
      }
    }
  })(radTree, json, radTree.get_nodes());

};