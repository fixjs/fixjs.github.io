﻿/**
 * DouranPortal Client Fraemwork
 *
 * @author    Mehran Hatami hatami@douran.com
 * @version   2.0
 * @url       http://www.douran.com
 *
 */
var dpf = {
  qs: {},
  defaultLang: "en-US",
  loadComplete: false,
  //
  telerik: {
    clientComponents: []
  },

  // dpf core global functions
  find: function () {
    if (arguments.length == 1 && typeof (arguments[0]) == "string") {
      return document.getElementById(arguments[0]);
    }
  },

  readQueryStrings: function () {
    if (window.location.search) {
      var qsstr = window.location.search.substring(1, window.location.search.length);

      if (!qsstr) {
        return;
      }

      var qsarr = qsstr.split("&");

      for (var i = 0, len = qsarr.length; i < len; i++) {
        var cqs = qsarr[i].split("=");
        this.qs[cqs[0]] = (cqs.length == 2) ? cqs[1] : "";
      }
    }
  },
  getDirection: function () {
    var dir;

    if (dir = document.lastChild.getAttribute("dir"));
    else if (dir = document.body.getAttribute("dir"));
    else if (dir = document.body.style.direction);
    else {
      var bdir = window.getComputedStyle(document.body, "").getPropertyValue("direction");
      dir = bdir || "ltr";
    }

    return dir;
  },
  getRectangle: function getRectangle(obj) {
    var tt = 0;
    var rect = {};
    var width = obj.offsetWidth;
    var height = obj.offsetHeight;
    var top = 0;
    var left = 0;

    while (obj) {
      top += obj.offsetTop;
      left += obj.offsetLeft;
      obj = obj.offsetParent;
    }

    rect.width = width;
    rect.height = height;
    rect.top = top;
    rect.left = left;
    rect.right = left + width;
    rect.bottom = top + height;

    if (arguments[1]) {
      var fr = getRectangle(arguments[1]);
      rect.bottom += fr.bottom;
      rect.top += fr.top;
      rect.left += fr.left;
      rect.right += fr.right;
    }

    return rect;
  },
  init: function () {
    dpf.readQueryStrings();
    dpf.loadLocale(function () {
      dpf.loadComplete = true;
    });
  },
  loadLocale: function (callback) {
    var localeCode = dpf.qs.Lang || "en-US";
    var isCallback = (callback && (typeof callback == "function" || callback instanceof Function));
    if (localeCode != dpf.defaultLang) {
      jQuery.getScript("scripts/dpf/locales/" + localeCode + ".js", function (scriptContent, state) {
        if (state == "success") {
          try {
            //FIXME: it's dangrous
            eval(scriptContent);

            callback(state);
          } catch (exp) {
            window.status = exp.Message;
            callback("error");
          }
        } else callback(state);
      });
    } else if (isCallback) callback();
  },
  getLocalizeString: function (key) {
    var localeCode = dpf.qs.Lang || "en-US";
    if (localeCode != dpf.defaultLang && dpf.locales[key]) {
      return dpf.locales[key];
    } else {
      return key;
    }
  }
};