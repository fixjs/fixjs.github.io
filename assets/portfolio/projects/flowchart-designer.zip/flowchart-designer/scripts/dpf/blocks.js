﻿if (window.dpf === undefined) {
  if (window.parent && window.parent !== window && window.parent.dpf !== undefined) {
    window.dpf = window.parent.dpf;
    if (window.apf !== undefined) {
      window.parent.apf = window.apf;
    }
  } else {
    window.dpf = {};
  }
}

if (dpf.eapp === undefined) {
  dpf.eapp = {};
}

dpf.eapp.doAction = function (type) {
  if (this.actionTracker === undefined) {
    if (apf.window && typeof apf.window.getActionTracker === 'function') {
      this.actionTracker = apf.window.getActionTracker();
    }
  }

  if (this.actionTracker && typeof this.actionTracker[type] === 'function') {
    this.actionTracker[type]();
  }
};

document.addEventListener('keydown', function (e) {
  if (e.ctrlKey) {
    if (e.keyCode == 90) {
      dpf.eapp.doAction('undo');
    } else if (e.keyCode == 89) {
      dpf.eapp.doAction('redo');
    }
  }
});

var oldApfOnLoad = apf.onload;

apf.onload = function () {
  if (oldApfOnLoad !== undefined) {
    oldApfOnLoad.call(window);
  }

  if (window.wfExample !== undefined) {
    window.parent.wfExample = window.wfExample;
  }
};

var blocktypes = dpf.eapp.blocktypes = {
  eStart: {
    type: 'eStart'
  },
  eEnd: {
    type: 'eEnd'
  },
  eActivity: {
    type: 'eActivity'
  },
  eDecisionActivity: {
    type: 'eDecisionActivity'
  },
  eDecision: {
    type: 'eDecision'
  }
};

var getLeft = dpf.eapp.getLeft = function () {
  if (arguments.length && arguments[0] !== undefined && !isNaN(parseInt(arguments[0]))) return parseInt(arguments[0]);
  var wfRect = dpf.getRectangle(wfExample.oExt);
  switch (this.type) {
  case 'eStart':
    return ((wfRect.width - 35) / 2);
  }
  return 100;
};
var getTop = dpf.eapp.getTop = function () {
  if (arguments.length && arguments[0] !== undefined && !isNaN(parseInt(arguments[0]))) return parseInt(arguments[0]);
  var wfRect = dpf.getRectangle(wfExample.oExt);
  switch (this.type) {
  case 'eStart':
    return 30;
  }
  return 100;
};
var getCaption = dpf.eapp.getCaption = function (caption) {
  if (arguments.length && arguments[0] !== undefined) return arguments[0] + '';
  var val = caption || '';
  if (dpf.getLocalizeString && dpf.getLocalizeString(this.type)) {
    return dpf.getLocalizeString(this.type);
  } else return this.type;
};

var blockActions = {
  left: function () {
    return dpf.eapp.getLeft.apply(this, arguments);
  },
  top: function () {
    return dpf.eapp.getTop.apply(this, arguments);
  },
  caption: function () {
    return dpf.eapp.getCaption.apply(this, arguments);
  }
};

apf.extend(blocktypes.eStart, blockActions);
apf.extend(blocktypes.eEnd, blockActions);
apf.extend(blocktypes.eActivity, blockActions);
apf.extend(blocktypes.eDecisionActivity, blockActions);
apf.extend(blocktypes.eDecision, blockActions);


var getBlocks = dpf.eapp.getBlocks = function (type) {
  var blocks = [];
  try {
    for (var blockId in wfExample.objCanvas.htmlBlocks) {
      if (wfExample.objCanvas.htmlBlocks[blockId].other.type == type) blocks.push(wfExample.objCanvas.htmlBlocks[blockId]);
    }
  } catch (exp) {}
  return blocks;
};
var findBlock = dpf.eapp.findBlock = function (xmlId) {
  try {
    for (var blockId in wfExample.objCanvas.htmlBlocks) {
      if (wfExample.objCanvas.htmlBlocks[blockId].other.xmlNode.getAttribute('id') == xmlId)
        return wfExample.objCanvas.htmlBlocks[blockId];
    }
  } catch (exp) {}
  return null;
};
var getString = dpf.eapp.getString = function (msg) {
  var v;
  if (msg.key && dpf.getLocalizeString && (v = dpf.getLocalizeString(msg.key))) return v;
  return msg.defaultValue || msg + '';
};
dpf.eapp.addeStart = function (caption, left, top) {
  if (getBlocks(blocktypes.eStart.type).length) return alert(getString(dpf.eapp.messages.errors.duplicateStart));
  wfExample.addBlock(blocktypes.eStart.type, blocktypes.eStart.left(left), blocktypes.eStart.top(top), blocktypes.eStart.caption(caption));
};
dpf.eapp.addeEnd = function (caption, left, top) {
  //if (getBlocks(blocktypes.eStart.type).length) return alert(getString(dpf.eapp.messages.errors.duplicateStart));
  wfExample.addBlock(blocktypes.eEnd.type, blocktypes.eEnd.left(left), blocktypes.eEnd.top(top), blocktypes.eEnd.caption(caption));
};
dpf.eapp.addeActivity = function (caption, left, top) {
  //if (getBlocks(blocktypes.eStart.type).length) return alert(getString(dpf.eapp.messages.errors.duplicateStart));
  wfExample.addBlock(blocktypes.eActivity.type, blocktypes.eActivity.left(left), blocktypes.eActivity.top(top), blocktypes.eActivity.caption(caption));
};
dpf.eapp.addeDecisionActivity = function (caption, left, top) {
  //if (getBlocks(blocktypes.eStart.type).length) return alert(getString(dpf.eapp.messages.errors.duplicateStart));
  wfExample.addBlock(blocktypes.eDecisionActivity.type, blocktypes.eActivity.left(left), blocktypes.eActivity.top(top), blocktypes.eActivity.caption(caption));
};
dpf.eapp.addeDecision = function (caption, left, top) {
  //if (getBlocks(blocktypes.eStart.type).length) return alert(getString(dpf.eapp.messages.errors.duplicateStart));
  wfExample.addBlock(blocktypes.eDecision.type, 700, 500, 'Hello');
};
dpf.eapp.getAddMessage = function (type) {
  switch (type) {
  case 'eStart':
    if (getBlocks(type).length) return dpf.eapp.messages.errors.duplicateStart;
    break;
  }
  return dpf.eapp.messages.addActions[type];
};
dpf.eapp.add = function (type, left, top, caption) {
  var msg = dpf.eapp.getAddMessage(type);
  if (!msg.isValid) return alert(getString(msg));

  return wfExample.addBlock(blocktypes[type].type, blocktypes[type].left(left), blocktypes[type].top(top), blocktypes[type].caption(caption), msg.capPos);
};
dpf.eapp.addAndConnect = function (type, left, top, caption) {
  var msg = dpf.eapp.getAddMessage(type);
  if (!msg.isValid) {
    return alert(getString(msg));
  }
  wfExample.addBlock(blocktypes[type].type, blocktypes[type].left(left), blocktypes[type].top(top), blocktypes[type].caption(caption), msg.capPos);
};
dpf.eapp.flowToolbar = {};
dpf.eapp.flowToolbar.rotateElement = function rotateElement(turn) {
  if (!wfExample.selected) {
    alert('Select element.');
  } else {
    var sel = wfExample.selected;

    var rotation = !sel.getAttribute('rotation') ? 0 : parseInt(sel.getAttribute('rotation'));

    if (turn == 1) {
      rotation += 90;
      if (rotation > 270) {
        rotation = 0;
      }
    } else if (turn === 0) {
      rotation -= 90;
      if (rotation < 0) {
        rotation = 270;
      }
    }
    wfExample.rotate(sel, rotation);
  }
};
dpf.eapp.flowToolbar.flipv = function flipv() {
  if (!wfExample.selected) {
    alert('Select element.');
  } else {
    var sel = wfExample.selected;
    wfExample.flipVertical(sel, parseInt(sel.getAttribute('flipv')) == 'true' ? false : true);
  }
};
dpf.eapp.flowToolbar.fliph = function fliph() {
  if (!wfExample.selected) {
    alert('Select element.');
  } else {
    var sel = wfExample.selected;
    wfExample.flipHorizontal(sel, parseInt(sel.getAttribute('fliph')) == 'true' ? false : true);
  }
};
dpf.eapp.flowToolbar.lockToggleSelected = function lockToggleSelected() {
  if (!wfExample.selected) {
    alert('Select element.');
  } else {
    var sel = wfExample.selected;
    var lock = sel.getAttribute('lock') == 'true' ? true : false;
    wfExample.setLock(sel, lock ? false : true);
  }
};
dpf.eapp.flowToolbar.zindex = function () {
  if (!wfExample.selected) {
    alert('Select element.');
  } else {
    var sel = wfExample.selected;
    var zindex = parseInt(sel.getAttribute('zindex'));
    wfExample.setZindex(sel, (zindex - 1));
  }
};
dpf.eapp.createModel = function createModel(xmlDoc) {
  return new apf.model(xmlDoc);
};
dpf.eapp.messages = {
  errors: {
    duplicateStart: {
      isValid: false,
      key: 'DuplicateStart',
      defaultValue: 'this flow has an Start Activity!'
    }
  },
  addActions: {
    eStart: {
      isValid: true,
      capPos: 'topside'
    },
    eActivity: {
      isValid: true,
      capPos: 'inside'
    },
    eDecisionActivity: {
      isValid: true,
      capPos: 'topinside'
    },
    eDecision: {
      isValid: true,
      capPos: 'topside'
    },
    eEnd: {
      isValid: true,
      capPos: 'outside'
    }
  }
};