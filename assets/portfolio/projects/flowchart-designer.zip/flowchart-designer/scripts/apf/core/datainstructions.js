/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

//#ifdef __WITH_DATA_INSTRUCTIONS

/**
 * @term datainstruction Data instructions offer a single and consistent way for
 * storing and retrieving
 * data from different data sources. For instance from a webserver using REST
 * or RPC, or from local data sources such as gears, air, o3, html5, as well as
 * from in memory sources from javascript or cookies. There is often an xml
 * element which is relevant to storing information. This element can be
 * accessed using xpath statements in the data instruction using curly braces.
 *
 * Syntax:
 * Using data instructions to retrieve data
 * <code>
 * get="name_of_model"
 * get="name_of_model:xpath"
 * get="#element"
 * get="#element:select"
 * get="#element:select:xpath"
 * get="#element"
 * get="#element:choose"
 * get="#element:choose:xpath"
 * get="#element::xpath"
 * get="url:example.jsp"
 * get="url:http://www.bla.nl?blah=10&foo={@bar}&example=[10+5]"
 * get="rpc:comm.submit('abc', {@bar})"
 * get="call:submit('abc', {@bar})"
 * get="xmpp:login(username, password)"
 * get="webdav:getRoot()"
 * get="eval:10+5"
 * </code>
 *
 * Syntax:
 * Using data instructions to store data
 * <code>
 * set="url:http://www.bla.nl?blah=10&foo={/bar}&example=[10+5]"
 * set="url.post:http://www.bla.nl?blah=10&foo={/bar}&example=[10+5]"
 * set="rpc:comm.submit('abc', {/bar})"
 * set="call:submit('abc', {/bar})"
 * set="eval:example=5"
 * set="cookie:name.subname = {.}"
 * </code>
 *
 * See:
 * <ul>
 *  <li>{@link teleport.cgi the cgi teleport module}</li>
 *  <li>{@link teleport.rpc the rpc teleport module}</li>
 *  <li>{@link teleport.webdav the webdav teleport module}</li>
 *  <li>{@link teleport.xmpp the xmpp teleport module}</li>
 * </ul>
 */

/**
 * @private
 */
apf.namespace("datainstr", {
    "call" : function(xmlContext, options, callback){
        var parsed = options.parsed || this.parseInstructionPart(
            options.instrData.join(":"), xmlContext, options.args, options);

        //#ifdef __DEBUG
        if (!self[parsed.name])
            throw new Error(apf.formatErrorString(0, null,
                "Saving/Loading data", "Could not find Method '" + q[0] + "' \
                in process instruction '" + instruction + "'"));
        //#endif

        if (options.preparse) {
            options.parsed = parsed;
            options.preparse = -1;
            return;
        }

        //Call method
        var retvalue = self[parsed.name].apply(null, parsed.arguments);

        //Call callback
        if (callback)
            callback(retvalue, apf.SUCCESS, options);
    },

    "eval" : function(xmlContext, options, callback){
        var parsed = options.parsed
            || this.parseInstructionPart(
                "(" + options.instrData.join(":") + ")", xmlContext,
                options.args, options);

        if (options.preparse) {
            options.parsed = parsed;
            options.preparse = -1;
            return;
        }

        try {
            var retvalue = eval(parsed.arguments[0]);
        }
        catch(e) {
            //#ifdef __DEBUG
            throw new Error(apf.formatErrorString(0, null, "Saving data",
                "Could not execute javascript code in process instruction \
                '" + instruction + "' with error " + e.message));
            //#endif
        }

        if (callback)
            callback(retvalue, apf.SUCCESS, options);
    }

    // #ifdef __WITH_COOKIE
    ,cookie: function(xmlContext, options, callback){
        var query  = options.instrData.join(":");
        var parsed = options.parsed || query.indexOf("=") > -1
            ? this.parseInstructionPart(query.replace(/\s*=\s*/, "(") + ")",
                xmlContext, options.args, options)
            : {name: query, args: options.args || [xmlContext]};

        if (options.preparse) {
            options.parsed = parsed;
            options.preparse = -1;
            return;
        }

        var value;
        if (options.isGetRequest) {
            value = apf.getcookie(parsed.name);
            value = value ? apf.unserialize(value) || "" : "";
        }
        else {
            value = apf.setcookie(parsed.name,
                apf.serialize(parsed.args[0]));
        }

        if (callback)
            callback(value || parsed.args[0], apf.SUCCESS, options);
    }

    // #endif
});


/**
 * Stores data using a {@link term.datainstruction data instruction}.
 *
 * @param {String}      instruction  the {@link term.datainstruction data instruction} to be used to store the data.
 * @param {XMLElement}  [xmlContext] the subject of the xpath queries
 * @param {Object}      [options]    the options for this instruction
 *   Properties:
 *   {Boolean} multicall    whether this call should not be executed immediately but saved for later sending using the purge() command.
 *   {mixed}   userdata     any data that is useful to access in the callback function.
 *   {Array}   args         the arguments of the call, overriding any specified in the data instruction.
 * @param {Function}    [callback]   the code that is executed when the call returns, either successfully or not.
 */
apf.saveData = function(instruction, xmlContext, options, callback){
    if (!instruction) return false;

    if (!options) options = {};
    options.instrData = instruction.split(":");
    options.instrType = options.instrData.shift();
    
    var instrType = options.instrType.indexOf("url.") == 0
        ? "url"
        : options.instrType;

    options.instruction = instruction;

    //#ifdef __DEBUG
    if (!this.datainstr[instrType]) {
        /*throw new Error(apf.formatErrorString(0, null,
            "Processing a data instruction",
            "Unknown data instruction format: " + instrType));*/
        
        return false;
    }
    //#endif

    this.datainstr[instrType].call(this, xmlContext, options, callback);
};

/**
 * Retrieves data using a {@link term.datainstruction data instruction}.
 * Example:
 * Several uses for a data instruction
 * <code>
 *  <!-- loading aml from an xml file -->
 *  <a:bar aml="url:moreaml.xml" />
 *
 *  <a:bindings>
 *    <!-- loads data using an remote procedure protocol -->
 *    <a:load   get = "rpc:comm.getData()" />
 *
 *    <!-- inserts data using an remote procedure protocol -->
 *    <a:insert get = "rpc:comm.getSubData({@id})" />
 *  </a:bindings>
 *
 *  <a:actions>
 *    <!-- notifies the server that a file is renamed -->
 *    <a:rename set = "url:update_file.jsp?id={@id}&name={@name}" />
 *
 *    <!-- adds a node by retrieving it's xml from the server. -->
 *    <a:add    get = "url:new_user.xml" />
 *  </a:actions>
 *
 *  <!-- creates a model which is loaded into a list -->
 *  <a:list model="webdav:getRoot()" />
 *
 *  <!-- loads data into a model and when submitted sends the altered data back -->
 *  <a:model load="url:load_contact.jsp" submission="save_contact.jsp" />
 * </code>
 *
 * @param {String}      instruction  the {@link term.datainstruction data instruction} to be used to retrieve the data.
 * @param {XMLElement}  [xmlContext] the subject of the xpath queries
 * @param {Object}      [options]    the options for this instruction
 *   Properties:
 *   {Boolean} multicall    whether this call should not be executed immediately but saved for later sending using the purge() command.
 *   {mixed}   userdata     any data that is useful to access in the callback function.
 *   {mixed}   data         data to use in the call
 *   {Array}   args         the arguments of the call, overriding any specified in the data instruction.
 * @param {Function}    [callback]   the code that is executed when the call returns, either successfully or not.
 */
//instrType, data, xmlContext, callback, multicall, userdata, arg, isGetRequest
apf.getData = function(instruction, xmlContext, options, callback){
    var instrParts = instruction.match(/^(.*?)(?:\!\{(.*)$|$)/);//\[([^\]\[]*)\]
    var operators  = instrParts[2] ? instrParts[2].splitSafe("\}\s*,|,|\}\s*") : "";//\{|

    var gCallback  = function(data, state, extra){
        if (state != apf.SUCCESS)
            return callback(data, state, extra);

        operators[2] = data;
        if (operators[0] && data) {
            if (typeof data == "string")
                data = apf.xmldb.getXml(data);

            extra.data = data;
            data = data.selectSingleNode(operators[0]);

            //Change this to warning?
            if (!data) {
                throw new Error(apf.formatErrorString(0, null,
                    "Loading new data", "Could not load data because \
                    the xpath selection didn't have a match. \n\
                    Xpath: '" + operators[0] + "'\n\
                    Data instruction: '" + instruction + "'"));
            }
        }

        extra.userdata = operators;
        return callback(data, state, extra);
    }

    if (!options) options = {};
    options.isGetRequest = true;
    options.userdata     = operators;

    //Get data operates exactly the same as saveData...
    if (this.saveData(instrParts[1], xmlContext, options, gCallback) !== false)
        return;

    //...and then some
    var data      = instruction.split(":");
    var instrType = data.shift();

    if (instrType.substr(0, 1) == "#") {
        instrType = instrType.substr(1);
        var retvalue, oAmlNode = self[instrType];

        if (!oAmlNode) {
            var err = new Error(apf.formatErrorString(0, null, "Loading data",
                "Could not find object '" + instrType + "' referenced in \
                process instruction '" + instruction + "' with error "
                + e.message));
            
            if (callback && callback(null, apf.ERROR, {
                message : err.description || err.message,
                error   : err
            } === true))
                return;

            throw err;
        }

        var node = oAmlNode.hasFeature(__MULTISELECT__)
            ? oAmlNode.selected
            : oAmlNode.xmlRoot;
        
        if (!node)
            retvalue = null;
        else
            retvalue = data[1]
              ? node.selectSingleNode(data[1])
              : node;
    }
    else {
        var model = apf.nameserver.get("model", instrType);

        if (!model) {
            var err = new Error(apf.formatErrorString(1068, null,
                "Loading data", "Could not find model by name: "
                + instrType));

            if (callback && callback(null, apf.ERROR, {
                message : err.description || err.message,
                error   : err
            }) === true)
                return;
            
            throw err;
        }

        if (!model.data)
            retvalue = null;
        else
            retvalue = data[1]
                ? model.data.selectSingleNode(data[1])
                : model.data;
    }

    if (callback)
        gCallback(retvalue, apf.SUCCESS, {userdata:operators});
    else {
        //apf.console.warn("Returning data directly in apf.getData(). \
            //This means that all callback communication ends in void!");
        return retvalue;
    }
};

//#ifdef __WITH_MODEL
/**
 * Creates a model object based on a {@link term.datainstruction data instruction}.
 *
 * @param {String} instruction  the {@link term.datainstruction data instruction} to be used to retrieve the data for the model.
 * @param {AmlNode} amlNode     the element the model is added to.
 * @param {Boolean} isSelection whether the model provides data that determines the selection of the element.
 */
apf.setModel = function(instruction, amlNode, isSelection){
    if (!instruction) return;

    var data      = instruction.split(":");
    var instrType = data[0];

    //So are we sure we shouldn't also check .dataParent here?
    var model = isSelection
        ? amlNode.$getMultiBind().getModel()
        : amlNode.getModel && amlNode.getModel();
    if(model)
        model.unregister(amlNode);

    if (apf.datainstr[instrType]) {
        amlNode.setModel(new apf.model().loadFrom(instruction));
    }
    else if (instrType.substr(0,1) == "#") {
        instrType = instrType.substr(1);

        if (isSelection) {
            var sb2 = apf.isParsing
                ? apf.AmlParser.getFromSbStack(amlNode.uniqueId, 1)
                : amlNode.$getMultiBind().smartBinding;
            if (sb2)
                sb2.model = new apf.model().loadFrom(instruction);
        }
        else if (!self[instrType] || !apf.AmlParser.inited) {
            apf.AmlParser.addToModelStack(amlNode, data)
        }
        else {
            var oConnect = eval(instrType);
            if (oConnect.connect)
                oConnect.connect(amlNode, null, data[2], data[1] || "select");
            else
                amlNode.setModel(new apf.model().loadFrom(instruction));
        }

        amlNode.connectId = instrType;
    }
    else {
        var instrType = data.shift();
        model = instrType == "@default"
            ? apf.globalModel
            : apf.nameserver.get("model", instrType);

        //#ifdef __DEBUG
        if (!model) {
            throw new Error(apf.formatErrorString(1068, amlNode,
                "Finding model", "Could not find model by name: " + instrType));
        }
        //#endif

        if (isSelection) {
            var sb2 = apf.isParsing
                ? apf.AmlParser.getFromSbStack(amlNode.uniqueId, 1)
                : amlNode.$getMultiBind().smartBinding;
            if (sb2) {
                if (apf.isParsing) {
                    sb2.model = model;
                    sb2.$modelXpath[amlNode.uniqueId] = data.join(":");
                }
                else 
                    sb2.setModel(model, data.join(":"));
            }
        }
        else
            amlNode.setModel(model, data.join(":"));
    }
};
//#endif

/**
 * Parses argument list
 * Example:
 * Javascript
 * <code>
 *  apf.parseInstructionPart('type(12+5,"test",{@value}.toLowerCase(),[0+2, "test"])', xmlNode);
 * </code>
 * Aml
 * <code>
 *  <a:rename set="rpc:comm.setFolder({@id}, {@name}, myObject.someProp);" />
 * </code>
 * @private
 */
apf.parseInstructionPart = function(instrPart, xmlNode, arg, options){
    var parsed  = {}, s = instrPart.split("(");
    parsed.name = s.shift();

    //Get arguments for call
    if (!arg) {
        arg = s.join("(");

        //#ifdef __DEBUG
        if (arg.slice(-1) != ")") {
            throw new Error(apf.formatErrorString(0, null, "Saving data",
                "Syntax error in instruction. Missing ) in " + instrPart));
        }
        //#endif

        function getXmlValue(xpath){
            var o = xmlNode ? xmlNode.selectSingleNode(xpath) : null;

            if (!o)
                return null;
            else if (o.nodeType >= 2 && o.nodeType <= 4)
                return o.nodeValue;
            else if (apf.isOnlyChild(o.firstChild, [3, 4]))
                return o.firstChild.nodeValue;
            else
                return o.xml || o.serialize();
        }

        arg = arg.slice(0, -1);
        var depth, lastpos = 0, result = ["["];
        arg.replace(/\\[\{\}\'\"]|(["'])|([\{\}])/g,
            function(m, chr, cb, pos){
                chr && (!depth && (depth = chr)
                    || depth == chr && (depth = null));

                if (!depth && cb) {
                    if (cb == "{") {
                        result.push(arg.substr(lastpos, pos - lastpos));
                        lastpos = pos + 1;
                    }
                    else {
                        var str = arg.substr(lastpos, pos - lastpos);
                        if (str.match(/[\w_]+\s*\:[^\:]/))
                            result.push("{" + str + "}");
                        else 
                            result.push("getXmlValue('", str
                                .replace(/([\\'])/g, "\\$1"), "')");
                        lastpos = pos + 1;
                    }
                }
            });

        result.push(arg.substr(lastpos), "]");

        //Safely set options
        (function(){
            try{
                with (options) {
                    arg = eval(result.join(""));
                }
            }
            catch(e) {
                //#ifdef __DEBUG
                throw new Error(apf.formatErrorString(0, null, "Saving data",
                    "Error executing data instruction: " + arg
                    + "\nreason:" + e.message
                    + "\nAvailable properties:" + apf.vardump(options)));
                //#endif

                arg = [];
            }
        })();
    }

    parsed.arguments = arg;

    return parsed;
};

//#endif
