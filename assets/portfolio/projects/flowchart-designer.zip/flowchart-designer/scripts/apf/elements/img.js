/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

// #ifdef __JIMG || __INC_ALL
// #define __JBASESIMPLE 1

/**
 * Element displaying a picture. This element can read databound resources.
 * Example:
 * This example shows a list with pictures. When one is selected its displayed
 * in the img element.
 * <code>
 *  <a:model id="mdlPictures"> 
 *      <pictures> 
 *          <picture title="Landscape" src="http://example.com/landscape.jpg" />
 *          <picture title="Animal" src="http://example.com/animal.jpg" />
 *          <picture title="River" src="http://example.com/river.jpg" />
 *      </pictures> 
 *  </a:model>
 *  
 *  <a:list id="lstPics" skin="thumbnail" height="200" width="400" 
 *      traverse = "picture" 
 *      name = "@title" 
 *      model = "mdlPictures" 
 *      image = "@src" 
 *  />
 *   
 *  <a:img ref="@src" model="#lstPics" width="400" />
 * </code>
 *
 * @constructor
 * @define img
 * @allowchild {smartbinding}
 * @addnode elements
 *
 * @inherits apf.BaseSimple
 *
 * @author      Ruben Daniels (ruben AT javeline DOT com)
 * @version     %I%, %G%
 * @since       0.4
 *
 * @event click Fires when a user presses a mouse button while over this element.
 *
 * @binding value  Determines the way the value for the element is retrieved 
 * from the bound data.
 * Example:
 * Sets the image source based on data loaded into this component.
 * <code>
 *  <a:img>
 *      <a:bindings>
 *          <a:value select="@src" />
 *      </a:bindings>
 *  </a:img>
 * </code>
 * Example:
 * A shorter way to write this is:
 * <code>
 *  <a:img ref="@src" />
 * </code>
 */
apf.img = apf.component(apf.NODE_VISIBLE, function(){
    // #ifdef __WITH_EDITMODE
    this.editableParts = {"main" : [["image","@src"]]};
    //#endif
    
    var _self = this;
    
    /**
     * Sets the value of this element. This should be one of the values
     * specified in the values attribute.
     * @param {String} value the new value of this element
     */
    this.setValue = function(value){
        this.setProperty("value", value);
    };
    
    /**
     * Returns the current value of this element.
     * @return {String}
     */
    this.getValue = function(value){
        return this.value;
    };
    
    this.$supportedProperties.push("value", "src");
    /**
     * @attribute {String} value the url location of the image displayed.
     */
    this.$propHandlers["src"] = 
    this.$propHandlers["value"] = function(value){
        if (this.oImage.nodeType == 1)
            this.oImage.style.backgroundImage = "url(" + value + ")";
        else
            this.oImage.nodeValue = value;
        
        //@todo resize should become a generic thing
        if (this.oImage.nodeType == 2 && !this.$resize.done) {
            if (this.oImg) {
                //#ifdef __WITH_LAYOUT
                //@todo add this to $destroy
                var pNode = apf.hasSingleRszEvent ? this.pHtmlNode : this.oExt;
                apf.layout.setRules(pNode, this.uniqueId + "_image",
                    "var o = apf.all[" + this.uniqueId + "];\
                     if (o) o.$resize()");
                apf.layout.activateRules(pNode);
                
                this.oImg.onload = function(){
                    apf.layout.forceResize(pNode);
                }
                //#endif
            }
            
            this.$resize.done = true;
        }

        if (this.oImg) {
            this.oImg.style.display = value ? "block" : "none";
            
            if (value)
                this.$resize();
        }
    };
    
    this.$clear = function(){
        this.value = "";
        
        if (this.oImg)
            this.oImg.style.display = "none";
    }
    
    /**** Init ****/
    
    this.$draw = function(){
        //Build Main Skin
        this.oInt = this.oExt = this.$getExternal();
        this.oExt.onclick = function(e){
            this.host.dispatchEvent("click", {htmlEvent: e || event});
        };
        this.oImage = this.$getLayoutNode("main", "image", this.oExt);
        this.oImg = this.oInt.getElementsByTagName("img")[0];
    };
    
    this.$resize = function(){
        var diff = apf.getDiff(this.oExt);
        var wratio = 1, hratio = 1;
        
        this.oImg.style.width = "";
        this.oImg.style.height = "";
        
        if (this.oImg.offsetWidth > this.oExt.offsetWidth)
            wratio = this.oImg.offsetWidth / (this.oExt.offsetWidth - diff[0]);
        if (this.oImg.offsetHeight > this.oExt.offsetHeight)
            hratio = this.oImg.offsetHeight / (this.oExt.offsetHeight - diff[1]);

        if (wratio > hratio && wratio > 1)
            this.oImg.style.width = "100%";
        else if (hratio > wratio && hratio > 1)
            this.oImg.style.height = "100%";
        
        this.oImg.style.top = ((this.oExt.offsetHeight - apf.getHeightDiff(this.oExt) 
            - this.oImg.offsetHeight) / 2) + "px";
    }
    
    this.$loadAml = function(x){
        if(x.getAttribute("src"))
            this.setProperty("value", x.getAttribute("src"));
        
        apf.AmlParser.parseChildren(x, null, this);
    };
}).implement(
    apf.BaseSimple
);

// #endif
