/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

// #ifdef __JTAB || __JPAGES || __JSWITCH || __INC_ALL
// #define __WITH_PRESENTATION 1
// #define __JBASETAB 1

/**
 * Element displaying a page and several buttons allowing a
 * user to switch between the pages. Each page can contain
 * arbitrary aml. Each page can render it's content during
 * startup of the application or when the page is activated.
 * Example:
 * <code>
 *  <a:tab id="tab">
 *      <a:page caption="General">
 *          <a:checkbox>Example</a:checkbox>
 *          <a:button>Example</a:button>
 *      </a:page>
 *      <a:page caption="Advanced">
 *          <a:checkbox>Test checkbox</a:checkbox>
 *          <a:checkbox>Test checkbox</a:checkbox>
 *          <a:checkbox>Test checkbox</a:checkbox>
 *      </a:page>
 *      <a:page caption="Ajax.org">
 *          <a:checkbox>This ok?</a:checkbox>
 *          <a:checkbox>This better?</a:checkbox>
 *      </a:page>
 *  </a:tab>
 * </code>
 *
 * @constructor
 * @define tab, pages, switch
 * @allowchild page
 * @addnode elements
 *
 * @author      Ruben Daniels (ruben AT javeline DOT com)
 * @version     %I%, %G%
 * @since       0.1
 *
 * @inherits apf.BaseTab
 */

apf["switch"] =
apf.pages     =
apf.tab       = apf.component(apf.NODE_VISIBLE, function(){
    this.$hasButtons = this.tagName == "tab";
    this.$focussable = apf.KEYBOARD; // This object can get the focus from the keyboard

    /**** Init ****/

    this.$draw = function(bSkinChange){
        //Build Main Skin
        this.oExt = this.$getExternal();
    };

    this.$loadAml = function(x){
        this.switchType = x.getAttribute("switchtype") || "incremental";
        this.$loadChildren();
    };
}).implement(apf.BaseTab);

// #endif
