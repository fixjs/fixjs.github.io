/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

//#ifdef __WITH_DATABINDING

/**
 * @term smartbinding Smartbinding is a type of bidirectional databinding where 
 * rules specify how data is rendered in a component <i>and</i> how changes to
 * the bound data are sent back to the server (or other data source). 
 * Smartbindings are specifically designed to solve the problem of databinding
 * for Ajax applications that connect to remote (non-local) datasources.
 * A smartbinding element can contain three elements; {@link element.bindings bindings}, 
 * {@link element.actions actions} and {@link element.model model}.
 *
 * See also more information about {@link term.binding binding rules} and
 * {@link term.action action rules}.
 *
 * Model:
 * The model is the place where your xml data resides. Data is loaded into the
 * model using a {@link term.datainstruction data instruction} as the following
 * example shows:
 * <code>
 *  <a:model load="url:get_person.php?id=10" />
 * </code>
 * An element can connect directly to a model in order to bind to data.
 * <code>
 *  <a:model id="mdlExample" />
 *  <a:tree model="mdlExample" />
 * </code>
 *
 * The model can also be part of a smartbinding that is used by the element. 
 * A smartbinding can be used by multiple elements referenced by id:
 * <code>
 *  <a:smartbinding id="sbExample">
 *      <a:model />
 *      ...
 *  </a:smartbinding>
 *  <a:tree smartbinding="sbExample" />
 * </code>
 *
 * Bindings:
 * The bindings element is a container for binding rules. Binding rules determine
 * how an element renders the data that it's bound to. Some binding rules specify
 * how data can be interacted with (i.e. {@link baseclass.multiselect.binding.select the select rule}).
 * Check the {@link term.binding term binding rules} for more information.
 *
 * Actions:
 * The actions element is a container for action rules. Action rules influence 
 * and trigger several parts of the user interaction. 
 * <ol>
 *  <li>It determines whether a user action can be executed on the bound and/or 
 *      selected {@link term.datanode data node}.</li>
 *  <li>It dispatches events, before and after the data is changed.</li>
 *  <li>It creates a {@link http://en.wikipedia.org/wiki/Command_pattern command object} 
 *      that is pushed on the undo stack of the {@link element.actiontracker actiontracker} 
 *      connected to the element that triggered the action.</li>
 *  <li>The command object contains all the information to send the change back 
 *      to the server</li>
 * </ol>
 * So in short, an action rule is always triggered by the user, creates an 
 * undo item and sends the change back to the server.
 * Check the {@link term.action term action rules} for more information.
 *
 * See:
 * {@link baseclass.databinding.attribute.smartbinding}
 */

/**
 * @term binding Binding rules determine how an element displays the data that 
 * its bound to (ex.: {@link element.tree.binding.caption the caption rule}), 
 * and determines how it can be interacted with 
 * (ex.: {@link baseclass.multiselect.binding.select the select rule}).
 * Binding rules are part of the {@link term.smartbinding smartbinding concept}.
 * 
 * Basic:
 * Let's take a simple example, that of a {@link element.textbox textbox}. A 
 * textbox has a {@link element.textbox.attribute.value value attribute}. This
 * attribute can be set like this:
 * <code>
 *  <a:textbox value="The text" />
 * </code>
 * In many cases it's handy to bind the value of the textbox to data. Imagine
 * you are editing a contact's name in a textbox. In this case you would want to 
 * bind the value of the textbox to the xml data. The binding rule is configured
 * to determine this value based on the bound xml. Let's look at an example:
 * <code>
 *  <a:model id="mdlExample">
 *      <contact>
 *          <name>Test</name>
 *      </contact>
 *  </a:model>
 *
 *  <a:textbox model="mdlExample">
 *      <a:bindings>
 *          <a:value select="name" />
 *      </a:bindings>
 *  </a:textbox>
 * </code>
 * The textbox binds to the data of the model. The bind rule sets how the value
 * is retrieved from the bound data. In this case the value of the name node is
 * retrieved. <strong>When the user changes the value of the textbox, the name
 * node is updated with that value.</strong> Subsequently <strong>when the xml
 * changes the value of the textbox is updated</strong>.
 *
 * Each attribute on an element can be bound to data by using the attribute
 * name as the name of the binding rule. In the next example, the visible
 * attribute of a textbox is based on the availability of a {@link term.datanode data node}:
 * <code>
 *  <a:textbox>
 *      <a:bindings>
 *          <a:visible select="name" value="true" />
 *      </a:bindings>
 *  </a:textbox>
 * </code>
 * Each element has a primary bind rule that can be accessed in a short format.
 * This is usually the value bind rule. The short format works as follows:
 * <code>
 *  <a:textbox ref="name" model="mdlExample" />
 * </code>
 *
 * Advanced:
 * For multi node components databinding adds another conceptual step. The basics
 * stay the same, though a way is introduced to do 'foreach' on the data to 
 * determine which nodes are rendered. This is done using the 
 * {@link element.multiselectbinding.binding.traverse traverse binding rule} and
 * the selected nodes are called {@link term.traversenode traverse nodes}.
 *
 * When the set of traverse nodes is determined, each is rendered based on other
 * binding rules that determine whatever is deemed necesary by the component. 
 * This can be the caption, icon, tooltip, whether an item is seletable and so on.
 * In the next example a list is bound to some data representing a contact list.
 * Each contact's name is displayed as the caption of the item.
 * <code>
 *  <a:list>
 *      <a:bindings>
 *          <a:caption select="name" />
 *          <a:icon value="contact.png" />
 *          <a:tooltip select="company" />
 *          <a:traverse select="contact" />
 *      </a:bindings>
 *  </a:list>
 * </code>
 * 
 * Fallbacks:
 * By stacking multiple binding rules it's possible to define different ways to
 * determine the value for an attribute. Let's say we have a tree that displays
 * files and folders. A file and a folder can have custom icons. If these are 
 * not specified, they each default to an icon representing their type. This would
 * be encoded like this:
 * <code>
 *  <a:bindings>
 *      <a:icon select="@icon" />
 *      <a:icon select="self::folder" value="folder.png" />
 *      <a:icon select="self::file" value="file.png" />
 *  </a:bindings>
 * </code>
 *
 * Processors:
 * There are several ways to convert the data retrieved from the xml data into
 * the needed string or boolean. The following example uses {@link core.apf.object.jsltImplementation jslt}
 * to determine the icon by the extension of the filename:
 * <code>
 *  <a:bindings>
 *      <a:icon select="."><![CDATA[
 *          [var ext = $'@filename'.split(".").pop();
 *           %ext == $'@filename' ? "unknown.png" : ext + ".png";]
 *      ]]></a:icon>
 *  </a:bindings>
 * </code>
 * Instead of jslt you can use xslt as well. Furthermore you can apply some
 * javascript to the result by calling a method. The following examples shows
 * a caption where a javascript method inserts smileys.
 * <code>
 *  <a:bindings>
 *      <a:caption select="body" method="insertSmileys" />
 *  </a:bindings>
 * </code>
 *
 * Extending:
 * Two special binding rules are the {@link baseclass.databinding.binding.load load}
 * and the {@link element.tree.binding.insert insert} bindings. These bindings
 * are used to load and insert new data into the data bound to the element that
 * uses them. With these rules an application can start out with only a bit of
 * data and when the user needs it extends the data. A simple example is that of
 * a tree element that loads subnodes whenever a user expands a node. This can
 * be achieved in the following way:
 * <code>
 *  <a:tree>
 *      <a:bindings>
 *          <a:caption select = "@name" />
 *          <a:insert  select = "self::category[not(@leaf)]" 
 *                     get    = "url:get_categories.php?parent={@id}" />
 *          <a:traverse select="category" />
 *      </a:bindings>
 *  </a:tree>
 * </code>
 * For more information about how data can be loaded into aml elements please
 * check {@link term.datainstruction data instructions}.
 */

/**
 * @term action Action rules determine whether a user can execute an action and
 * takes care of executing the change both locally and on a remote server. Each
 * triggered action creates an item on the undo stack.
 * Action rules are part of the {@link term.smartbinding smartbinding concept}.
 *
 * Syntax:
 * Actions are added to {@link element.actions}. The <i>select</i> attribute specifies
 * whether an action can be executed. The <i>set</i> attribute specifies how the change
 * to the data is send to the server. The following example shows a remove 
 * action on a datagrid. A jsp script is called to process the change. This is
 * specified using a {@link term.datainstruction data instruction}.
 * <code>
 *  <a:datagrid>
 *      <a:actions>
 *          <a:remove select = "self::contact[not(@readonly)]"
 *                    set    = "url:remove_contact.jsp?id={@dbid}" />
 *      </a:actions>
 *  </a:datagrid>
 * </code>
 *
 * Defaults:
 * The default behaviour for all components is to enable all actions when no
 * actions element has been assigned. This can be change by setting 
 * {@link element.appsettings.attribute.auto-disable-actions}. When a actions
 * element <i>is</i> assigned, all actions are disabled unless they are specified.
 * When the select attribute on an action is not set the action will always be
 * allowed. 
 * 
 * Flow:
 * Action rules influence and trigger several parts of the user interaction. 
 * <ol>
 *  <li>It determines whether a user action can be executed on the bound and/or 
 *      selected {@link term.datanode data node}.</li>
 *  <li>It dispatches events, before and after the data is changed.</li>
 *  <li>It creates a {@link http://en.wikipedia.org/wiki/Command_pattern command object} 
 *      that is pushed on the undo stack of the {@link element.actiontracker actiontracker} 
 *      connected to the element that triggered the action.</li>
 *  <li>The command object ({@link core.undodata UndoData}) contains all the 
 *      information to send the change back to the server.</li>
 * </ol>
 *
 * Fallbacks:
 * By stacking multiple action rules it's possible to define different ways to
 * deal with user actions. Let's say we have a tree that displays
 * files and folders. Renaming a file and a folder might have different handlers. 
 * This would be encoded like this:
 * <code>
 *  <a:actions>
 *      <a:rename select = "self::file"   
 *                set    = "url:rename_folder.php?path={@path}&name={@name}" />
 *      <a:rename select = "self::folder" 
 *                set    = "url:rename_file.php?path={@path}&name={@name}" />
 *  </a:actions>
 * </code>
 *
 * Undo:
 * When an action is execute it creates an entry on the undostack of an 
 * actiontracker. Undo can be triggered by calling the undo method.
 * <code>
 *  myTree.getActionTracker().undo();
 * </code>
 * Executing will revert the change to the data. This will also be communicated
 * to the server. In some cases the call to the server is not symmetric; the set
 * call cannot be used to revert. For these situations set the undo attribute.
 * <code>
 *  <a:actions>
 *      <a:remove set  = "url:remove.php?id={@id}"
 *                undo = "url:undo_remove.php?id={@id}" />
 *      </a:remove>
 *  </a:actions>
 * </code>
 * In the example above the server is required to support reverting remove. 
 * Another possibility is to add the item again as shown in this example:
 * <code>
 *  <a:actions>
 *      <a:remove set  = "url:remove.php?id={@id}"
 *                undo = "url:add.php?xml={.}" />
 *      </a:remove>
 *  </a:actions>
 * </code>
 *
 * Javascript:
 * Each action has a method associated with it that exists on the element that
 * the action rule is assigned to. The method has the same name as the action 
 * and can be called from javascript. For instance, the {@link baseclass.multiselect.binding.remove remove action}:
 * <code>
 *  myTree.remove();
 *  myTree.remove(dataNode);
 * </code>
 *
 * Add:
 * Adding {@link term.datanode data nodes} to an element is a bit more advanced because the origin of
 * the new data can be encoded in {@link baseclass.multiselect.binding.add the add action rule}. 
 * There are three ways to provide the data to add a node. 
 * 
 * The first is by calling the add method using javascript.
 * <code>
 *  <a:list id="myList">
 *      <a:actions>
 *          <a:add set="rpc:comm.addProduct({.})" />
 *      </a:actions>
 *  </a:list>
 *  <a:script>
 *      myList.add('<product name="USB drive" type="storage" />');
 *  </a:script>
 * </code>
 *
 * The second by specifying the template as a child of the add action rule:
 *  <a:actions>
 *      <a:add set="rpc:comm.addProduct({.})">
 *          <product name="USB drive" type="storage" />
 *      </a:add>
 *  </a:actions>
 *
 * The third way gets the added node from the server.
 * <code>
 *  <a:actions>
 *      <a:add get="rpc:comm.createNewProduct()" />
 *  </a:actions>
 * </code>
 *
 * Purging:
 * Sometimes it's necesary to not send the changes directly to the server. For
 * instance when the application offers a <i>save</i> button. To achieve this
 * set the {@link element.actiontracker.attribute.realtime realtime attribute}
 * of the actiontracker to false. The save button can call the 
 * {@link element.actiontracker.method.purge purge method} to have the 
 * actiontracker send the calls.
 * <code>
 *  <a:actiontracker id="myAt" realtime="false" />
 *  <a:list actiontracker="myAt" />
 *  <a:button onclick="myAt.purge()">Save</a:button>
 * </code>
 * N.B. At a certain amount of changes this way will become inefficient and 
 * you'll want to send the state of your data to the server directly. You can
 * do that like this:
 * <code>
 *  <a:list id="myList">
 *      <a:actions>
 *          <a:rename />
 *          <a:remove />
 *      </a:actions>
 *  </a:list>
 *  <a:button onclick="myList.getModel().submit('url:save.php', myList.xmlRoot)">
 *      Save
 *  </a:button>
 * </code>
 * See also {@link element.model.method.submit}.
 * 
 * Transactions:
 * A transaction is a 
 * set of changes to data which are treated as one change. When one of the 
 * changes in the set fails, all the changes will be cancelled. In the case of
 * a gui this is happens when a user decides to cancel after 
 * making several changes. A good example are the well known <i>Properties</i> 
 * windows with an ok, cancel and apply button. 
 *
 * When a user edits data, for instance user information, all the changes are
 * seen as one edit and put on the undo stack as a single action. Thus clicking
 * undo will undo the entire transaction, not just the last change done by that
 * user in the edit window. Transaction support both optimistic and pessimistic 
 * locking. For more information on transactions see {@link baseclass.transaction}.
 */
 
/**
 * @term datanode A data node is the term used for any xml node (attribute, 
 * element, textnode or otherwise) that is used in a databound context. So when
 * xml is loaded into a {@link element.model model} we refer to those xml nodes 
 * as data nodes.
 */
 
/**
 * Element containing information on how databound elements process data.
 * The {@link term.smartbinding smartbinding} element specifies how data is transformed and rendered 
 * in databound elements. It also specifies how changes on the bound data are 
 * send to their original data source ({@link element.actions actions}) and
 * which {@link term.datanode data nodes} can be dragged and dropped ({@link element.dragdrop dragdrop}).
 * Example:
 * A simple example of a smartbinding transforming data into representation
 * <code>
 *  <a:smartbinding id="sbUsers">
 *      <a:bindings>
 *          <a:caption select="text()" />
 *          <a:icon value="icoUser.png" />
 *          <a:traverse select="user" />
 *      </a:bindings>
 *  </a:smartbinding>
 * 
 *  <a:list smartbinding="sbUsers" />
 * </code>
 * Example:
 * This is an elaborate example showing how to create a filesystem tree with
 * files and folders in a tree. The smartbinding element describes how the
 * files and folders are transformed to tree elements and how actions within
 * the tree are sent to the data source. In this case {@link teleport.webdav WebDAV}
 * is used. The drag and drop rules specify which elements can be dragged and
 * where they can be dropped.
 * <code>
 *  <a:smartbinding id="sbFilesystem" model="webdav:getRoot()">
 *      <a:bindings>
 *          <a:insert select="self::folder" get="webdav:readdir({@path})" />
 *          <a:traverse select="file|folder" sort="@name" sort-method="filesort" />
 *          <a:caption select="@name" />
 *          <a:icon select="self::folder" value="icoFolder.png" />
 *          <a:icon select="self::file" method="getIcon" />
 *      </a:bindings>
 *      <a:actions>
 *         <a:add type="folder" get="webdav:mkdir({@id}, 'New Folder')" />
 *         <a:add type="file" get="webdav:create({@id}, 'New File', '')" />
 *         <a:rename set="webdav:move(oldValue, {@name}, {@id})"/>
 *         <a:copy select="." set="webdav:copy({@id}, {../@id})"/>
 *         <a:move select="." set="webdav:move()"/>
 *         <a:remove select="." set="webdav:remove({@path})"/>
 *      </a:actions>
 *      <a:dragdrop>
 *          <a:allow-drag select="folder|file" /> 
 *          <a:allow-drop select="folder|file" target="folder" 
 *              operation="tree-append" copy-condition="event.ctrlKey" /> 
 *      </a:dragdrop>
 *  </a:smartbinding>
 *
 *  <a:tree model="mdlFilesystem" smartbinding="sbFilesystem" />
 *
 *  <a:script>
 *      function filesort(value, args, xmlNode) {
 *          return (xmlNode.tagName == "folder" ? 0 : 1) + value;
 *      }
 *
 *      function getIcon(xmlNode){
 *          xmlNode.getAttribute('name').match(/\.([^\.]*)$/);
 *              
 *          var ext = RegExp.$1;
 *          return (SupportedIcons[ext.toUpperCase()]
 *              ? SupportedIcons[ext.toUpperCase()] + ".png" 
 *              : "unknown.png");
 *      }
 *  </a:script>
 * </code>
 * Remarks:
 * Each element has it's own set of binding rules it uses to render the data 
 * elements. The same goes for it's actions. To give an example, a slider has 
 * one action called 'change'. This action is called when then value of the 
 * slider changes. A tree element has several actions - among others: 'add',
 * 'remove', 'move', 'copy' and 'rename'. 
 * 
 * Smartbindings enable many other features in a Ajax.org Platform
 * application. Actions done by the user can be undone by calling 
 * {@link element.actiontracker.method.undo} of the element. The 
 * Remote Smartbinding element can send changes on data to other clients.
 *
 * This element is created especially for reuse. Multiple elements can reference
 * a single smartbinding element by setting the value of the 'smartbinding'
 * attribute to the ID of this smartbinding element. If an element is only used
 * for a single other element it can be set as it's child. In fact, each of the
 * children of the smartbinding element can exist outside the smartbinding
 * element and referenced indepently.
 * Example:
 * This example shows a smartbinding element which references to its children as
 * stand alone elements.
 * <code>
 *  <a:bindings id="bndExample">
 *      ...
 *  </a:bindings>
 *  <a:actions id="actExample">
 *      ...
 *  </a:actions>
 *  <a:dragdrop id="ddExample">
 *      ...
 *  </a:dragdrop>
 *  <a:model id="mdlExample" />
 *
 *  <a:smartbinding id="sbExample"
 *    actions  = "actExample" 
 *    bindings = "bndExample" 
 *    dragdrop = "ddExample" 
 *    model    = "mdlExample" />
 *
 *  <a:list smartbinding="sbExample" />
 *  <a:tree binding="bndExample" action="actExample" model="url:example.php" />
 * </code>
 * Example:
 * This example shows the children of the smartbinding directly as a children of
 * the element that they apply to.
 * <code>
 *  <a:tree>
 *      <a:bindings>
 *          ...
 *      </a:bindings>
 *      <a:actions>
 *          ...
 *      </a:actions>
 *      <a:dragdrop>
 *          ...
 *      </a:dragdrop>
 *  </a:tree>
 * </code>
 * Example:
 * The shortest method to add binding rules to an element is as follows:
 * <code>
 *  <a:tree traverse="file|folder" caption="@name" icon="@icon" />
 * </code>
 * @see baseclass.databinding
 * @see baseclass.databinding.attribute.smartbinding
 * @see term.smartbinding
 * @see term.binding
 * @see term.action
 * 
 * @define smartbinding
 * @allowchild bindings, actions, ref, action, dragdrop, model
 * @addnode smartbinding, global
 *
 * @constructor
 * @apfclass
 *
 * @author      Ruben Daniels (ruben AT javeline DOT com)
 * @version     %I%, %G%
 * @since       0.8
 *
 * @default_private
 */
apf.smartbinding = function(name, xmlNode, parentNode){
    this.xmlbindings = null;
    this.xmlactions  = null;
    this.xmldragdrop = null;
    this.bindings    = null;
    this.actions     = null;
    this.dragdrop    = null;

    this.amlNodes    = {};
    this.$modelXpath = {};
    this.name        = name;
    var _self        = this;
    //this.uniqueId    = apf.all.push(this) - 1;
    
    //#ifdef __WITH_AMLDOM_FULL
    this.tagName    = "smartbinding";
    this.nodeFunc   = apf.NODE_HIDDEN;
    this.parentNode = parentNode;
    apf.implement.call(this, apf.AmlDom); /** @inherits apf.AmlDom */
    //#endif

    var parts        = {
        bindings: 'loadBindings',
        actions : 'loadActions'
    };
    
    //#ifdef __DEBUG
    apf.console.info(name
        ? "Creating SmartBinding [" + name + "]"
        : "Creating implicitly assigned SmartBinding");
    //#endif
    
    /**
     * @private
     */
    this.initialize = function(amlNode, part){
        //register element
        this.amlNodes[amlNode.uniqueId] = amlNode;
        
        if (part)
            return amlNode[parts[part]](this[part], this["xml" + part]);
        
        if (amlNode.$aml && this.name) //@todo is this still relevant?
            amlNode.$aml.setAttribute("smartbinding", this.name);

        for (part in parts) {
            //#ifdef __SUPPORT_SAFARI2
            if (typeof parts[part] != "string") continue;
            //#endif

            if (!this[part]) continue;

            //#ifdef __DEBUG
            if (!amlNode[parts[part]]) {
                throw new Error(apf.formatErrorString(1035, amlNode, 
                    "initializing smartBinding", 
                    "Could not find handler for '" + part + "'."));
            }
            //#endif

            amlNode[parts[part]](this[part], this["xml" + part]);
        }

        if (this.model) {
            this.model.register(amlNode, this.$modelXpath[amlNode.getHost
                ? amlNode.getHost().uniqueId
                : amlNode.uniqueId] || this.modelBaseXpath); //this is a hack.. by making MOdels with links to other models possible, this should not be needed
        }
        else if (amlNode.$model && (amlNode.smartBinding && amlNode.smartBinding != this))
            amlNode.$model.reloadAmlNode(amlNode.uniqueId);//.load(amlNode.model.data.selectSingleNode("Accounts/Account[1]"));
        
        return this;
    };
    
    /**
     * @private
     */
    this.deinitialize = function(amlNode){
        //unregister element
        this.amlNodes[amlNode.uniqueId] = null;
        delete this.amlNodes[amlNode.uniqueId];
        
        for (var part in parts) {
            //#ifdef __SUPPORT_SAFARI2
            if (typeof parts[part] != "string") continue;
            //#endif

            if (!this[part]) continue;
            
            //#ifdef __DEBUG
            if (!amlNode["un" + parts[part]]) {
                throw new Error(apf.formatErrorString(1035, amlNode, 
                    "deinitializing smartBinding", 
                    "Could not find handler for '" + part + "'."));
            }
            //#endif
            
            amlNode["un" + parts[part]]();
        }
        
        if (this.model)
            this.model.unregister(amlNode);
    };
    
    var timer, queue = {};
    this.markForUpdate = function(amlNode, part){
        (queue[amlNode.uniqueId] 
            || (queue[amlNode.uniqueId] = {}))[part || "all"] = amlNode;
        
        if (!this.amlNodes[amlNode.uniqueId])
            this.amlNodes[amlNode.uniqueId] = amlNode;

        if (!timer) {
            timer = setTimeout(function(){
                _self.$updateMarkedItems();
            });
        }
        
        return this;
    };
    
    this.$isMarkedForUpdate = function(amlNode){
        return queue[amlNode.uniqueId] ? true : false;
    }
    
    this.$updateMarkedItems = function(){
        clearTimeout(timer);
        
        var amlNode, model, id, part, q = queue;
        timer = null;
        queue = {}
        for (id in q) {
            //We're only processing nodes that are registered here
            if (!this.amlNodes[id])
                continue;
            
            if (q[id]["all"]) {
                amlNode = q[id]["all"];
                //model isn't done here
                for (part in parts) {
                    if (!this[part]) continue;
                    amlNode[parts[part]](this[part], this["xml" + part]);
                }
                
                model = amlNode.getModel();
                if (model)
                    model.reloadAmlNode(amlNode.uniqueId);
                else
                    amlNode.reload();
            }
            else {
                for (part in q[id]) {
                    amlNode = q[id][part];
                    if (part == "model") {
                        amlNode.getModel().reloadAmlNode(amlNode.uniqueId);
                        continue;
                    }
                    
                    amlNode[parts[part]](this[part], this["xml" + part]);
                    if (part == "bindings")
                        amlNode.reload();
                }
            }
        }
    };
    
    /**
     * @private
     */
    this.addBindRule = function(xmlNode, amlParent){
        var str = xmlNode[apf.TAGNAME] == "ref"
            ? amlParent ? amlParent.mainBind : "value"
            : xmlNode.tagName;
        if (!this.bindings)
            this.bindings = {};
        if (!this.bindings[str])
            this.bindings[str] = [xmlNode];
        else
            this.bindings[str].push(xmlNode);
    };
    
    /**
     * @private
     */
    this.addBindings = function(rules){
        this.bindings    = rules;//apf.getRules(xmlNode);
        this.xmlbindings = xmlNode;
        
        if (!apf.isParsing) {
            //@todo, dynamically update part
        }
        
        //if (!apf.isParsing)
            //this.markForUpdate(null, "bindings");
    };
    
    /**
     * @private
     */
    this.addActionRule = function(xmlNode){
        var str = xmlNode[apf.TAGNAME] == "action" ? "Change" : xmlNode.tagName;
        if (!this.actions)
            this.actions = {};
        if (!this.actions[str])
            this.actions[str] = [xmlNode];
        else
            this.actions[str].push(xmlNode);
    };
    
    /**
     * @private
     */
    this.addActions = function(rules, xmlNode){
        this.actions    = rules;//apf.getRules(xmlNode);
        this.xmlactions = xmlNode;
        
        //if (!apf.isParsing)
            //this.markForUpdate(null, "actions");
    };
    
    /**
     * @private
     */
    this.addDropRule = 
    this.addDragRule = function(xmlNode){
        if (!this.dragdrop)
            this.dragdrop = {};
        if (!this.dragdrop[xmlNode[apf.TAGNAME]])
            this.dragdrop[xmlNode[apf.TAGNAME]] = [xmlNode];
        else
            this.dragdrop[xmlNode[apf.TAGNAME]].push(xmlNode);
    };
    
    /**
     * @private
     */
    this.addDragDrop = function(rules, xmlNode){
        this.dragdrop    = rules;//apf.getRules(xmlNode);
        this.xmldragdrop = xmlNode;
        
        //if (!apf.isParsing)
            //this.markForUpdate(null, "dragdrop");
    };
    
    /**
     * @private
     */
    this.setModel = function(model, xpath){
        if (typeof model == "string")
            model = apf.nameserver.get("model", model);
        
        this.model          = apf.nameserver.register("model", this.name, model);
        this.modelBaseXpath = xpath;
        
        var amlNode;
        for (var uniqueId in this.amlNodes) {
            amlNode = this.amlNodes[uniqueId];
            this.model.unregister(amlNode);
            this.model.register(amlNode, this.$modelXpath[amlNode.getHost
                ? amlNode.getHost().uniqueId
                : amlNode.uniqueId] || this.modelBaseXpath); //this is a hack.. by making Models with links to other models possible, this should not be needed
            //this.amlNodes[uniqueId].load(this.model);
        }
    };
    
    /**
     * Loads xml data in the model of this smartbinding element.
     * 
     * @param  {mixed}  xmlNode the {@link term.datanode data node} loaded into
     * the model of this smartbinding element. This can be an XMLElement, a 
     * string or null. 
     * @private
     */
    this.load = function(xmlNode){
        this.setModel(new apf.model().load(xmlNode));
    };
    
    /**
     * @private
     *
     * @attribute {String} bindings the id of the bindings element that contains 
     * the {@link term.binding binding rules} for all elements connected to 
     * this smartbinding element
     * Example:
     * <code>
     *  <a:smartbinding id="sbExample" bindings="bndExample" />
     * </code>
     * @see element.bindings
     * @see term.binding
     * @see term.smartbinding
     *
     * @attribute {String} actions  the id of the actions element that provides 
     * the {@link term.action action rules} for all elements connected to 
     * this smartbinding element
     * Example:
     * <code>
     *  <a:smartbinding id="sbExample" bindings="actExample" />
     * </code>
     * @see element.actions
     * @see term.action
     * @see term.smartbinding
     *
     * @attribute {String} dragdrop the id of the dragdrop element that provides 
     * the drag and drop rules for all elements connected to this smartbinding 
     * element
     * Example:
     * <code>
     *  <a:smartbinding id="sbExample" dragdrop="ddExample" />
     * </code>
     * @see element.dragdrop
     * @see term.smartbinding
     *
     * @attribute {String} model    the id of the model element that provides 
     * the data for all elements connected to this smartbinding element.
     * Example:
     * <code>
     *  <a:smartbinding id="sbExample" model="mdlExample" />
     * </code>
     * @see element.model
     * @see term.smartbinding
     *
     * @define bindings element containing all the binding rules for the data 
     * bound elements referencing this element.
     * Example:
     * <code>
     *  <a:bindings id="bndFolders" >
     *      <a:caption select="@name" />
     *      <a:icon select="@icon" />
     *      <a:traverse select="folder" sort="@name" />
     *  </a:bindings>
     *
     *  <a:tree bindings="bndFolders" />
     * </code>
     * @see element.smartbinding
     * @allowchild {bindings}
     * @addnode smartbinding, global
     * @define actions  element containing all the action rules for the data 
     * bound elements referencing this element.
     * Example:
     * <code>
     *  <a:actions id="actPerson" >
     *      <a:add set="rpc:comm.addPerson({.})">
     *          <person name="New person" />
     *      </a:add
     *      <a:rename set="rpc.comm.renamePerson({@id}, {@name})" />
     *      <a:remove select="@new" set="rpc:comm.removePerson({@id})"/>
     *  </a:actions>
     *
     *  <a:tree actions="actPerson" />
     * </code>
     * @allowchild {actions}
     * @addnode smartbinding, global
     * @define dragdrop element containing all the dragdrop rules for the data 
     * bound elements referencing this element.
     * Example:
     * This example shows drag and drop rules for a tree with person and
     * office elements. A person can be dragged to an office. An office can be
     * dragged but not dropped within this element. Possible an other element
     * does allow receiving an office element.
     * <code>
     *  <a:dragdrop>
     *      <a:allow-drag select="person|office" /> 
     *      <a:allow-drop select="person" target="office" 
     *          operation="tree-append" copy-condition="event.ctrlKey" /> 
     *  </a:dragdrop>
     * </code>
     * @allowchild allow-drag, allow-drop
     * @addnode smartbinding, global
     * @define ref      shorthand for the default binding rule
     * @addnode smartbinding
     * @define action   shorthand for the default action rule.
     * @addnode smartbinding
     */
    var known = {
        actions  : "addActions",
        bindings : "addBindings",
        dragdrop : "addDragDrop"
    };

    this.loadAml = function(xmlNode){
        this.name = xmlNode.getAttribute("id");
        this.$aml  = xmlNode;

        var name, attr = xmlNode.attributes, l = attr.length;
        for (var i = 0; i < l; i++) {
            name = attr[i].nodeName;
            if (name == "model")
                continue;
            
            if (!known[name])
                continue;
            
            //#ifdef __DEBUG
            if (!apf.nameserver.get(name, attr[i].nodeValue))
                throw new Error(apf.formatErrorString(1036, this, 
                    "Connecting " + name, 
                    "Could not find " + name + " by name '" 
                    + attr[i].nodeValue + "'"));
            //#endif
            
            var cNode = apf.nameserver.get(name, attr[i].nodeValue);
            this[known[name]](apf.getRules(cNode), cNode);
        }

        var data_node, nodes = xmlNode.childNodes;
        for (var i = 0; i < nodes.length; i++) {
            if (nodes[i].nodeType != 1) continue;
    
            switch (nodes[i][apf.TAGNAME]) {
                case "model":
                    data_node = nodes[i];
                    break;
                case "bindings":
                    this.addBindings(apf.getRules(nodes[i]), nodes[i]);
                    break;
                case "actions":
                    this.addActions(apf.getRules(nodes[i]), nodes[i]);
                    break;
                case "dragdrop":
                    this.addDragDrop(apf.getRules(nodes[i]), nodes[i]);
                    break;
                case "ref":
                    this.addBindRule(nodes[i]);
                    break;
                case "action":
                    this.addActionRule(nodes[i]);
                    break;
                default:
                    throw new Error(apf.formatErrorString(1039, this, 
                        "setSmartBinding Method", 
                        "Could not find handler for '" 
                        + nodes[i].tagName + "' node."));
                    break;
            }
        }
        
        //Set Model
        if (data_node)
            this.setModel(new apf.model().loadAml(data_node));
        else if (xmlNode.getAttribute("model"))
            apf.setModel(xmlNode.getAttribute("model"), this);
    };
    
    if (xmlNode)
        this.loadAml(xmlNode);
};

// #endif

