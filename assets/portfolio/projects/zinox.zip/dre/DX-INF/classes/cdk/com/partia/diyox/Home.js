com.partia.diyox.Home = function com$partia$diyox$Home(){
		/*<init class="com.partia.diyox.Home"
			version="0.0.1a"
			author="Mehran Hatami"
			createdate="2009/03/01"
			modifieddate="2009/03/01" />*/
};
com.partia.diyox.Home.prototype = {
    init : function com$partia$diyox$Home$init(){
        var $t = this;
        /*_.dre.bordercell2.onmousedown.add(function(e){
        	_.dragger.doResizeV(e , this ,[_.dre.cell11,_.dre.cell12],1);
        });
         _.dre.bordercell3.onmousedown.add(function(e){
        	_.dragger.doResizeV(e , this ,_.dre.cell21,1);
        });*/
    }
};
if(!_.dre) _.dre={};
_.dre.home = new com.partia.diyox.Home();
