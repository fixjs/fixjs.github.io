com.partia.diyox.runtime.Loader = function com$partia$diyox$runtime$Loader(){
		/*<init class="com.partia.diyox.runtime.Loader"
			version="0.0.1a"
			author="Mehran Hatami"
			createdate="2009/03/01"
			modifieddate="2009/03/01" />*/
};
com.partia.diyox.runtime.Loader.prototype = {
    init : function com$partia$diyox$runtime$Loader$init(){
        var $t = this;
        window.status = "Init com.partia.diyox.runtime Successfully!";
    }
};
if(!_.dre) _.dre={};
_.dre.loader = new com.partia.diyox.runtime.Loader();
