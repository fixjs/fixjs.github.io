com.partia.dario.secretariat.ws.Proxy = function com$partia$dario$secretariat$ws$Proxy(){
    /*<init class="com.partia.dario.secretariat.ws.Proxy"
			version="0.0.1a"
			author="Saeed Yousefi"
			createdate="2009/05/25"
			modifieddate="2009/05/26" />*/


    $t.adapter = null;
    $t.isStarted = false;
    //  wsImport("http://192.168.0.152:8086/Secretariat/SecretariatServiceReference.svc?wsdl");
    var wsdlLocation =_.ns.getPath("com.partia.dario.ws.SecretariatService","wsdl");
    wsImport(wsdlLocation,null,function(){
        $t.adapter =new Partia.Dario.Secretariat.Services.ServiceContract.SecretariatServiceClassClient();
       
        $t.informationData = new Partia.Dario.Secretariat.Services.DataContract.InformationData();
        $t.resultInfo = new Partia.Dario.Secretariat.Services.DataContract.GetResultInfo();

        //default header***********************************
        $t.informationData.userName.set(new zinox.xml.schema.String('ali'));
        $t.informationData.password.set(new zinox.xml.schema.String('5FA285E1BEBE0A6623E33AFC04A1FBD5'));
        $t.informationData.clientCulture.set(Partia.Dario.Secretariat.Services.DataContract.ClientCulture.en_US)
        $t.informationData.digitalSignature.set(new zinox.xml.schema.String(''));

        $t.resultInfo.mode.set(new zinox.xml.schema.Int(1));
        var start = new zinox.xml.schema.Int();
        start.value.set(0);
        $t.resultInfo.start.set(start);

    } );
  
};

com.partia.dario.secretariat.ws.Proxy.prototype={

    getGuid : function(value){
        var guid = new Partia.Dario.Secretariat.Services.DataContract.Guid();
        guid.value.set(value);
        return guid;
    }
    
   
}
_.secretariatService = new com.partia.dario.secretariat.ws.Proxy();




//testing methods
//test methods***********************************************************************************************
    //getOneAssignment()  test ok
    //_.secretariatService.adapter.getOneAssignment(_.secretariatService.informationData,'96ce8cc8-a123-de11-9f45-001fd0ad2780',function(res){window['qw']=res;});

    //getDocumentDocumentLock  test ok; ###############################################################################################################################
    //_.secretariatService.adapter.getDocumentDocumentLock(_.secretariatService.informationData,'9eb966d9-9110-de11-b038-001fd0ad2780',function(res){window['qw']=res;});


    //not header in responsxml but
    //addPriority errMessage='don't find respons data contract'######################################################
    //_.secretariatService.adapter.getOneDocumentRelationship(_.secretariatService.informationData,'9486e1fb-5637-de11-aaa8-001fd0ad2780',function(res){window['qw']=res;});
    //_req.response.XML.xml='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetOneDocumentRelationshipData xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:a="urn:Partia.Dario.Secretariat.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:Id>9486e1fb-5637-de11-aaa8-001fd0ad2780</a:Id><a:documentId>24be2b25-4537-de11-aaa8-001fd0ad2780</a:documentId><a:documentRelatedId>24be2b25-4537-de11-aaa8-001fd0ad2780</a:documentRelatedId><a:documentNumber>22</a:documentNumber><a:documentRelatedNumber>22</a:documentRelatedNumber><a:discriminator>Next</a:discriminator><a:documentDiscriminator>Next</a:documentDiscriminator><a:documentRelatedRegistrationDate>1</a:documentRelatedRegistrationDate><a:documentRegistrationDate>1</a:documentRegistrationDate><a:documentRelatedDiscriminator>Next</a:documentRelatedDiscriminator></GetOneDocumentRelationshipData></s:Body></s:Envelope>'
    //mainres=              '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetOneDocumentRelationshipData xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:a="urn:Partia.Dario.Secretariat.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:Id>9486e1fb-5637-de11-aaa8-001fd0ad2780</a:Id><a:documentId>24be2b25-4537-de11-aaa8-001fd0ad2780</a:documentId><a:documentRelatedId>24be2b25-4537-de11-aaa8-001fd0ad2780</a:documentRelatedId><a:documentNumber>22</a:documentNumber><a:documentRelatedNumber>22</a:documentRelatedNumber><a:discriminator>Next</a:discriminator><a:documentDiscriminator>Next</a:documentDiscriminator><a:documentRelatedRegistrationDate>1</a:documentRelatedRegistrationDate><a:documentRegistrationDate>1</a:documentRegistrationDate><a:documentRelatedDiscriminator>Next</a:documentRelatedDiscriminator></GetOneDocumentRelationshipData></s:Body></s:Envelope>'

    //test getAllDocumentGroup not ok; request envelop is empty ###############################################################################################################################
    //_.secretariatService.adapter.getAllDocumentGroup(_.secretariatService.informationData,_.secretariatService.resultInfo,function(res){window['qw']=res;});



    //test getDocumentAttachment; add success but  errMessage='the server was unable to prossess the request to an internal err'#############################################################################################################################################
    //_.secretariatService.adapter.getDocumentAttachment(_.secretariatService.resultInfo, _.secretariatService.informationData,'8cce8cc8-a123-de11-9f45-001fd0ad2780' ,function(res){window['qw']=res;});
    //_req.response.XML.xml='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><getDocumentAttachmentData xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:a="urn:Partia.Dario.Secretariat.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:GetDocumentAttachmentList><a:Id>8fce8cc8-a123-de11-9f45-001fd0ad2780</a:Id><a:documentId>8cce8cc8-a123-de11-9f45-001fd0ad2780</a:documentId><a:assignmentStateId>00000000-0000-0000-0000-000000000000</a:assignmentStateId><a:name>01.txt</a:name><a:path>C:\Dario\SecretariatApp\Tests\SecretariatApp.Host\Attachment\dfd4c37dd9f3845a.txt</a:path><a:code>dfd4c37dd9f3845a</a:code><a:order>1</a:order><a:content>Q01NX1Jlc3VsdERhdGFJbmZvIGdldFJlc3VsdEluZm8gPSBuZXcgQ01NX1Jlc3VsdERhdGFJbmZvKDEsIENvbmZpZ3VyYXRpb25EYXRhLmdldFNlbGVjdFJvd1BlclBhZ2UoIlJvd1BlclBhZ2VEb2N1bWVudEF0dGFjaG1lbnQiKSwgMSk7DQogICAgICAgICAgICAgICAgTGlzdDxTUlRfRG9jdW1lbnRBdHRhY2htZW50RGV0YWlsVmlldz4gYXR0YWNobWVudExpc3QgPSBhdHRhY2htZW50QWRhcHRlci5nZXRBc3NpZ25tZW50QXR0YWNobWVudChhc3NpZ25tZW50SWQsIGdldFJlc3VsdEluZm8pOw0KICAgICAgICAgICAgICAgIGZvciAoaW50IGkgPSAwOyBpIDwgYXR0YWNobWVudExpc3QuQ291bnQ7IGkrKykNCiAgICAgICAgICAgICAgICB7DQogICAgICAgICAgICAgICAgICAg</a:content><a:desc>desc1</a:desc><a:discriminator>Document</a:discriminator><a:type>Content</a:type><a:xslId>0</a:xslId><a:mimeType>text/plain</a:mimeType><a:xslName i:nil="true"/><a:xslPath i:nil="true"/><a:xslCode i:nil="true"/></a:GetDocumentAttachmentList></getDocumentAttachmentData></s:Body></s:Envelope>'
    //mainres=              '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><getDocumentAttachmentData xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:a="urn:Partia.Dario.Secretariat.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:GetDocumentAttachmentList><a:Id>8fce8cc8-a123-de11-9f45-001fd0ad2780</a:Id><a:documentId>8cce8cc8-a123-de11-9f45-001fd0ad2780</a:documentId><a:assignmentStateId>00000000-0000-0000-0000-000000000000</a:assignmentStateId><a:name>01.txt</a:name><a:path>C:\Dario\SecretariatApp\Tests\SecretariatApp.Host\Attachment\dfd4c37dd9f3845a.txt</a:path><a:code>dfd4c37dd9f3845a</a:code><a:order>1</a:order><a:content>Q01NX1Jlc3VsdERhdGFJbmZvIGdldFJlc3VsdEluZm8gPSBuZXcgQ01NX1Jlc3VsdERhdGFJbmZvKDEsIENvbmZpZ3VyYXRpb25EYXRhLmdldFNlbGVjdFJvd1BlclBhZ2UoIlJvd1BlclBhZ2VEb2N1bWVudEF0dGFjaG1lbnQiKSwgMSk7DQogICAgICAgICAgICAgICAgTGlzdDxTUlRfRG9jdW1lbnRBdHRhY2htZW50RGV0YWlsVmlldz4gYXR0YWNobWVudExpc3QgPSBhdHRhY2htZW50QWRhcHRlci5nZXRBc3NpZ25tZW50QXR0YWNobWVudChhc3NpZ25tZW50SWQsIGdldFJlc3VsdEluZm8pOw0KICAgICAgICAgICAgICAgIGZvciAoaW50IGkgPSAwOyBpIDwgYXR0YWNobWVudExpc3QuQ291bnQ7IGkrKykNCiAgICAgICAgICAgICAgICB7DQogICAgICAgICAgICAgICAgICAg</a:content><a:desc>desc1</a:desc><a:discriminator>Document</a:discriminator><a:type>Content</a:type><a:xslId>0</a:xslId><a:mimeType>text/plain</a:mimeType><a:xslName i:nil="true"/><a:xslPath i:nil="true"/><a:xslCode i:nil="true"/></a:GetDocumentAttachmentList></getDocumentAttachmentData></s:Body></s:Envelope>';

    
    //addPriority errMessage='don't find respons data contract'#############################################################################################################################################
    //inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.AddPriorityData
    // inputEntity.name.set(new zinox.xml.schema.String("test789"));
    //_.secretariatService.adapter.addPriority(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});
    //_req.response.XML.xml='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><h:AddPriorityMessageInfoOut xmlns:h="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><messageFlag xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">custom</messageFlag><message xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">عملیات اضافه کردن اولویت با موفقیت انجام شد.</message><code xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">srt-107</code></h:AddPriorityMessageInfoOut></s:Header><s:Body><AddPriorityOutput xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract"/></s:Body></s:Envelope>"
    //mainRes=              '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><h:AddPriorityMessageInfoOut xmlns:h="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><messageFlag xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">custom</messageFlag><message xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">عملیات اضافه کردن اولویت با موفقیت انجام شد.</message><code xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">srt-107</code></h:AddPriorityMessageInfoOut></s:Header><s:Body><AddPriorityOutput xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract"/></s:Body></s:Envelope>

    //test addSensitivity() not ok; errMessage='don't find respons data contract'#############################################################################################################################################
    //inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.AddSensitivityData
    // inputEntity .name.set(new zinox.xml.schema.String("test"));
    //_.secretariatService.adapter.addSensitivity(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});


     //editAssignement errMessage='don't find respons data contract'#############################################################################################################################################
//    inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.EditAssignementData
//    inputEntity.priorityId.set((new zinox.xml.schema.Int(1)));
//    inputEntity.id.set(_.secretariatService.getGuid('84ce8cc8-a123-de11-9f45-001fd0ad2780'));
//    inputEntity.estimateTime.set(new zinox.xml.schema.DateTime("2009-05-09T10:31:11"));
//    inputEntity .subject.set(new zinox.xml.schema.String("test"));
//    _.secretariatService.adapter.editAssignement(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});
 //_req.response.XML.xml='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><h:editAssignementMessageInfoOut xmlns:h="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><messageFlag xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">custom</messageFlag><message xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">ویرایش ارجاع مورد نظر با موفقیت انجام شد.</message><code xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">srt-158</code></h:editAssignementMessageInfoOut></s:Header><s:Body/></s:Envelope>'


    //editDocumentGroup errMessage='don't find respons data contract'#############################################################################################################################################
    // inputEntity = new Partia.Dario.Secretariat.Services.DataContract.EditDocumentGroupData
    // inputEntity.documentGroupId.set((new zinox.xml.schema.Int(1)));
    // inputEntity.id.set((new zinox.xml.schema.Int(1)));
    // inputEntity.documentGroupNumberingId.set((new zinox.xml.schema.Int(3)));
    // inputEntity.desc..set((new zinox.xml.schema.String("TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT")));
    // inputEntity.code.set((new zinox.xml.schema.String("13")));
    // inputEntity.name.set((new zinox.xml.schema.String("13")));
    //_.secretariatService.adapter.editDocumentGroup(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});


    //test changeOrderPrioritynot ok; errMessage='don't find respons data contract'#############################################################################################################################################
    //inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.ChangeOrderPriorityData
    // inputEntity .id.set(new zinox.xml.schema.Int(9));
    // inputEntity .order.set(new zinox.xml.schema.Int(11));
    //_.secretariatService.adapter.changeOrderPriority(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});


    //test ChangeFinalState; not ok; errMessage='don't find respons data contract'#############################################################################################################################################
    //inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.ChangeFinalStateData
    //inputEntity.documentId.set(_.secretariatService.getGuid('156f44c8-8e23-de11-9f45-001fd0ad2780'));
    //inputEntity.isFinalState.set(new zinox.xml.schema.Boolean(true));
    //_.secretariatService.adapter.ChangeFinalState(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});


   //test lockDocument ok; errMessage='don't find respons data contract'#############################################################################################################################################
    //inputEntity  = new Partia.Dario.Secretariat.Services.DataContract.LockDocumentData
    // inputEntity.documentId.set(_.secretariatService.getGuid('24be2b25-4537-de11-aaa8-001fd0ad2780'));
    // inputEntity.expireDate.set(new zinox.xml.schema.DateTime("2009-05-09T10:31:11"));
    //_.secretariatService.adapter.lockDocument(_.secretariatService.informationData,inputEntity  ,function(res){window['qw']=res;});


    
   //test removePriority not ok; don't find respons data contract ###############################################################################################################################
    //_.secretariatService.adapter.removePriority(_.secretariatService.informationData,1,function(res){window['qw']=res;});

