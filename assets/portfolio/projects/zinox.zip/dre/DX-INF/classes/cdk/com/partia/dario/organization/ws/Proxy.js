com.partia.dario.organization.ws.Proxy = function com$partia$dario$organization$ws$Proxy(){
    /*<init class="com.partia.dario.organization.ws.Proxy"
			version="0.0.1a"
			author="Saeed Yousefi"
			createdate="2009/06/07"
			modifieddate="2009/06/07" />*/


    $t.adapter = null;
    $t.isStarted = false;
    //  wsImport("http://dario-server.mbo.partia.net:8086/organization/OrganizationServiceReference.svc?wsdl");
    wsdlLocation =_.ns.getPath("com.partia.dario.ws.OrganizationService","wsdl");
    wsImport(wsdlLocation,null,function(){
        if(Toloo && !window.Partia) Partia=Toloo;
        $t.adapter =new Partia.Dario.Organization.Services.ServiceContract.OrganizationServiceClassClient();
       
            $t.informationData = new Partia.Dario.Organization.Services.DataContract.InformationData();
        

        //default header***********************************
        $t.informationData.userName.set(new zinox.xml.schema.String('ali'));
        $t.informationData.password.set(new zinox.xml.schema.String('5FA285E1BEBE0A6623E33AFC04A1FBD5'));
        $t.informationData.clientCulture.set(new zinox.xml.schema.String('EN'));
        $t.informationData.digitalSignature.set(new zinox.xml.schema.String(''));
    } );
  
};

com.partia.dario.organization.ws.Proxy.prototype={
    getGuid : function(value){
        var guid = new Partia.Dario.Secretariat.Services.DataContract.Guid();
        guid.value.set(value);
        return guid;
    }
}
_.organizationProxy = new com.partia.dario.organization.ws.Proxy();




//testing methods
//test methods***********************************************************************************************
    //getAllPost: test not ok,    envelop body is empty
    //_.organizationProxy.adapter.getAllPost(function(res){window['qw']=res;});
    //FiddlerRequest='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><h:informationData xmlns:h="urn:Toloo.Dario.Organization.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Toloo.Dario.Organization.Services.DataContract">ali</userName><clientCulture xmlns="urn:Toloo.Dario.Organization.Services.DataContract">FA</clientCulture><password xmlns="urn:Toloo.Dario.Organization.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Toloo.Dario.Organization.Services.DataContract"/></h:informationData></s:Header><s:Body/></s:Envelope>'
    // __reqDoc.xml= '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body/></soap:Envelope>'
    
   //getOneUnit test not ok ; ###############################################################################################################################
    //_.organizationProxy.adapter.getOneUnit(_.organizationProxy.informationData,1,function(res){window['qw']=res;});
    //FiddlerRequest='<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header><h:informationData xmlns:h="urn:Toloo.Dario.Organization.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Toloo.Dario.Organization.Services.DataContract"   >ali</userName><clientCulture xmlns="urn:Toloo.Dario.Organization.Services.DataContract">EN</clientCulture><password xmlns="urn:Toloo.Dario.Organization.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Toloo.Dario.Organization.Services.DataContract"/></h:informationData></s:Header><s:Body><unitIdValue xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">1</unitIdValue></s:Body></s:Envelope>'
    // __reqDoc.xml= '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header><  InformationData xmlns=  "urn:Toloo.Dario.Organization.Services.DataContract"                                                       ><userName xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">ali</userName><clientCulture xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">fa_IR</clientCulture><password xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract"></digitalSignature></InformationData></soap:Header><soap:Body><GetOneUnitInput xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">1</GetOneUnitInput></soap:Body></soap:Envelope>"'
    

//secretriat:   '<s:Header><h:getOneAssignmenttMessageInfoIn xmlns:h="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">ali</userName><ClientCulture xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">fa_IR</ClientCulture><password xmlns="urn:Partia.Dario.Secretariat.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.Secretariat.Services.DataContract"/></h:getOneAssignmenttMessageInfoIn></s:Header><s:Body><GetOneAssignmentInput xmlns="urn:Partia.Dario.Secretariat.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><getOneAssignment_Id>96ce8cc8-a123-de11-9f45-001fd0ad2780</getOneAssignment_Id></GetOneAssignmentInput></s:Body></s:Envelope>'
//role managment <s:Header><h:setUserActivityMesssageInfoIn xmlns:h="urn:Partia.Dario.RoleManagement.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.RoleManagement.Services.DataContract">'+$t.userName+'</userName><ClientCulture xmlns="urn:Partia.Dario.RoleManagement.Services.DataContract">'+$t.clientCulture+'</ClientCulture><password xmlns="urn:Partia.Dario.RoleManagement.Services.DataContract">'+$t.password+'</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.RoleManagement.Services.DataContract"/></h:setUserActivityMesssageInfoIn></s:Header><s:Body><SetUserActivityInput xmlns="urn:Partia.Dario.RoleManagement.Services.ServiceContract"><setUserActivityData xmlns:a="urn:Partia.Dario.RoleManagement.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:userId>'+userId+'</a:userId><a:isActive>'+isActive+'</a:isActive></setUserActivityData></SetUserActivityInput></s:Body></s:Envelope>';
//organization  '<s:Header><h:informationData xmlns:h="urn:Toloo.Dario.Organization.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Toloo.Dario.Organization.Services.DataContract">ali</userName><clientCulture xmlns="urn:Toloo.Dario.Organization.Services.DataContract">EN</clientCulture><password xmlns="urn:Toloo.Dario.Organization.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Toloo.Dario.Organization.Services.DataContract"/></h:informationData></s:Header><s:Body><unitIdValue xmlns="urn:Toloo.Dario.Organization.Services.ServiceContract">1</unitIdValue></s:Body></s:Envelope>'
//common        '<s:Header><h:getAttachmentFileMessageInfoIn xmlns:h="urn:Partia.Dario.Contact.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">'+ $t.userName+'</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">'+ $t.clientCulture+'</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">'+ $t.password+'</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.Contact.Services.DataContract"/></h:getAttachmentFileMessageInfoIn></s:Header><s:Body><GetAttachmentFileInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"><attachmentId>'+attachmentId+'</attachmentId></GetAttachmentFileInput></s:Body>';
