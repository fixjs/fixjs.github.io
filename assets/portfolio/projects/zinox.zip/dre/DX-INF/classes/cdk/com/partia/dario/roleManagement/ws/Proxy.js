com.partia.dario.roleManagement.ws.Proxy = function com$partia$dario$roleManagement$ws$Proxy(){
    /*<init class="com.partia.dario.roleManagement.ws.Proxy"
			version="0.0.1a"
			author="Saeed Yousefi"
			createdate="2009/06/07"
			modifieddate="2009/06/07" />*/


    //  wsImport("http://dario-server.mbo.partia.net:8086/rolemanagement/RoleManagementServiceReference.svc?wsdl");
    var wsdlLocation =_.ns.getPath("com.partia.dario.ws.RoleManagementServiceService","wsdl");
    wsImport(wsdlLocation,null,function(){
        $t.adapter =new Partia.Dario.RoleManagement.Services.ServiceContract.RoleManagementServiceClassClient();
       
        $t.informationData = new Partia.Dario.RoleManagement.Services.DataContract.InformationData();
        $t.resultInfo = new Partia.Dario.Secretariat.Services.DataContract.GetResultInfo();

        //default header***********************************
        $t.informationData.userName.set(new zinox.xml.schema.String('ali'));
        $t.informationData.password.set(new zinox.xml.schema.String('5FA285E1BEBE0A6623E33AFC04A1FBD5'));
        $t.informationData.clientCulture.set(Partia.Dario.RoleManagement.Services.DataContract.ClientCulture.fa_IR)
        $t.informationData.digitalSignature.set(new zinox.xml.schema.String());

        $t.resultInfo.mode.set(new zinox.xml.schema.Int(1));
        
        var start=new zinox.xml.schema.Int();
        start.value.set(0);
        $t.resultInfo.start.set(start);
    } );
  
};

com.partia.dario.roleManagement.ws.Proxy.prototype={

    getGuid : function(value){
        var guid = new Partia.Dario.RoleManagement.Services.DataContract.Guid();
        guid.value.set(value);
        return guid;
    }
    
   
}
_.roleManagementProxy = new com.partia.dario.roleManagement.ws.Proxy();




//testing methods
//test methods***********************************************************************************************
    //getAllUser: test not ok,    envelop body is empty
    //_.roleManagementProxy.adapter.getAllUser(_.roleManagementProxy.informationData,_.roleManagementProxy.resultInfo,function(res){window['qw']=res;});
    
   //getOneUnit test not ok ; ###############################################################################################################################
    //_.roleManagementProxy.adapter.getOneUnit(_.roleManagementProxy.informationData,1,function(res){window['qw']=res;});
    
