com.partia.dario.common.ws.Proxy = function com$partia$dario$common$ws$Proxy(){
    /*<init class="com.partia.dario.common.ws.Proxy"
			version="0.0.1a"
			author="Saeed Yousefi"
			createdate="2009/06/07"
			modifieddate="2009/06/07" />*/


    //  wsImport("http://dario-server.mbo.partia.net:8086/common/ContactServiceReference.svc?wsdl");
    var wsdlLocation =_.ns.getPath("com.partia.dario.ws.CommonService","wsdl");
    wsImport(wsdlLocation,null,function(){
        $t.adapter =new Partia.Dario.Contact.Services.ServiceContract.ContactServiceClassClient();
       
        $t.informationData = new Partia.Dario.Contact.Services.DataContract.InformationData();
        $t.resultInfo = new Partia.Dario.Contact.Services.DataContract.GetResultInfo();

        //default header***********************************

        $t.resultInfo.mode.set(new zinox.xml.schema.Int(1));
        $t.resultInfo.start.set(new zinox.xml.schema.Int('0'));
        
        $t.informationData.userName.set(new zinox.xml.schema.String('ali'));
        $t.informationData.password.set(new zinox.xml.schema.String('5FA285E1BEBE0A6623E33AFC04A1FBD5'));
        $t.informationData.clientCulture.set(new zinox.xml.schema.String('EN'))
        $t.informationData.digitalSignature.set(new zinox.xml.schema.String(''));

        
    } );
  
};

com.partia.dario.common.ws.Proxy.prototype={

    getGuid : function(value){
        var guid = new Partia.Dario.Common.Services.DataContract.Guid();
        guid.value.set(value);
        return guid;
    }
    
   
}
_.commonProxy = new com.partia.dario.common.ws.Proxy();




//testing methods
//test methods***********************************************************************************************
    //getAllContact: test not ok,    envelop body is empty
    //_.commonProxy.adapter.getAllContact(_.commonProxy.informationData,_.commonProxy.resultInfo,function(res){window['qw']=res;});
    //fidler.request='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><getContactMessageInfo xmlns="urn:Partia.Dario.Contact.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.Contact.Services.DataContract"/>     </getContactMessageInfo></s:Header><s:Body><GetContactInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><contactId>1</contactId></GetContactInput></s:Body></s:Envelope>'
    //_.reqDoc.xml=  '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><getContactMessageInfo xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"                                                    ><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature xmlns="urn:Partia.Dario.Contact.Services.DataContract"></digitalSignature></getContactMessageInfo></s:Header><s:Body><GetContactInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"                                                    ><contactId>1</contactId></GetContactInput></s:Body></s:Envelope>'

    //getContact test not ok ; ###############################################################################################################################
    //_.commonProxy.adapter.getContact(_.commonProxy.informationData,1,function(res){window['qw']=res;});

    //addAddress test not ok ; ###############################################################################################################################
    // inputdata=new Partia.Dario.Contact.Services.DataContract.AddAddressData();
    // inputdata.contactId.set(new zinox.xml.schema.Int(1));
    // inputdata.geoghraphyId.set(new zinox.xml.schema.Int(11));
    // inputdata.descrition.set(new zinox.xml.schema.String('ghttttttttttttttttt'));
    // inputdata.isDefault.set(new zinox.xml.schema.Boolean(true));
    // inputdata.postalCode.set(new zinox.xml.schema.String('99'));
    // inputdata.street.set(new zinox.xml.schema.String('street'));
    // _.commonProxy.adapter.addAddress(_.commonProxy.informationData,inputdata,function(res){window['qw']=res;});

   //fidler.request='<s:Envelope xmlns:s="http://schemas.xmls.org/s/envelope/"><Header><addAddressMessageInfoIn xmlns="urn:Partia.Dario.Contact.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.Contact.Services.DataContract"/>     </addAddressMessageInfoIn></Header><s:Body><AddAddressInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"><addAddressData xmlns:a="urn:Partia.Dario.Contact.Services.DataContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><a:contactId                                                    >1</a:contactId><a:geoghraphyId>11</a:geoghraphyId><a:street>shahrak</a:street><a:postalCode>99</a:postalCode><a:descrition>descAdd</a:descrition><a:isDefault>true</a:isDefault><a:AddressDiscriminator>Home</a:AddressDiscriminator></addAddressData></AddAddressInput></s:Body></s:Envelope>
   //_.reqDoc.xml=  '<s:Envelope xmlns:s="http://schemas.xmls.org/s/envelope/"><Header><addAddressMessageInfoIn xmlns="urn:Partia.Dario.Contact.Services.ServiceContract">                                                    <userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature xmlns="urn:Partia.Dario.Contact.Services.DataContract"></digitalSignature></addAddressMessageInfoIn></Header><s:Body><AddAddressInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"><addAddressData                                                                                                             ><contactId xmlns="urn:Partia.Dario.Contact.Services.DataContract">1</contactId><geoghraphyId xmlns="urn:Partia.Dario.Contact.Services.DataContract">11</geoghraphyId><street xmlns="urn:Partia.Dario.Contact.Services.DataContract">street</street><postalCode xmlns="urn:Partia.Dario.Contact.Services.DataContract">99</postalCode><descrition xmlns="urn:Partia.Dario.Contact.Services.DataContract">ttttttttt</descrition><isDefault xmlns="urn:Partia.Dario.Contact.Services.DataContract">true</isDefault></addAddressData></AddAddressInput></s:Body></s:Envelope>"'

   ////removeAddress test not ok ; ###############################################################################################################################
   //_.commonProxy.adapter.removeAddress(_.commonProxy.informationData,32,function(res){window['qw']=res;});
   //fidler.request='<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><removeAddressMessageInfoIn xmlns="urn:Partia.Dario.Contact.Services.ServiceContract" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature i:nil="true" xmlns="urn:Partia.Dario.Contact.Services.DataContract"/>     </removeAddressMessageInfoIn></s:Header><s:Body><RemoveAddressInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"><removeAddressId>32</removeAddressId></RemoveAddressInput></s:Body></s:Envelope>'
   //_.reqDoc.xml=  '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><removeAddressMessageInfoIn xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"                                                    ><userName xmlns="urn:Partia.Dario.Contact.Services.DataContract">ali</userName><clientCulture xmlns="urn:Partia.Dario.Contact.Services.DataContract">EN</clientCulture><password xmlns="urn:Partia.Dario.Contact.Services.DataContract">5FA285E1BEBE0A6623E33AFC04A1FBD5</password><digitalSignature xmlns="urn:Partia.Dario.Contact.Services.DataContract"></digitalSignature></removeAddressMessageInfoIn></s:Header><s:Body><RemoveAddressInput xmlns="urn:Partia.Dario.Contact.Services.ServiceContract"><removeAddressId>32</removeAddressId></RemoveAddressInput></s:Body></s:Envelope>