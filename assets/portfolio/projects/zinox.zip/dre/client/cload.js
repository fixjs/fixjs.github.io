//core lang
window.zino = {
  core: {},
  localization: {},
  collections: {},
  handles: [],
  io: {},
  util: {},
  net: {},
  config: {
    "nocache": true
  },
  lang: {},
  ui: {
    drawing: {},
    styling: {}
  }
};
Function.prototype.inherit = function Function$inherit(s) {
  if (!(s instanceof Function)) {
    throw new Error("Cannot inherit from " + s);
  }
  try {
    this.prototype = new s;
    this.constructor = this.prototype.constructor = this;
    this.superClass = s;
    return this;
  } catch (e) {
    throw new Error("Error on inheriting." + e);
  }
};
setType = function setType(o, t, ts) {
  if (typeof (t) == "string") {
    if (!ts) ts = t;
    t = eval(t);
  };
  o.__type__ = t;
  if (ts) o.toString = function Object$toString() {
    return "[object " + ts + "]";
  }
};
zino.getHandle = function zino$getHandle(obj) {
  if (typeof obj != "object" && typeof obj != "function") throw new Error("Cannot retrive invalid argument!");
  var hid;
  try {
    if (!obj.attributes) {
      if ((hid = obj.__HANDLE_ID__) === undefined || (hid === null)) hid = obj.__HANDLE_ID__ = zino.handles.push(obj) - 1;
    } else {
      if ((hid = obj.getAttribute("__HANDLE_ID__")) === null) obj.setAttribute("__HANDLE_ID__", hid = zino.handles.push(obj) - 1);
    }
  } catch (e) {
    throw new Error("zino.getHandle , " + (e.message || e));
  }
  return hid;
};
zino.getObject = function zino$getObject(hid) {
  if (!zino.handles[hid]) throw new Error("Invalid handle!");
  return zino.handles[hid];
};
var _ = window._ = new Object();
zino.lang.Object = function zino$lang$Object() {
  setType(this, "zino.lang.Object");
};
zino.lang.Object.prototype = {
  equals: function zino$lang$Object$equals(object) {
    return (this == object);
  },
  getType: function zino$lang$Object$equals() {
    return (this.__type__);
  },
  getClassName: function zino$lang$Object$getClassName() {
    try {
      return (this + "").split("[object")[1].trim().replace("]", "");
    } catch (err) {
      return "zino.lang.Object";
    }
  }
};
zino.lang.Variant = function zino$Variant() {
  this._TYPE = "zino.Variant";
};
zino.lang.Enum = function zino$Enum(ps, cf) {
  var $t = this;
  $t._i = 0;
  $t._hc = false;
  $t._ps = [];
  if (ps) {
    if (ps instanceof Array)
      for (var i = 0; i < ps.length; i++) $t.add(ps[i]);
    else {
      if (ps instanceof Object)
        for (var i in ps) $t.add(i, ps[i]);
      else throw new Error("invalid input argument!");
    }
  }
  if (cf) $t.setf(cf);
};
zino.lang.Enum.prototype = {
  setf: function zino$Enum$setf(v) {
    var $t = this;
    $t._hc = v ? true : false;
    $t.constructor = v;
    if ($t._hc)
      for (var i = 0; i < $t._ps.length; i++) {
        var p = $t._ps[i];
        if (!p.isf) {
          p.isf = true;
          $t[p.name] = $t.makef(p.value);
        }
      } else
        for (var i = 0; i < $t._ps.length; i++) {
          var p = $t._ps[i];
          if (!p.isf) {
            p.isf = false;
            $t[p.name] = p.value || p._i;
          }
        }
  },
  add: function zino$Enum$add(n, v) {
    var $t = this;
    if (this._hc && v) this[n] = $t.makef(v);
    else this[n] = v ? v : this._i++;
    this._ps.push({
      name: n,
      value: v,
      _i: this._i,
      isf: this._hc
    });
    return this[n];
  },
  makef: function zino$Enum$makef(v) {
    var $t = this;
    return function () {
      return $t.constructor(v);
    }
  },
  remove: function zino$Enum$remove(n) {
    if (this._hc) {
      delete this[n];
      for (var i = 0; i < this._ps.length; i++)
        if (this._ps[i].name == n) this._ps.splice(i, 1);
    }
  }
};
zino.lang.Exception = function zino$Exception(message, objects, exp, title, fileName, lineNumber) {
  this._TYPE = "zino.lang.Exception";
  if (exp && exp instanceof zino.lang.Exception) {
    this.title = exp.title;
    this.message = exp.message;
    this.fileName = exp.fileName;
    this.lineNumber = exp.lineNumber;
    this.objects = exp.objects;
    this.Exception = exp.Exception;
    this.stacks = exp.stacks;
    this.stacks.push(new zino.lang.Exception(message, objects, null, title, fileName, lineNumber));
  } else {
    this.title = "";
    this.message = message ? message : (exp && (exp.message || exp)) + "";
    this.objects = objects;
    this.Exception = exp ? exp : null;
    this.fileName = (fileName ? fileName : (exp ? exp.fileName : "")) + "";
    this.lineNumber = (lineNumber ? lineNumber : (exp ? exp.lineNumber : -1)) * 1;
    this.stacks = [];
    this.title = title;
  };
  this.toString = function zino$Exception$toString() {
    return "Title: " + this.title + "\r\nMessage: " + this.message + "\r\nFilename: " + this.fileName + "\r\nLine number: " + this.lineNumber + "\r\nError handle: " + zino.getHandle(this);
  };
  return this.toString();
};
zino.util.Browser = function zino$Browser() {}.inherit(zino.lang.Object);
zino.util.Browser.navigators = [{
  string: navigator.vendor,
  indexWord: "Apple",
  identity: "Safari"
}, {
  prop: window.opera,
  identity: "Opera"
}, {
  string: navigator.vendor,
  indexWord: "iCab",
  identity: "iCab"
}, {
  string: navigator.vendor,
  indexWord: "KDE",
  identity: "Konqueror"
}, {
  string: navigator.userAgent,
  indexWord: "Firefox",
  identity: "Firefox"
}, {
  string: navigator.userAgent,
  indexWord: "Netscape",
  identity: "Netscape"
}, {
  string: navigator.userAgent,
  indexWord: "MSIE",
  identity: "InternetExplorer",
  versionSearch: "MSIE"
}, {
  string: navigator.userAgent,
  indexWord: "Gecko",
  identity: "Mozilla",
  versionSearch: "rv"
}, {
  string: navigator.userAgent,
  indexWord: "Mozilla",
  identity: "Netscape",
  versionSearch: "Mozilla"
}];
zino.util.Browser.operatingSystems = [{
  string: navigator.platform,
  indexWord: "Win",
  identity: "Windows"
}, {
  string: navigator.platform,
  indexWord: "Mac",
  identity: "Mac"
}, {
  string: navigator.platform,
  indexWord: "FreeBSD",
  identity: "FreeBSD"
}, {
  string: navigator.platform,
  indexWord: "Linux",
  identity: "Linux"
}];
zino.util.BrowserCompabilityInspector = function zino$util$BrowserCompabilityInspector() {
  var $t = this;
  var dataString = "";
  var data = zino.util.Browser.navigators;
  for (var i = 0; i < data.length; i++) {
    dataString = data[i].string;
    var dataProp = data[i].prop;
    this.versionSearchString = data[i].versionSearch || data[i].identity;
    if (dataString) {
      var r = dataString.toLowerCase().indexOf(data[i].indexWord.toLowerCase());
      if (r != -1) {
        $t.name = data[i].identity;
        break;
      }
    } else if (dataProp);
    $t.name = data[i].identity;
  };
  var data = zino.util.Browser.operatingSystems;
  for (var i = 0; i < data.length; i++) {
    dataString = data[i].string;
    var dataProp = data[i].prop;
    this.versionSearchString = data[i].versionSearch || data[i].identity;
    if (dataString) {
      if (dataString.toLowerCase().indexOf(data[i].indexWord.toLowerCase()) != -1);
      $t.OS = data[i].identity;
    } else if (dataProp);
    $t.OS = data[i].identity;
  };
  $t.appVersion = navigator.appVersion;
  $t.appName = navigator.appName;
  $t.isPNGSupported = ($t.appName.toLowerCase() == "netscape") ? true : false;
  $t.isXPathSelectSupport = ($t.appName.toLowerCase() == "netscape") ? true : false;
  $t.isFirefox = ($t.name.toLowerCase() == "firefox") ? true : false;
  $t.isIE = ($t.name.toLowerCase() == "internetexplorer") ? true : false;
  $t.isSafariOld = parseInt((navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/) || "")[1]) < 420;
}.inherit(zino.lang.Object);
zino.util.Browser.compability = new zino.util.BrowserCompabilityInspector;
zino.util.Event = function zino$util$Event(_$t, initFunction) {
  var $t = this;
  $t.$t = _$t || $t;
  $t._TYPE = "zino.util.Event";
  var isFirst = false;
  $t.initFunction = initFunction;
  $t.__handles__ = [];
  $t.raise = function () {
    try {
      var args = (window.event) ? Array.prototype.concat(window.event, arguments) : arguments;
      var r = true;
      for (var i = 0; i < $t.__handles__.length; i++) {
        if ($t.__handles__[i]) var rF = $t.__handles__[i].apply($t.$t, arguments);
        r = (rF == undefined ? true : rF) && r;
        ___i = i;
        if (!r) break;
      }
    } catch (e) {
      ___e = e;
      throw new zino.lang.Exception(null, {
        source: this
      }, e, "zino.util.Event.raise", "zino.util.Event.js", 26);
    };
    return !!r;
  }
};
zino.util.Event.prototype.add = function () {
  var $t = this;
  if (!$t.isFirst) {
    if ($t.initFunction) $t.initFunction.call($t.$t, null);
    $t.isFirst = true;
  }
  for (var i = 0; i < arguments.length; i++) $t.__handles__.push(arguments[i]);
  return this;
};
zino.util.Event.prototype.remove = function () {
  if (!this.__handles__.length) return this;
  var index = -1;
  for (var i = 0; i < arguments.length; i++)
    if ((index = this.__handles__.indexOf(arguments[i])) != -1) this.__handles__.splice(index, 1);
  return this;
};
setNamespaces = function zino$global$misc$setNamespaces(DOM) {
  var tns = DOM.getAttribute("targetNamespace") ? DOM.getAttribute("targetNamespace") : null;
  for (var i = 0; i < DOM.attributes.length; i++) {
    var att = DOM.attributes[i];
    if (att.prefix != "xmlns") {
      continue;
    }
    if (!ns) var ns = {};
    ns[att.baseName] = att.value;
    if (att.value == "http://www.w3.org/2001/XMLSchema") $t.schemaNS = att.baseName;
  }
  if (ns) {
    ns["xsd"] = "http://www.w3.org/2001/XMLSchema";
    ns["soap"] = "http://schemas.xmlsoap.org/wsdl/soap/";
    ns["mime"] = "http://schemas.xmlsoap.org/wsdl/mime/";
    ns["http"] = "http://schemas.xmlsoap.org/wsdl/http/";
    ns["soapenc"] = "http://schemas.xmlsoap.org/soap/encoding/";
    ns["wsdl"] = "http://schemas.xmlsoap.org/wsdl/";
    setNSResolver(DOM, ns)
  }
};
zino.io.FileInfo = function zino$io$FileInfo(entity) {
  var $t = this;
  $t._AUTHOR = 'Mehran Hatami';
  var cl = 'zino.io.FileInfo';
  setType($t, eval(cl), cl);
  $t._VERSION = '0.0.1';
  $t._CREATEDATE = '2009/08/26';
  $t._MODIFIEDDATE = '2009/08/26';
  $t.name = entity.name || null;
  $t.content = entity.content || null;
  $t.contentType = entity.contentType || null;
  $t.size = entity.size || null;
  $t.fieldName = entity.fieldName || null;
}.inherit(zino.lang.Object);
//global.misc
xsdStr = function (val) {
  var str = new zinox.xml.schema.String();
  if (val) str.value.set(val);
  return str;
};
xsdInt = function (val) {
  var xint = new zinox.xml.schema.Int();
  if (val) xint.value.set(val);
  return xint;
};
checkMTOMResponse = function (req) {
  try {
    var resStr = req.response.text || "",
      isxml = resStr ? !(resStr.split('text/xml').length == 1) : false;
    if (!req.response.XML && resStr && isxml) {
      var sarr = resStr.split("Envelope");
      if (sarr.length == 1) return;
      var oarr = sarr[0].split("<");
      var envtagname = oarr[oarr.length - 1] + "Envelope";
      var starttag = "<" + envtagname,
        endtag = "</" + envtagname + ">";
      response = [];
      _pp = [starttag, endtag]
      var c1 = resStr.split(starttag);
      var c2 = c1[1].split(endtag);
      var soapDoc = zinox.xml.dom.Document.parseXML(starttag + c2[0] + endtag);
      return {
        soap: soapDoc,
        headers: [],
        files: null
      };
    } else if (req.response.XML) {
      return {
        soap: req.response.XML
      };
    }
  } catch (e) {
    alert('e==' + e)
  }
};
isFunc = function (f) {
  if (!f) return false;
  else return (f instanceof Function);
};
isArray = function (o) {
  if (!o) return false;
  else return (o instanceof Array);
};
changeDirection = function (name) {
  if (name == "fa-IR") window.document.lastChild.setAttribute("dir", "rtl");
  else window.document.lastChild.setAttribute("dir", "ltr");
};
checkEnter = function $checkEnter(e, callback) {
  if (e.keyCode == 13 && callback && isFunc(callback)) callback();
};
isEl = function (cel) {
  if (cel && cel.tagName && cel.baseName && (cel.ownerDocument === window.document)) return cel;
  else return false;
};
getEl = function (c) {
  if (c) {
    var cel;
    if (c.element && isFunc(c.element.get) && (cel = c.element.get())) return isEl(cel);
    else return isEl(c);
  }
};
zalert = function $zalert(message, caption) {
  if (_.alert === undefined) {
    _.alert = new zinox.ui.controls.dialog.Alert(message, caption);
    _.alert.show();
  } else {
    if (!_.alert.visible) {
      _.alert.text.set(message);
      _.alert.caption.set(caption);
      _.alert.show();
    }
  }
};
zconfirm = function $zconfirm(message, caption, okFunction, okBtnText, cancelBtnText) {
  if (_.conf === undefined) {
    _.conf = new zinox.ui.controls.dialog.Confirm(message, caption, okFunction, okBtnText || "تایید", cancelBtnText || "بستن");
    _.conf.show();
  } else {
    _.conf.confirm(message, caption, okFunction, okBtnText || "تایید", cancelBtnText || "بستن");
  }
};

wait = function $wait$(x, y, z) {
  if (_.waiting === undefined) {
    if (!_.waitloading) {
      var tbl = ce("table");
      tbl.align = "center";
      tbl.style.height = "28px";
      _.waitloading = new zinox.ui.controls.HtmlControl(tbl);
      _.waitloading.mainTable = tbl;
      _.waitloading.mainTable.style.position = "absolute";
      var r0 = tbl.insertRow(0),
        c0 = r0.insertCell(0),
        c1 = r0.insertCell(1);
      var img = ce("img");
      img.src = "/dre/client/_resources/loading.gif";
      c0.appendChild(img);
      _.waitloading.caption = {
        set: function (v) {
          c1.innerHTML = v || (_.waitCaption || "loading...");
        }
      };
      _.waitloading.caption.set();
      _.waitloading.mainClass.add("wait-loading-panel");
      var opac = new zino.ui.Opacity(_.waitloading.pgblock = ce("div"));
      opac.change(40);
      _.waitloading.pgblock.style.backgroundColor = "#ccc";
      _.waitloading.pgblock.style.position = "absolute";
      _.waitloading.pgblock.zIndex = "20000";
      _.waitloading.mainTable.zIndex = "20001";
    }
    var msg = null,
      ctrl = _.body,
      w = -1;
    if (typeof (x) == "number") w = x;
    else if (typeof (y) == "number") w = y;
    else if (typeof (z) == "number") w = z;
    if (w != -1) _.waitloading.element.get().style.width = px(w);
    if (x && typeof (x) == "string") {
      msg = x;
      if (y && y instanceof zinox.ui.Control) ctrl = y;
    } else if (x && x instanceof zinox.ui.Control) {
      ctrl = x;
      if (y && typeof (y) == "string") msg = y;
    }
    var ct = ctrl.element.get(),
      rect = getRectangle(ct),
      bdy = _.body.element.get();
    bdy.appendChild(_.waitloading.pgblock);
    bdy.appendChild(_.waitloading.mainTable);
    if (msg) _.waitloading.caption.set(msg);
    _.waitloading.pgblock.style.top = px(rect.top);
    _.waitloading.pgblock.style.left = px(rect.left);
    _.waitloading.pgblock.style.width = px(rect.width);
    _.waitloading.pgblock.style.height = px(rect.height);
    _.waitloading.mainTable.style.top = px(parseInt(((rect.height) - 28) / 2));
    var tblrect = getRectangle(_.waitloading.mainTable);
    _.waitloading.mainTable.style.top = px(rect.top + parseInt(((rect.height) - 28) / 2));
    _.waitloading.mainTable.style.left = _left = px(rect.left + parseInt(((rect.width) - (tblrect.width)) / 2) - 6);
    _.waiting = true;
  }
};
mouseWheel = function mouseWheel(event, handle) {
  var delta = 0;
  if (!event) event = window.event;
  if (event.wheelDelta) {
    delta = event.wheelDelta / 120;
    if (window.opera) delta = -delta;
  } else if (event.detail) delta = -event.detail / 3;
  if (delta) handle(delta);
  if (event.preventDefault) event.preventDefault();
  event.returnValue = false;
};
upCase = function (str) {
  try {
    return str[0].toUpperCase() + str.substring(1, str.length);
  } catch (err) {
    return str;
  }
};
waitend = function () {
  if (_.waiting == true) {
    delete _.waiting;
    var bdy = _.body.element.get();
    bdy.removeChild(_.waitloading.mainTable);
    bdy.removeChild(_.waitloading.pgblock);
    _.waitloading.caption.set();
  }
};
switchCulture = function $switchCulture$() {
  if (_.cultures.current.get().name == "en-US") gotoPersianCulture();
  else gotoENCulture();
};
disableSelection = function $disableSelection(target) {
  if (typeof target.onselectstart != "undefined") target.onselectstart = function () {
    return false;
  }; //IE route
  else if (typeof target.style.MozUserSelect != "undefined") target.style.MozUserSelect = "none"; //Firefox route
  else target.onmousedown = function () {
    return false;
  }; //All other route (ie: Opera)
  target.style.cursor = "default";
};
hideChilds = function (el) {
  for (var i = 0; i < el.childNodes.length; i++) {
    if (el.childNodes[i].nodeType == 1) el.childNodes[i].style.visibility = "hidden";
  }
};
showChilds = function (el) {
  for (var i = 0; i < el.childNodes.length; i++) el.childNodes[i].style.visibility = "visible";
};

moveChilds = function (el, el1) {
  for (var i = 0; i < el.childNodes.length; i++) el1.appendChild(el.childNodes[i]);
};

removeChilds = function (el) {
  var childs = [];
  for (var i = 0; i < el.childNodes.length; i++) childs.push(el.removeChild(el.childNodes[i]));
  return childs;
};
appendChilds = function (el, childs) {
  for (var i = 0; i < childs.length; i++) el.appendChild(childs[i]);
};
wsImport = function (wsdllocation, ns, onload) {
  if (_.ws.ref && _.ws.ref.addNewServiceRefrence) _.ws.ref.addNewServiceRefrence(wsdllocation, ns, onload);
  else _.ns.includeC("zinox.xml.ws.WSRef", function () {
    _.ws.ref.addNewServiceRefrence(wsdllocation, ns, onload);
  });
};

carr = function (s) {
  if (!window[s]) window[s] = [];
};
upFirstChar = function (str) {
  return str.substring(0, 1).toUpperCase() + (str.substring(1, (str.length)));
};
lowFirstChar = function (str) {
  return str.substring(0, 1).toLowerCase() + (str.substring(1, (str.length)));
};
setNamespaces = function zino$global$misc$setNamespaces(DOM) {
  var tns = DOM.getAttribute("targetNamespace") ? DOM.getAttribute("targetNamespace") : null;
  for (var i = 0; i < DOM.attributes.length; i++) {
    var att = DOM.attributes[i];
    if (att.prefix != "xmlns") {
      continue;
    }
    if (!ns)
      var ns = {};
    ns[att.baseName] = att.value;
    if (att.value == "http://www.w3.org/2001/XMLSchema")
      $t.schemaNS = att.baseName;
  }
  if (ns) {
    ns["xsd"] = "http://www.w3.org/2001/XMLSchema";
    ns["soap"] = "http://schemas.xmlsoap.org/wsdl/soap/";
    ns["mime"] = "http://schemas.xmlsoap.org/wsdl/mime/";
    ns["http"] = "http://schemas.xmlsoap.org/wsdl/http/";
    ns["soapenc"] = "http://schemas.xmlsoap.org/soap/encoding/";
    ns["wsdl"] = "http://schemas.xmlsoap.org/wsdl/";
    setNSResolver(DOM, ns)
  }
};

findByTrain = function $findByTrain(t, p) {
  var trn = String(t),
    pe = p ? ((p === _.win) ? _.body : p) : _.body;
  for (var i = 1; i < trn.length; i++) pe = pe.controls[trn.charAt(i)];
  return pe;
};

sortByDepth = function $sortByDepth(ctrls0) {
  if ((!ctrls0 instanceof Array) || ctrls0.length == 0) return;
  var trns = [],
    sortedList = [],
    sl = 0;;
  for (var i = 0; i < ctrls0.length; i++) trns.push(ctrls0[i].getTrain());
  trns.sort();
  for (var i = 0; i < trns.length; i++) {
    var baseTrn = trns[i],
      asort = findByTrain(baseTrn),
      newcs = [],
      newac;
    for (var j = i + 1; j < trns.length; j++) {
      if (str(trns[j]).substring(0, len(baseTrn)) == str(baseTrn)) {
        newcs.push(findByTrain(trns[j]));
        i++;
      }
    }
    if (newcs.length && (newac = sortByDepth(newcs))) asort = [asort].concat(newac);
    sortedList[sl++] = asort;
  }
  return sortedList;
};

und = function $und(obj) {
  return (obj === undefined);
};

getCursorPosition = function $getCursorPosition(event) {
  var pos = {};
  if (_.browser.isIE) {
    pos.x = window.event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft;
    pos.y = window.event.clientY + document.documentElement.scrollTop + document.body.scrollTop;
  } else {
    pos.x = event.clientX + window.scrollX;
    pos.y = event.clientY + window.scrollY;
  }
  return pos;
};

getCenterGravity = function $getCenterGravity(obj) {
  var rect = getRectangle(obj);
  return {
    x: rect.left + parseInt(rect.width / 2),
    y: rect.top + parseInt(rect.height / 2)
  };
};
getPosition = function $getPosition(obj) {
  var elm = null,
    val;
  if (obj instanceof zinox.ui.Control) elm = obj.element.get();
  else elm = obj;
  var rect = getRectangle(elm);
  val = {
    x: {
      left: rect.left
    },
    y: {
      top: rect.top
    }
  };
  val.x.right = val.x.left + rect.width;
  val.y.bottom = val.y.top + rect.height;
  return val;
};
getDropRegion = function $getDropRegion(obj) {
  var elm = null,
    val;
  if (obj instanceof HTMLElement) elm = obj;
  else if (obj instanceof zinox.ui.Control) elm = obj.element.get();
  var rect = getRectangle(elm);
  if (elm.tagName == "body") val = {
    x: {
      left: 0,
      right: rect.width
    },
    y: {
      top: 0,
      bottom: rect.height
    }
  };
  else {
    val = {
      x: {
        left: rect.left + parseInt(rect.width / 4)
      },
      y: {
        top: rect.top + parseInt(rect.height / 4)
      }
    };
    val.x.right = val.x.left + parseInt(rect.width / 2);
    val.y.bottom = val.y.top + parseInt(rect.height / 2);
  }
  return val;
};
est = function est(e) {
  var absoluteX = absoluteY = 0;
  if (e.offsetParent) {
    absoluteX = e.offsetLeft;
    absoluteY = e.offsetTop;
    while (e = e.offsetParent) {
      if (e.offsetParent) {
        var $scrollTop = e.scrollTop;
        var $scrollLeft = e.scrollLeft;
      } else {
        var $scrollTop = 0;
        var $scrollLeft = 0;
      } //end if
      absoluteX += e.offsetLeft - $scrollLeft;
      absoluteY += e.offsetTop - $scrollTop;
      //alert(e.scrollTop)
    } //end while
  } //end if
  return {
    x: absoluteX,
    y: absoluteY
  } //end return
};
isDefined = function (strName) {
  var nameAr = strName.split(".");
  var textjs = "";
  if (!eval(textjs = "window['" + nameAr[0] + "']")) return false;
  for (var i = 1; i < nameAr.length; i++) {
    if (!eval(textjs += "['" + nameAr[i] + "']")) {
      return false;
    }
  }
  return true;
};
setJsNamespace = function createJsNamespace(url, obj) {
  var ns = getNamespace(url),
    pe = null,
    nsa = ns.split("."),
    name = "",
    i = 0;
  var obj = obj || {};
  nsa.forEach(function (n) {
    i++;
    if (!pe) {
      pe = window[n] || (window[n] = {});
      name = n;
    } else {
      if (i == nsa.length) pe = (pe[n] = obj);
      else pe = pe[n] || (pe[n] = {});
      name += "$" + n;
    }
  });
  return name;
};
// Type
setType = function setType(o, t, ts) {
  o.__type__ = t;
  if (ts)
    o.toString = function Object$toString() {
      return "[object " + ts + "]"
    }
};

getType = function getType(o) {
  return o && (o.__type__ || typeof o);
};

isInstanceOf = function isInstanceOf(object, t) {
  if (t == zino.Variant) return true;
  if (object instanceof zino.lang.Property)
    return (getType(object) == t) || (getType(object) == zino.Variant);
  else
    return o instanceof t;

};

addChar = function addChar(input, insTexte) {
  var startTag = '',
    endTag = '';
  if (input.createTextRange) {
    var text;
    input.focus(input.caretPos);
    input.caretPos = document.selection.createRange().duplicate();
    if (input.caretPos.text.length > 0) input.caretPos.text = startTag + input.caretPos.text + endTag;
    else input.caretPos.text = startTag + insTexte + endTag;
  } else input.value += startTag + insTexte + endTag;
};

ea = function ea(str, t) {
  if (!(typeof str == "string" || str instanceof String))
    throw new zino.lang.Exception("Not valid string format.\r\n" + (typeof str) + " : " + str, {
      str: str,
      t: t,
      source: this
    }, null, "Global.ea", "Global.Misc.js", 49);

  str = str.replaceAll("\n", "");

  if (str.indexOf("{#") == 0) {
    var r = str.substring(2, str.lastIndexOf("}"));
  } else {
    var t = t || "string";


    switch (t) {

    case "string":
      r = '"' + str + '"';
      break;

    case "boolean":
      r = '"' + str + '".toBoolean()';
      break;

    case "number":
      r = str;
      break;

    case "function":
      r = "function ea$function$(){\n" + str + "\n}";
      break;

    case "Boolean":
      r = "new " + t + '("' + str + '".toBoolean())';
      break;

    default:
      r = "new " + t + '("' + str + '")';
      break;

    }

  }
  return "__JSON_BUG = " + r;
};

getCS = function getCS(o, add) {
  var r = "";
  for (var i in o) {
    var v = o[i] ? o[i].toString() : "";
    r += "public int " + i;
    r += (v.indexOf("{") != -1 ? v.substring(v.indexOf("("), v.indexOf(")") + 1) + "{}" : ";");
    r += "\r\n";
  }
  if (add) {
    var pre = _.body.element.get().appendChild(ce("pre"));
    pre.innerHTML = r;
  }
  return r + "\r\n";
};

setNSResolver = function setNSResolver(node, res) {
  //var doc = node.ownerDocument || node.documentElement.ownerDocument || (node.nodeType == 9 ? node : false);
  try {
    var doc = node.ownerDocument || node.documentElement || (node.nodeType == 9 ? node : false);
    if (!doc)
      throw new zino.lang.Exception("Not Valid Node or Document.", {
        node: node,
        res: res,
        source: this
      }, null, "Global.setNSResolver", "Global.Misc.js", 111);
    //doc.__J_NSS = res;

    if (zino.util.Browser.compability.isXPathSelectSupport) {
      var nsrs = " ";

      for (var i in res) {
        nsrs += 'case "' + i + '": return "' + res[i] + '";break;';
      }

      eval("var nsr = function setNSResolver$nsr(prefix){ switch(prefix){" + nsrs + "default:return null;} }");
      doc.__J_NSRESOLVER = nsr;
    } else {
      doc.setProperty('SelectionLanguage', 'XPath');
      var nsr = "";
      for (i in res) {
        nsr += 'xmlns:' + i + '="' + res[i] + '" ';
      }
      doc.setProperty('SelectionNamespaces', nsr);
    }
  } catch (e) {
    throw new zino.lang.Exception(null, {
      node: node,
      res: res,
      source: this
    }, e, "Global.setNSResolver", "Global.Misc.js", 132);
  }
};

flatById = function flatById(ar) {
  var o = {};
  for (var i = 0; i < ar.length; i++) {
    o[ar[i].getAttribute("id")] = ar[i];
  }
  return o;
};

serialize = function serialize(o) {
  var r = "";
  for (var i in o) {
    r += '"' + i + '":';
    r += ((typeof o[i]) == "string" ? '"' + o[i] + '"' : o[i]);
    r += ",";
  }
  return ("{" + r.substr(0, r.length - 1) + "}");
};

to = function to(obj) {
  return (obj._TYPE && obj._TYPE != "null") ? obj._TYPE : (typeof obj);;
};

isNode = function isNode(o) {
  return (o.childNodes ? true : false);
};

dn = function dn(doc, ph, v) {
  zino.Engine.render(doc, ph, v);
};

mp = function mp(path) {
  var rEnv = /(.*)(\{:)([^\}]*)(\})(.*)/i;
  var r = rEnv.exec(path);
  if (r != null) {
    return mp(r[1]) + _.env[r[3]] + mp(r[5]);
  } else {
    return path;
  }
};

en = function en(node) {
  while (node.childNodes.length) {
    node.removeChild(node.firstChild);
  }
};

getWindowRect = function getWindowRect() {
  var winW, winH;
  if (parseInt(navigator.appVersion) > 3) {
    if (navigator.appName == "Netscape") {
      winW = window.innerWidth;
      winH = window.innerHeight;
    }
    if (navigator.appName.indexOf("Microsoft") != -1) {
      winW = document.body.offsetWidth;
      winH = document.body.offsetHeight;
    }
  }
  return [winW, winH];
};

trim = function trim(s) {
  while (s.charAt(0) == ' ') {
    s = s.substring(1, c.length);
  }
  while (s.charAt(s.length - 1) == ' ') {
    s = s.substring(0, c.length - 2);
  }
  return s;
};

alertr = function alertr(obj) {
  var r = "";
  for (i in obj) {
    r += i + ":" + obj[i] + ",\n\n\n";
  }
  alert(r);
};

alerta = function alerta(obj) {
  var r = "";
  for (i in obj) {
    alert([i, obj[i]]);
  }
};
printa = function printa(obj) {
  var r = "";
  for (i in obj) {
    document.write(i + " : " + obj[i]);
  }
};

printr = function printr(obj) {
  var r = "";
  for (i in obj) {
    r += i + ":" + obj[i] + ",<br/><br/>";
  }
  document.write(r);
};

pn = function pn(o) {
  return o.parentNode ? o.parentNode : o.parentElement;
};

getNodeXML = function getNodeXML(node) {
  if (document.importNode) {
    var xs = new XMLSerializer();
    //var child = document.importNode(node , true);
    //obj.appendChild ( child );
    return xs.serializeToString(node);
  } else if (node.xml) {
    return node.xml;
    //obj.insertAdjacentHTML(node.xml);
  }
};

copyAtrributes = function copyAtrributes(s, d) {
  for (var ai = 0; ai < s.attributes.length; ai++) {

    switch (s.attributes[ai].nodeName) {
    case "src":
      d.src = mp(s.attributes[ai].nodeValue);

    case "href":
      d.href = mp(s.attributes[ai].nodeValue);

    case "class":
      d.className = s.attributes[ai].nodeValue;
      break;
    case "nowrap":
      d.noWrap = true;
      break;
    case "cellspacing":
      d.cellSpacing = s.attributes[ai].nodeValue;
      break;
    case "rowspan":
      d.rowSpan = s.attributes[ai].nodeValue;
      break;

    case "style":
      d.style.cssText = s.attributes[ai].nodeValue;
      break;

    case "onclick":

      var fs = "d.onclick = function copyAtrributes$onclick(){" + s.attributes[ai].value + "}";
      eval(fs);
      break;

    default:
      d.setAttribute(s.attributes[ai].nodeName, s.attributes[ai].value);
      break;
    }

  }
};

createQS = function createQS(frm) {
  qs = "";
  for (var i = 0; i < frm.length; i++) {
    if (frm[i].type == "checkbox" || frm[i].type == "radio") {
      qs += frm[i].name + "=" + (frm[i].checked ? 1 : 0) + "&";
    } else {
      qs += frm[i].name + "=" + (frm[i].value) + "&";
    }
  }
  return qs;
};


getn = function getn(n, t) { //getElementByTagName
  return n.getElementsByTagName(t);
};


gfetn = function gfetn(n, t) { // getFirstElement ByTag Name
  return n.getElementsByTagName(t) ? n.getElementsByTagName(t)[0] : false;
};

gtv = function gtv(n, t) { //getTagValue
  var ts = getTag(n, t);
  return ts ? ts.firstChild.nodeValue : false;
};

//remove White
removeWhite = function removeWhite(doc) {
  if (!doc) return false;
  var isWhite = /\S/;

  for (var i = 0; i < doc.childNodes.length; i++) {
    var child = doc.childNodes[i];

    if (child.nodeType == 3 && !isWhite.test(child.nodeValue)) {
      doc.removeChild(doc.childNodes[i]);
      i--;
    }

    if (child.nodeType == 1 && child.hasChildNodes()) removeWhite(child);
  }
  return true;
};

getRectangle = function getRectangle(obj) {
  var tt = 0;
  var r = {};
  var width = obj["offsetWidth"];
  var height = obj["offsetHeight"];
  var top = 0;
  var left = 0;
  while (obj) {
    top += obj["offsetTop"];
    left += obj["offsetLeft"];
    obj = obj.offsetParent
  }
  r.width = width;
  r.height = height;
  r.top = top;
  r.left = left;
  r.right = left + width;
  r.bottom = top + height;
  if (arguments[1]) {
    var fr = getRectangle(arguments[1]);
    r.bottom += fr.bottom;
    r.top += fr.top;
    r.left += fr.left;
    r.right += fr.right;
  }
  return r;
};

twoChar = function twoChar(s) {
  var n = s * 1;
  var r = (n < 10 ? '0' : '') + n;
  return r;
};

formatNumber = function formatNumber(format, num, leftToRight) {
  var r = format;

  for (var i = 0; i < (num * 1 + "").length; i++) {
    if (leftToRight) {
      r = r.replace(/\#/, (num * 1 + "").charAt(i, 1));
    } else {
      var index = r.lastIndexOf("#");
      if (index == -1)
        break;
      r = r.substring(0, index) + (num * 1 + "").charAt((num * 1 + "").length - i - 1, 1) + r.substring(index + 1);
    }
  }
  return r.replace(/\#/g, "0");
};

gel = function gel(i) {
  o = document.getElementById(i);
  return (o != null ? o : false);
};

ce = function ce(tagName, className, cssText) {
  var r = document.createElement(tagName);
  cssText && (r.style.cssText = cssText);
  className && (r.className = className);
  return r;
};

cs = function cs(text) {

  return document.createTextNode(text);


};

px = function px(x) {
  return x + 'px';
};
str = function str(x) {
  return String(x);
};

len = function len(x) {
  return str(x).length;
};

jtry = function jtry() {
  var v, o = arguments;
  if (o.length == 1 && typeof (o[0]) == "object")
    for (var i in o[0]) try {
      v = o[0][i]();
      break;
    } catch (e) {} else
      for (var i = 0; i < o.length; i++) try {
        v = o[i]();
        break;
      } catch (e) {}
  return v;
};

isParentOf = function isParentOf(p, l) {
  while (l && (l = l.parentNode) != p);
  return !!l;
};

isChildOf = function isChildOf(l, p) {
  return isParentOf(p, l);
};
ct = function ct(text) {
  var rLang = /(.*)(\{\$)([^\}]*)(\})(.*)/i;
  var r = rLang.exec(text);
  if (r != null) {
    if (r[1] || r[5]) {
      var e = ce("SPAN");
      if (r[1]) e.appendChild(ct(r[1]));
      e.appendChild(_.langs.createElement(r[3]));
      if (r[5]) e.appendChild(ct(r[5]));
      return e;
    } else {
      return _.langs.createElement(r[3]);
    }
  } else {
    return cs(text);
  }
};

getNamespace = function getNamespace(url) {
  if (url.indexOf("urn:") == 0) return url.split("urn:")[1];
  else {
    if (url.indexOf(":") == -1) url = "http://" + url + "/";
    var r = url.split("://")[1];
    r = r.replace(/\/\//g, "/");
    r = r.replace(/(\/[a-zA-Z0-9\$]*)([\.\~\!\`\'\"\'\,\-\s])([a-zA-Z0-9\$]*)/g, "$1_$3");
    r = r.split("/");
    r[0] = r[0].replace(/([a-zA-Z0-9\$]*)([\~\!\`\'\"\'\,\-\s])([a-zA-Z0-9\$]*)/g, "$1_$3");
    r[0] = r[0].split(".");
    var rev = [];
    for (var i = r[0].length - 1; i > -1; i--)
      if (r[0][i] != "") rev.push(r[0][i]);
    for (var i = 1; r.length > i; i++)
      if (r[i] != "") rev.push(r[i]);
    for (var i = 0; i < rev.length; i++)
      if (!isNaN(rev[i] - 0)) rev[i] = "_" + rev[i];
    alert(rev);
    return rev.join(".");
  }
};
//global.prototype
//String
String.prototype.replaceAll = function String$replaceAll(t1, t2) {
  var str = this.toString();
  var tmpArr = str.split(t1);
  return tmpArr.join(t2);
};

String.prototype.toBoolean = function String$toBoolean() {
  return this.toString() == "true" || this.toString() == "1" || this.toString() == "on" || this.toString() == "yes" ? true : false;
};

String.prototype.trim = function String$trim() {
  return this.replace(/^\s+|\s+$/g, '');
};

String.prototype.invert = function String$invert() {
  var rvs = "";
  for (var i = this.length; i > 0; i--) rvs += this.charAt(i - 1);
  return rvs;
};

String.prototype.trimLeft = function String$trimLeft() {
  return this.replace(/^\s+/g, '');
};

String.prototype.trimRight = function String$trimRight() {
  return this.replace(/\s+$/g, '');
};

String.fromKeyCode = function String$fromKeyCode(keyCode, shiftKey) {
  if (shiftKey) {
    var KeyCodes = {
      32: " ",
      48: ")",
      49: "!",
      50: "@",
      51: "#",
      52: "$",
      53: "%",
      54: "^",
      55: "&",
      56: "*",
      57: "(",
      59: ":",
      65: "A",
      66: "B",
      67: "C",
      68: "D",
      69: "E",
      70: "F",
      71: "G",
      72: "H",
      73: "I",
      74: "J",
      75: "K",
      76: "L",
      77: "M",
      78: "N",
      79: "O",
      80: "P",
      81: "Q",
      82: "R",
      83: "S",
      84: "T",
      85: "U",
      86: "V",
      87: "W",
      88: "X",
      89: "Y",
      90: "Z",
      106: "*",
      107: "+",
      109: "_",
      111: "/",
      186: ";",
      187: "=",
      188: "<",
      189: "-",
      190: ">",
      191: "?",
      192: "~",
      219: "{",
      220: "|",
      221: "}",
      222: "\""
    };
  } else {
    var KeyCodes = {
      32: " ",
      48: "0",
      49: "1",
      50: "2",
      51: "3",
      52: "4",
      53: "5",
      54: "6",
      55: "7",
      56: "8",
      57: "9",
      59: ";",
      65: "a",
      66: "b",
      67: "c",
      68: "d",
      69: "e",
      70: "f",
      71: "g",
      72: "h",
      73: "i",
      74: "j",
      75: "k",
      76: "l",
      77: "m",
      78: "n",
      79: "o",
      80: "p",
      81: "q",
      82: "r",
      83: "s",
      84: "t",
      85: "u",
      86: "v",
      87: "w",
      88: "x",
      89: "y",
      90: "z",
      96: "0",
      97: "1",
      98: "2",
      99: "3",
      100: "4",
      101: "5",
      102: "6",
      103: "7",
      104: "8",
      105: "9",
      106: "*",
      107: "+",
      109: "-",
      110: ".",
      111: "/",
      186: ";",
      187: "=",
      188: ",",
      189: "-",
      190: ".",
      191: "/",
      192: "`",
      219: "[",
      220: "\\",
      221: "]",
      222: "\'"
    };
  }
  return KeyCodes[keyCode];
};
String.format = function (text) {
  if (arguments.length <= 1)
    return text;

  var tokenCount = arguments.length - 2;
  for (var token = 0; token <= tokenCount; token++) {
    text = text.replace(new RegExp("\\{" + token + "\\}", "gi"), arguments[token + 1]);
  }

  return text;
};

//Date
Date.getTimeStampByTicks = function (ticks) {
  return (ticks - 621356065390000000) / 10000;
};

Date.prototype.ticks = function () {
  var date = this
  this.day = date.getDate();
  this.month = date.getMonth() + 1;
  this.year = date.getFullYear();
  this.hour = date.getHours();
  this.minute = date.getMinutes();
  this.second = date.getSeconds();
  this.ms = date.getMilliseconds();

  this.monthToDays = function (year, month) {
    var add = 0;
    var result = 0;
    if ((year % 4 == 0) && ((year % 100 != 0) || ((year % 100 == 0) && (year % 400 == 0)))) add++;

    switch (month) {
    case 0:
      return 0;
    case 1:
      result = 31;
      break;
    case 2:
      result = 59;
      break;
    case 3:
      result = 90;
      break;
    case 4:
      result = 120;
      break;
    case 5:
      result = 151;
      break;
    case 6:
      result = 181;
      break;
    case 7:
      result = 212;
      break;
    case 8:
      result = 243;
      break;
    case 9:
      result = 273;
      break;
    case 10:
      result = 304;
      break;
    case 11:
      result = 334;
      break;
    case 12:
      result = 365;
      break;
    }
    if (month > 1) result += add;
    return result;
  }

  this.dateToTicks = function (year, month, day) {
    var a = parseInt((year - 1) * 365);
    var b = parseInt((year - 1) / 4);
    var c = parseInt((year - 1) / 100);
    var d = parseInt((a + b) - c);
    var e = parseInt((year - 1) / 400);
    var f = parseInt(d + e);
    var monthDays = this.monthToDays(year, month - 1);
    var g = parseInt((f + monthDays) + day);
    var h = parseInt(g - 1);
    return h * 864000000000;
  }

  this.timeToTicks = function (hour, minute, second) {
    return (((hour * 3600) + minute * 60) + second) * 10000000;
  }

  return this.dateToTicks(this.year, this.month, this.day) + this.timeToTicks(this.hour, this.minute, this.second) + (this.ms * 10000);
}

//Math
Math.div = function Math$div(n1, n2) {
  return parseInt((n1 / n2), 10);
};

//Array
if (zino.util.Browser.compability.isIE) {
  Array.prototype.indexOf = function Array$prototype$indexOf(elt, from) {
    for (var from = from == null ? 0 : from < 0 ? Math.max(0, this.length + from) : from; from < this.length; from++) {
      if (from in this && this[from] === elt)
        return from;
    };
    return -1;
  };

  Array.prototype.forEach = function Array$prototype$forEach(fun, thisp) {
    var len = this.length;
    if (typeof fun != "function") throw new TypeError();

    for (var i = 0; i < len; i++)
      if (i in this)
        fun.call(thisp, this[i], i, this);
  };


  Array.prototype.filter = function Array$prototype$filter(fun, thisp) {
    if (typeof fun != "function") throw new TypeError();

    var res = new Array();
    for (var i = 0; i < this.length; i++) {
      if (i in this) {
        var val = this[i]; // in case fun mutates this
        if (fun.call(thisp, val, i, this))
          res.push(val);
      }
    }

    return res;
  };

  Array.prototype.map = function Array$prototype$map(fun, thisp) {
    var len = this.length;
    if (typeof fun != "function") throw new TypeError();

    var res = new Array(len);
    for (var i = 0; i < len; i++)
      if (i in this)
        res[i] = fun.call(thisp, this[i], i, this);
    return res;
  };

  Array.prototype.some = function Array$prototype$some(fun, thisp) {
    if (typeof fun != "function") throw new TypeError();

    for (var i = 0; i < this.length; i++)
      if (i in this && fun.call(thisp, this[i], i, this))
        return true;

    return false;
  };

  Array.prototype.every = function Array$prototype$every(fun, thisp) {
    if (typeof fun != "function") throw new TypeError();

    for (var i = 0; i < this.length; i++) {
      if (i in this && !fun.call(thisp, this[i], i, this))
        return false;
    }
    return true;
  };

  Array.prototype.contains = function Array$prototype$contains(b) {
    return this.indexOf(b) > -1;
  };
  //Array.concat = Array.prototype.concat;
};

//Function
Function.prototype.inherit = function Function$inherit(s) {
  if (!(s instanceof Function)) {
    throw new zino.lang.Exception("Cannot inherit from " + s, {
      s: s,
      source: this
    }, null, "Function.inherit", "Global.Prototype.js", 64);
  }
  try {
    /*for(var i in s.prototype)
			this.prototype[i] = s.prototype[i];*/
    this.prototype = new s;
    //delete this.prototype._event;
    //this.constructor = this;
    this.constructor = this.prototype.constructor = this;
    //this.prototype.constructor = this;
    this.superClass = s;
    return this;
  } catch (e) {
    _c = this;
    _p = s;
    throw new zino.lang.Exception("An Error occured while inheriting." + e, {
      s: s,
      source: this
    }, e, "Function.inherit", "Global.Prototype.js", 73);
  }
};

Function.prototype.inherits = function Function$inherits(c) {
  var o = this;
  do {
    if (o == c) return true;
  } while (o = o.superClass);

  return false;
};
Function.prototype.onadd = function Function$onadd() {};

Function.prototype.add = function Function$add( /*[func1,func2,...]*/ ) {
  //if(!this.__handles__){
  var nf = function Function$Executer$$Multiple() {
    var r = true;
    for (var i = 0; i < nf.__handles__.length; i++) {
      var rF = nf.__handles__[i].apply(this, arguments);
      r = (rF == undefined ? true : rF) && r;
    }
    return !!r;
  };
  nf.__handles__ = [this];
  for (var i = 0; i < arguments.length; i++) {
    var f = arguments[i];
    if (f) {
      if (typeof (f) != "function")
        throw new zino.lang.Exception("Cannot add non-function! " + f, {
          func: f,
          multifunc: nf,
          source: this
        }, null, "Function.add", "Global.Prototype.js", 152);
      if (this.onadd(f) != false)
        this.onadd(f);
      nf.__handles__.push(f);
    }
  };
  nf.toString = function () {
    return "[Function Multiple]"
  };
  return nf;
  /*}else{
		for(var i=0;i<arguments.length;i++){
			if( this.onadd(arguments[i]) != false )
				this.__handles__.push(arguments[i]);
		}
		return this;
	}*/
};

Function.prototype.remove = function Function$remove( /*[func1,func2,...]*/ ) {
  if (!this.__handles__)
    return;

  var index = -1;
  for (var i = 0; i < arguments.length; i++)
    if ((index = this.__handles__.indexOf(arguments[i])) != -1)
      this.__handles__.splice(index, 1);
};

Function.prototype.bind = function (object) {
  var __method = this;
  return function () {
    return __method.apply(object, arguments);
  };
};
//Browsers Needs

//FireFox
if (zino.util.Browser.compability.isFirefox || zino.util.Browser.compability.name == "Mozilla") {
  //Node
  Node.prototype.__defineGetter__("parentElement", function Function$inherits$parentElement() {
    return this.parentNode
  });
  Node.prototype.__defineGetter__("xml", function Function$inherits$xml() {
    return (new XMLSerializer()).serializeToString(this);
  });

  Node.prototype.__defineGetter__("innerText", function Function$inherits$innerText$Getter() {
    return this.textContent
  });
  Node.prototype.__defineSetter__("innerText", function Function$inherits$innerText$Setter(t) {
    this.textContent = t
  });

  Node.prototype.__defineGetter__("baseName", function Function$inherits$innerText$baseName() {
    return this.localName
  });

  Node.prototype.selectNodes = function Function$inherits$innerText$selectNodes(expr) {
    //DOCUMENT_NODE = 9
    var doc = this.nodeType == 9 ? this : this.ownerDocument;
    // var nsRes = doc.createNSResolver(this.nodeType == 9 ? this.documentElement : this);

    var nsRes = doc.__J_NSRESOLVER || function Function$inherits$innerText$selectNodes$nsRes() {};
    var xpRes = doc.evaluate(expr, this, nsRes, 5, null);
    var res = [];
    var item;
    while (item = xpRes.iterateNext()) {
      res.push(item);
    }

    return res;
  };

  Node.prototype.selectSingleNode = function Function$inherits$innerText$selectSingleNode(expr) {
    var nodes = this.selectNodes(expr);
    return (nodes.length) ? nodes[0] : null;
  };
  Document.prototype.createNode = function Document$createNode(t, nodeName, ns) {
    return this.createElementNS(ns, nodeName);
  };

  //Event
  Event.prototype.__defineGetter__("srcElement", function Function$inherits$innerText$srcElement() {
    return this.target
  });

  ///Sawp node
  Node.prototype.swapNode = function (node) {
    var nextSibling = this.nextSibling;
    var parentNode = this.parentNode;
    node.parentNode.replaceChild(this, node);
    parentNode.insertBefore(node, nextSibling);
  }

};

//Internet Explorer
if (zino.util.Browser.compability.isIE) {
  window.HTMLElement = function Type$HTMLElement() {};
  window.Element = function Type$Element() {};
  window.Node = function Type$Node() {};
};
//net.HTTPResponse
zino.net.HTTPResponse = function zino$net$HTTPResponse(httpReq) {
  /*<init class="zino.net.HTTPResponse"
		version="1.0.1pa"
		author="Shayan Nojedehi"
		createdate="2006/6/12" />*/

  var $t = this;
  setType($t, "zino.net.HTTPResponse");

  $t.text = httpReq.httpReqObj.responseText;
  $t.XML = httpReq.httpReqObj.responseXML;
  $t.url = httpReq.url;
};
//net.HTTPRequest
zino.net.HTTPRequest = function zino$net$HTTPRequest(url, method) {
  /*<init class="zino.net.HTTPRequest"
		version="1.0.1pa"
		author="Shayan Nojedehi"
		createdate="2006/6/12" />*/

  var $t = this;

  setType($t, "zino.net.HTTPRequest");

  $t.url = url || "?";
  $t.method = method || zino.net.HTTPRequest.Methods.Get;

  if (!($t.httpReqObj = zino.net.HTTPRequest.getXMLHTTPRequestObject())) {
    throw new zino.lang.Exception("Your browser is not supported!!!", zino.lang.Exception.Levels.CoreCritical);
  }

  $t.isOpen = false;
  $t.async = true;
  $t.ignoreCache = zino.config.nocache || false;
  $t.autoHeader = true;
  $t.ignoreWhite = true;

  //Events
  $t.onReadyStateChange = new zino.util.Event($t);
  $t.onRecieve = new zino.util.Event($t);
  $t.onLoad = new zino.util.Event($t);
  $t.onHTTPError = new zino.util.Event($t);

  //Private Events
  $t._onRecieve = function () {
    $t.onRecieve.raise();

    $t.isRecieved = true;
    $t.status = $t.httpReqObj.status;
    if ($t.httpReqObj.status == 200) {
      $t.response = new zino.net.HTTPResponse($t);
      if ($t.response.XML && $t.ignoreWhite) {
        removeWhite($t.response.XML.documentElement);
      }
      try {
        $t.onLoad.raise(true);
      } catch (e) {
        //alert("Loaded  Script Error\nin "+$t.url+":\n"+(e.message || e) );
        //throw e;
        //throw "salam";
        alert(new zino.lang.Exception(null, {
          source: this
        }, e, "zino.net.HTTPRequest._onRecieve", "zino.net.HTTPRequest.js", 47));
        throw new zino.lang.Exception(null, {
          source: this
        }, e, "zino.net.HTTPRequest._onRecieve", "zino.net.HTTPRequest.js", 47);
      };
    } else {
      if (!$t.onHTTPError.raise($t.status))
        $t.onLoad.raise(false);
    };

  };

  $t.httpReqObj.onreadystatechange = function () {
    $t.readyState = $t.httpReqObj.readyState;
    if ($t.httpReqObj.readyState == 4) {
      $t._onRecieve();
    }
    $t.onReadyStateChange.raise();

  };

  //Functions
  $t.setRequestHeader = function (name, value) {
    $t.httpReqObj.setRequestHeader(name, value);
  };

  $t.open = function (url) {
    url = url || $t.url;
    $t.url = url;
    if (url && (url.indexOf("?wsdl") != -1 || url.indexOf("?xsd") != -1)) $t.ignoreCache = false;
    if ($t.ignoreCache) {
      url = url + (url.indexOf("?") > 0 ? "&" : "?") + zino.net.HTTPRequest.ignoreCacheKey + "=" + (new Date()).valueOf();
    }
    if (url.indexOf("http://") == 0) {
      var lhost = "http://" + window.location.host;
      if (url.indexOf(lhost) == -1) url = lhost + "/dre/com.partia.http-1.0.proxy-1.0/go?url=" + url;
    }
    $t.httpReqObj.open(($t.method == zino.net.HTTPRequest.Methods.Post ? "POST" : "GET"), url, $t.async);
    this.isOpen = true;
  };

  $t.send = function (request) {
    $t.request = request || "";
    if (!$t.isOpen) {
      $t.open();
    }
    if ($t.method == zino.net.HTTPRequest.Methods.Post && $t.autoHeader) {
      this.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      this.setRequestHeader("Content-length", $t.request.length);
      this.setRequestHeader("Connection", "close");
    }

    try {
      $t.httpReqObj.send($t.request);
    } catch (ignore) {}
  };

  $t.load = function () {
    $t.send("");
  };

};

zino.net.HTTPRequest.Methods = {
  Get: 1,
  Post: 2
};
zino.net.HTTPRequest.ignoreCacheKey = "__ignch_r";
zino.net.HTTPRequest.getXMLHTTPRequestObject = function () {
  var xmlhttp;
  try { // Mozilla / Safari / IE7
    xmlhttp = new XMLHttpRequest();
  } catch (e) { // IE
    var XMLHTTP_IDS = new Array('MSXML2.XMLHTTP.5.0', 'MSXML2.XMLHTTP.4.0', 'MSXML2.XMLHTTP.3.0', 'MSXML2.XMLHTTP', 'Microsoft.XMLHTTP');
    var success = false;
    for (var i = 0; i < XMLHTTP_IDS.length && !success; i++) {
      try {
        xmlhttp = new ActiveXObject(XMLHTTP_IDS[i]);
        success = true;
      } catch (e) {}
    }
    if (!success) {
      return false;
    }
  }
  return xmlhttp;
};
//core.Script
zino.core.Script = function zino$core$Script(url, debug, isSource) {
  /*<init class="zino.core.Script"
			version="0.7.3a"
			author="Shayan Nojedehi"
			modifieddate="2006/8/1"
			createdate="2006/6/27" />*/

  var $t = this;
  $t.url = url;
  setType($t, "zino.core.Script");
  if (isSource) {
    $t.loaded = true;
  } else {
    $t.loaded = false;
    $t.onLoad = new zino.util.Event($t);
    $t.x = new zino.net.HTTPRequest(url);
    $t.fnc = "";
    $t.x.onLoad.add(function zino$core$Script$Request$onLoad() {
      var s = $t.x.response.text;
      var initStart;
      if ((initStart = s.indexOf("/*<init")) != -1) {
        var tInit = s.substring(initStart + 2, s.indexOf("/>*/") + 2);
        var initHolder = ce("DIV");
        initHolder.innerHTML = tInit.replace(/init/ig, "div");
        var init = initHolder.firstChild;

        var initText = "var $t=this;\n";

        initText += "$t._AUTHOR = '" + init.getAttribute("author") + "';";
        initText += "var cl = '" + (init.getAttribute("class") || init.getAttribute("className")) + "';setType($t,eval(cl),cl);";
        initText += "$t._VERSION = '" + init.getAttribute("version") + "';";
        initText += "$t._CREATEDATE = '" + init.getAttribute("createdate") + "';";
        initText += "$t._MODIFIEDDATE = '" + init.getAttribute("modifieddate") + "';";

        var className = init.getAttribute("class") || init.getAttribute("className");

        var tagName = init.getAttribute("tag");
        if (tagName) {
          var ns = init.getAttribute("ns") || "http://ns.partia.com/zino";

          s += "\n\rzino.core.RenderEngine.registerTag('" + ns + "','" + tagName + "'," + className + ");\n\r";
        };

      };

      var rgInit = /\/\*<init[^>]*\/>\*\//i;
      var rgImports = /(\/\*\!)([;<>_a-zA-Z0-9.=\s\/\n\"]*)(\*\/)/;

      if (!window._it_) window._it_ = [];
      _it_.push([rgInit, initText]);

      var fnc = s.replace(rgInit, initText);

      var r = rgImports.exec(fnc);


      var _LOADER = $t.loader = {
        onLoad: $t._onLoad
      };

      if (r) {
        fnc = zino.core.Script.parseInc(r[2], fnc);
      } else {
        fnc += "\n_LOADER.onLoad();\n"
      };

      $t.fnc = fnc;

      if ($t.debug) {
        alert(fnc);
      };

      try {
        carr("_ns_fnc_");
        _ns_fnc_.push(fnc);
        eval(fnc);
      } catch (e) {
        throw new zino.lang.Exception(null, {
          fnc: fnc,
          request: $t.x,
          source: this
        }, e, "zino.core.Script", $t.x.url);
      }

    });
    $t._onLoad = function zino$core$Script$_onLoad() {
      try {
        $t.loaded = true;
        $t.onLoad.raise();
      } catch (e) {
        //alert(["zino.core.Script.js1",(e.message || e)]);
        throw new zino.lang.Exception(null, {
          source: this
        }, e, "zino.core.Script._onLoad", "zino.core.Script.js", 80);
      }
    };
    $t.load = function zino$core$Script$load() {
      try {
        $t.x.load();
      } catch (e) {
        //alertr(["zino.core.Script.js2",(e.message || e)]);
        throw new zino.lang.Exception(null, {
          source: this
        }, e, "zino.core.Script.load", "zino.core.Script.js", 91);
      }
    };
  }
}.inherit(zino.lang.Object);
getRCName = function (ns) {
  var arr = ns.split(".");
  if (arr.length != 1) return arr[arr.length - 1];
  else return ns;
}
zino.core.Script.parseInc = function zino$core$Script$parseInc(importString, fnc) {
  var imports = importString.replace("\n", "").trim().split(";");
  var requires = [];
  var s = false;
  var incText = "\n_LOADER.onLoad();\n";

  for (var i = 0; i < imports.length; i++) {
    if (imports[i].trim() != "") {
      var im = imports[i].trim().split(" ");
      if (im[0].trim() == "import") {
        requires.push(im[1]);
      } else if (im[0].trim() == "include") {
        incText = "\n_.ns.includeC('" + im[1] + "', function zino$core$Script$parseInc$include(){\n" + incText + "\n});"
      } else if (im[0].trim() == "prepare") {
        incText = "\n_.ns.prepare('" + im[1] + "');\n" + incText;
      } else if (im[0].trim() == "register") {
        var name = getRCName(im[1]);
        if (name && name != im[1]) {
          s = true;
          incText = "\nvar " + name + "=" + im[1] + ";\n" + incText;
        }
      } else {
        throw new zino.lang.Exception("Syntax Error '" + im[0] + "' on " + importString, {
          fnc: fnc,
          importString: importString,
          index: i,
          source: this
        }, e, "zino.core.Script.parseInc", "zino.core.Script.js", 125);
      }
    }
  }

  fnc += incText;

  for (var j = 0; j < requires.length; j++) {
    fnc = "\n_.ns.includeC('" + requires[j] + "', function zino$core$Script$parseInc$include(){\n" + fnc + "\n});"
  }
  if (s) _SFnc = fnc;
  return fnc;

};
//core.ScriptManager
zino.core.ScriptManager = function zino$core$ScriptManager() {
  /*<init class="zino.core.ScriptManager"
			version="0.1.1a"
			author="Shayan Nojedehi"
			createdate="2006/6/27" />*/

  this.debug = false;
  this.scripts = {};
  this.refrences = [];
  this._TYPE = "zino.core.ScriptManager";
}.inherit(zino.lang.Object);
zino.core.ScriptManager.prototype.getPath = function zino$core$ScriptManager$load(ns, ex) {
  var ext = ex || "js";
  if (ns.indexOf("zino") == 0 || ns.indexOf("com.partiatech.diyox") == 0) return _.cmn.path + (ns.split(".")).join("/") + "." + ext;
  for (var i = 0; i < this.refrences.length; i++) {
    var sns = ns.split('.').join('/'),
      ins = this.refrences[i].ns.split('.').join('/') + "/";
    if (sns.indexOf(ins) == 0 && this.refrences[i].ext == ext) return this.refrences[i].path + sns.substring(ins.length, sns.length) + "." + ext;
  }
  return false;
};
zino.core.ScriptManager.prototype.load = function zino$core$ScriptManager$load(url, ns, onload) {
  var $t = this,
    s;
  if (!(s = this.scripts[url])) {
    s = this.scripts[url] = new zino.core.Script(url, $t.debug);
    if (_.log) {
      //if(ns) s._loadLog = _.log.addLoading("Registering " + ns);
    }
    s.onLoad.add(function zino$core$ScriptManager$load$onLoad1() {
      if (s._loadLog) s._loadLog.o.completed();
      try {
        onload && onload();
      } catch (e) {
        throw new zino.lang.Exception(null, {
          onload: onload,
          source: this
        }, e, "zino.core.ScriptManager", "zino.core.ScriptManager.js", 38);
      }
    });
    s.load();
    return s;

  } else if (!s.loaded) {
    s.onLoad.add(function zino$core$ScriptManager$load$onLoad2() {
      try {
        onload && onload();
      } catch (e) {
        throw new zino.lang.Exception(null, {
          onload: onload,
          source: this
        }, e, "zino.core.ScriptManager", "zino.core.ScriptManager.js", 49);
      }
    });
    return s;
  } else {
    try {
      onload && onload();
    } catch (e) {
      throw new zino.lang.Exception(null, {
        onload: onload,
        source: this
      }, e, "zino.core.ScriptManager", "zino.core.ScriptManager.js", 57);
    }
    return this.scripts[url];
  }
};
zino.core.ScriptManager.prototype.register = function zino$core$ScriptManager$register(ns, onLoad) {
  this.includeC(ns, function zino$core$ScriptManager$register$includeC() {
    var n = ns.split(".");
    var t = n[n.length - 1] + " = " + ns;
    eval(t);
    onLoad && onLoad();
  });
};
zino.core.ScriptManager.prototype.registerS = function zino$core$ScriptManager$registerS(ns) {
  var nns = (ns.split(".")).join("/"),
    url = this.getPath(ns);
  if (!(this.scripts[url])) this.scripts[url] = new zino.core.Script(url, false, true);
};
zino.core.ScriptManager.prototype.include = function zino$core$ScriptManager$include(url, ns, onLoad) {
  var url = url,
    sc;
  if (sc = this.scripts[url]) {
    if (!sc.loaded) {
      sc.onLoad.add(function zino$core$ScriptManager$load$onLoad2() {
        try {
          onLoad && onLoad();
        } catch (e) {
          throw new zino.lang.Exception(null, {
            onload: onLoad,
            source: this
          }, e, "zino.core.ScriptManager", "zino.core.ScriptManager.js", 38);
        }
      });
    } else {
      onLoad && onLoad();
      return this.scripts[url];
    }
  } else {
    if (ns)
      this.prepare(ns);
    //var t1 = eval(ns);
    this.load(url, ns, onLoad);
    //var t2 = eval(ns);

    /*for(var i in t1){
            if(!t1[i]) t2[i] = t1[i];//alert(i);
        }*/
  }
};
zino.core.ScriptManager.prototype.includeJs = function zino$core$ScriptManager$includeJs(ns, func) {
  var nsurl = this.getPath(ns),
    url = ns;
  if (nsurl) {
    url = nsurl;
    this.prepare(ns);
  }
  if (this.scripts[url]) return this.scripts[url];
  if (func !== undefined && (isFunc(func) || isArray(func))) _.sequence.addToEnd(ns, func);
  if (_.browser.isSafariOld) {
    var sstr = '<script type="text/javascript" src="' + url + '"><\/script>';
    //document.write('<script type="text/javascript" src="' + url + '"><\/script>');
  } else {
    var head = document.getElementsByTagName("head")[0];
    var script = document.createElement("script");
    script.src = url;
    head.appendChild(script);
  }
};
zino.core.ScriptManager.prototype.includeC = function zino$core$ScriptManager$includeC(ns, onLoad) {
  try {
    var nns = (ns.split(".")).join("/");
    this.include(this.getPath(ns), ns, onLoad);
  } catch (e) {
    alertr(["zino.core.ScriptManager.js1", (e.message || e)]);
  }
};
zino.core.ScriptManager.prototype.prepare = function zino$core$ScriptManager$prepare(ns0) {
  var ns = ns0.split(".");

  try {
    var t = "cns = " + ns[0];
    eval(t);
  } catch (e) {
    var t = ns[0] + " = {}";
    cns = eval(t);
  }


  for (var i = 1; i < ns.length; i++) {
    if (!cns[ns[i]]) {
      cns[ns[i]] = {};
    }
    cns = cns[ns[i]];
  }
};
zino.core.ScriptManager.Refrence = function zino$core$ScriptManager$Refrence(ns, path, ext) {
  /*<init class="zino.core.ScriptManager.Refrence"
			version="0.7.1a"
			author="Shayan Nojedehi"
			createdate="2006/09/03" />*/

  this.ns = ns;
  this.path = path;
  this.ext = ext || "js";
};
//core.Conf
zino.parseValue = function (val) {
  var boolpstr = "true;false;yes;no;1;0;",
    vind = boolpstr.search(val + ";");
  if (vind > -1) return val.toBoolean();
  return val;
};
zino.core.parseConfNode = function (node) {
  var $t = this;
  if (node.nodeType == 3) {
    $t.text = node.nodeValue;
    return;
  }
  if (node.attributes.length != 0) {
    for (var i = 0; i < node.attributes.length; i++) {
      var atrname = node.attributes[i].nodeName,
        atrval = node.attributes[i].value;
      if (atrval) $t[atrname] = zino.parseValue(atrval);
    }
  }
  if (node.childNodes.length) {
    $t.length = 0;
    for (var i = 0; i < node.childNodes.length; i++) {
      var cnode = node.childNodes[i],
        confobj = {};
      if (cnode.nodeType == 3) {
        $t.text = cnode.nodeValue;
        continue;
      }
      if (cnode.nodeType != 1) continue;
      $t.length++;
      zino.core.parseConfNode.call(confobj, cnode);
      $t[i] = confobj;
      if (confobj.xmlns) $t[confobj.xmlns] = confobj;
      if (confobj.name || confobj.id) $t[confobj.name || confobj.id] = confobj;
      else $t[cnode.nodeName] = confobj;
    }
  }
}; //zino.core.parseConfNode.call(this,node)
zino.loadConfig = function zino$loadConfig(url, onload) {
  var s;
  if (!(s = _.configs[url])) {
    var x = new zino.net.HTTPRequest(url),
      cnf = {
        url: url,
        loaded: false
      };
    if (!_.configs.length) cnf["nocache"] = true;
    (_.configs[_.configs.length] = _.configs[url] = cnf).req = x;
    _.configs.length++;
    x.onLoad.add(function () {
      try {
        cnf.loaded = true;
        var xdoc = x.response.XML;
        if (xdoc) zino.core.parseConfNode.call(cnf, (cnf.xmlDoc = xdoc).lastChild);
        onload && onload();
      } catch (err) {
        throw new zino.lang.Exception(null, {
          onload: onload,
          source: zino.loadConfig
        }, err, "zino.core.Configurator", "cload.js", 1783);
      }
    });
    x.load();
    return cnf;
  } else if (!s.loaded && s.req) {
    s.req.onLoad.add(function () {
      try {
        onload && onload();
      } catch (err) {
        throw new zino.lang.Exception(null, {
          onload: onload,
          source: zino.loadConfig
        }, err, "zino.core.Configurator", "cload.js", 1790);
      }
    });
    return s;
  } else {
    try {
      onload && onload();
    } catch (err) {
      throw new zino.lang.Exception(null, {
        onload: onload,
        source: zino.loadConfig
      }, err, "zino.core.Configurator", "cload.js", 1795);
    }
    return s;
  }
};
//zino.net.Cookie
zino.net.Cookie = function zino$net$Cookie(name, value, expireDate, path, domain, secure) {
  /*<init class="zino.net.Cookie"
			version="0.1.1a"
			author="Mehran Hatami"
			createdate="2006/07/05"
			modifieddate="2007/07/18" />*/
  var $t = this;
  $t._type = "zino.net.Cookie";

  $t.expireDate = expireDate || null;
  $t.name = name || null;
  $t.path = path || null;
  $t.domain = domain || null;
  $t.secure = secure || null;
  $t.value = value || null;

}
zino.net.Cookie.prototype = {
  makePhrase: function zino$net$Cookie$makePhrase() {
    var $t = this;
    var r = $t.name + '=' + escape($t.value);
    //r += ( $t.expireDate ? "; expires=" + $t.expireDate.toGMTString():"" );
    r += ($t.expireDate ? "; expires=" + $t.expireDate.toGMTString() : "");

    r += ($t.path ? "; path=" + $t.path : "");
    r += ($t.domain ? "; domain=" + $t.domain : "");
    r += ($t.secure ? "; secure=" + $t.secure : "");
    return r;
  },
  getValue: function zino$net$Cookie$getValue() {
    return ((document.cookie.match(new RegExp("(" + this.name + "=[^;]*)(;|$)")))[1] || null);
  },
  setValue: function zino$net$Cookie$setValue(value) {
    this.value = value;
    this.apply();
    return (this.value);
  },
  setExpire: function zino$net$Cookie$setExpire(value) {
    this.expireDate = value;
    this.apply();
    return (this.value);
  },
  getExpire: function zino$net$Cookie$getExpire() {
    return (this.expireDate || null);
  },
  apply: function zino$net$Cookie$apply() {
    return (document.cookie = this.makePhrase());
  }
}
//End zino.net.Cookie
//Start zino.net.CookieManager
zino.net.CookieManager = function zino$net$CookieManager() {
  /*<init class="zino.net.CookieManager"
		version="0.1.1a"
		author="Shayan Nojedehi"
		createdate="2006/7/5" />*/
  var $t = this;
  $t.items = {};
  $t.parseCookie();
};
zino.net.CookieManager.prototype = {
  parseCookie: function zino$net$CookieManager$parseCookie() {
    var cs = document.cookie.split(";");
    for (var c in cs) {
      var rItem = cs[c].split("=");
      rItem[0] = rItem[0].trim();
      this.items[rItem[0]] = new zino.net.Cookie(rItem[0], rItem[1]);
    }
  },
  add: function zino$net$CookieManager$add(cookie) {
    if (cookie._type == "zino.net.Cookie") {
      this.items[cookie.name] = cookie;
      this.items[cookie.name].apply();
    }
  },
  remove: function zino$net$CookieManager$remove(cookieName) {
    var $t = this;
    var cookie = $t.items[cookieName];
    if (cookie) {
      $t.items[cookieName].setExpire((new Date(0)));
      delete this.items[cookieName];
      this.items[cookie.name] = cookie;
      this.items[cookie.name].apply();
    }
  }
};
//End zino.net.CookieManager
//core.Loader
zino.core.Loader = function zino$Loader() {}.inherit(zino.lang.Object);
zino.core.Loader.initEnvironmentVariables = function zino$Loader$initEnvironmentVariables() {
  window._ = {
    body: {
      element: {
        "get": function () {
          return document.getElementsByTagName("body")[0];
        }
      }
    },
    win: {
      element: {
        "get": function () {
          return window;
        }
      }
    },
    context: {
      current: null,
      lastContextMenu: null,
      currentContextMenu: null,
      currentForm: null,
      isOpenContext: false,
      setCurrentContextMenu: function (contextMenu) {
        if (_.context.currentContextMenu && _.context.currentContextMenu != contextMenu) _.context.currentContextMenu.hide();
        _.context.currentContextMenu = contextMenu;
      }
    },
    tabIndexes: {
      orders: [],
      controls: {}
    },
    modernEvents: {
      ContextMenuDisplayed: false,
      onCurrentContexted: false,
      clicked: false,
      dblclicked: false,
      mouseMoved: false,
      mouseUped: false,
      mouseDowned: false,
      mouseovered: false,
      mouseOuted: false
    },
    env: {},
    config: {},
    tags: {},
    ns: new zino.core.ScriptManager(),
    nMain: null,
    r: null,
    xMain: new zino.net.HTTPRequest(""),
    ws: {},
    cmn: {
      path: "/dre/client/",
      zconfPath: "/dre/client/config.xml"
    },
    configs: {
      length: 0
    },
    icst: [],
    xml: {},
    cookieManager: new zino.net.CookieManager,
    focused: null,
    sequence: {
      __handles__: {},
      add: function (ns, p, f) {
        if (this.__handles__[ns] === undefined) this.__handles__[ns] = {
          start: [],
          end: []
        };
        if (this.__handles__[ns][p] === undefined) this.__handles__[ns][p] = [];
        if (isFunc(f)) this.__handles__[ns][p].push(f);
        else if (f instanceof Array) this.__handles__[ns][p] = this.__handles__[ns][p].concat(f);
      },
      addToStart: function (ns, f) {
        this.add(ns, "start", f);
      },
      addToEnd: function (ns, f) {
        this.add(ns, "end", f);
      },
      raise: function (ns, p) {
        if (!this.__handles__[ns] || !this.__handles__[ns][p]) return;
        var handlers = this.__handles__[ns][p];
        for (var i = 0; i < handlers.length; i++) {
          var x = handlers[i].call();
          if (x === false) break;
        }
      },
      raiseStart: function (ns) {
        this.raise(ns, "start");
      },
      raiseEnd: function (ns) {
        this.raise(ns, "end");
      }
    },
    startScript: function (ns) {
      _.sequence.raiseStart(ns)
    },
    endScript: function (ns) {
      _.sequence.raiseEnd(ns)
    }
  };
};
zino.core.Loader.init = function zino$Loader$init() {
  try {
    zino.core.Loader.initEnvironmentVariables();
    zino.config = zino.loadConfig(_.cmn.zconfPath, function load$zino$config() {
      zino.appConfig = zino.loadConfig(zino.config.common.app.confPath, function load$app$config() {
        loadZinoFramework();
      });
    });
  } catch (e) {
    alert(["zino.js1", (e.message || e)])
  }

};
zino.core.Loader.initincludes = {
  cultureManager: function initInclude$$zino$cultureManager() {
    _.cultures = new zino.core.CultureManager();
    _.cultures.load(_.config.defaultCulture);
    _.ns.includeC("zino.core.StyleManager", zino.core.Loader.initincludes.styleManager);
  },
  styleManager: function initInclude$$zino$styleManager() {
    _.styles = new zino.core.StyleManager();
    if (_.config.defaultTheme)
      _.ns.includeC("zino.core.ThemeManager", zino.core.Loader.initincludes.themeManager);

    if (_.config.defaultLang)
      _.langs.apply(_.config.defaultLang);
  },
  themeManager: function initInclude$$zino$core$ThemeManager() {
    _.themes = new zino.core.ThemeManager();
    try {
      _.themes.apply(_.config.defaultTheme);
    } catch (e) {
      alertr(["zino.js2", (e.message || e)]);
    }
  }
};

loadZinoFramework = function loadZinoFramework() {
  delete window.loadZinoFramework;
  //{Start core.RenderEngine
  _.ns.registerS("zino.core.RenderEngine");
  zino.core.RenderEngine = function zino$core$RenderEngine(ev) {
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zino.core.RenderEngine';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.1a';
    $t._CREATEDATE = '2007/8/21';
    $t._MODIFIEDDATE = 'null';
    if (ev && ev instanceof Function) $t.onrendercomplete = ev;
    this.onrender = new zino.util.Event();
    this._loadings = [];
  }.inherit(zino.lang.Object);

  zino.core.RenderEngine.prototype.addLoading = function zino$core$RenderEngine$addLoading() {
    return (this._loadings.push(1) - 1);
  };

  zino.core.RenderEngine.prototype.removeLoading = function zino$core$RenderEngine$removeLoading(i) {
    //delete this._loadings[i];
    this._loadings.pop();
    if (this._loadings.length == 0) {
      this.onrender.raise();
    }
  };

  zino.core.RenderEngine.prototype.render = function zino$core$RenderEngine$render(doc, parent) {

    if (!parent) return false;

    if (!isNode(doc))
      throw new zino.lang.Exception("Not valid node!", {
        document: doc,
        parent: parent,
        source: this
      }, null, "zino.core.EngineRender.render", "zino.core.RenderEngine.js", 31);

    this.lastChild = doc.lastChild.lastChild;
    if (doc.childNodes.length < 1) return false;
    this.renderNode(doc.firstChild, parent);
    return true;
  };
  zino.core.RenderEngine.prototype.renderNode = function zino$core$RenderEngine$renderNode(node, parent, rn) {
    var parent = (parent && parent.get && parent.get()) || (parent || null);
    var renderNext = (rn === undefined) ? true : !!rn;
    var element = (parent && parent.element && parent.element.get()) || (parent || null);
    try {
      if (!node) return false;
      if (!this.lastChild) this.lastChild = node.ownerDocument.lastChild.lastChild.lastChild;
      var $t = this;
      var haveImportNodes = false;
      if (_.tags[node.namespaceURI] && _.tags[node.namespaceURI][node.baseName]) {
        try {
          var obj = new(_.tags[node.namespaceURI][node.baseName]);
          if (parent) {
            if (node.getAttribute("id")) {
              parent[node.getAttribute("id")] = obj;
            }
            obj.jctor(node, parent);
          } else {
            obj.initX(node);
            return obj;
          }
        } catch (e) {
          throw new zino.lang.Exception(null, {
            node: node,
            source: this
          }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 61);
        }
      } else {
        //alert("nodeType : "+node.nodeType);
        switch (node.nodeType) {

          //Element
        case 1:
          switch (node.namespaceURI) {

          case "http://ns.partia.com/zino":
            //
            // ZINO zino Nodes
            //
            switch (node.baseName) {

            case "zino":
              $t.renderNode(node.firstChild, parent);
              break;

            case "config":
              _.config[node.getAttribute("id")] = node.getAttribute("value");
              break;

            case "refrence":
              _.ns.refrences.push(new zino.core.ScriptManager.Refrence(node.getAttribute("ns"), node.getAttribute("url"), node.getAttribute("ext")));
              break;
            case "head":
              var titles = node.getElementsByTagName("title"),
                lmsgs = node.getElementsByTagName("load-message");
              if (titles.length && titles[0].childNodes.length) window.document.title = titles[0].childNodes[0].nodeValue;
              if (lmsgs.length && lmsgs[0].childNodes.length) _.cmn.lmsg.text.set(lmsgs[0].childNodes[0].nodeValue);
              break;
            case "script":
              var t;
              if (t = node.getAttribute("with")) {
                var r = "var $ = $." + t + ";\n";
              } else {
                var r = "var $ = $;\n";
              };

              r += node.firstChild ? node.firstChild.nodeValue : "";
              eval("(function zino$core$RenderEngine$renderNode$script$run(){" + r + "})()");

              break;

            case "form":
              var fons = eval(ea(node.getAttribute("object"))),
                fo = fons;
              if (typeof fo == "string") {
                var frm = null;
                _.ns.prepare(fo);
                if ((frm = eval(fo)) && frm instanceof zinox.ui.controls.Form) fo = frm;
                else eval("fo = " + fo + " = new zinox.ui.controls.Form");
              };

              if (!fo) {
                throw new zino.lang.Exception("Undefined object '" + node.getAttribute("object") + "' in form", {
                  node: node,
                  source: this
                }, null, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 115);
              } else if (!(fo instanceof zinox.ui.controls.Form)) {
                throw new zino.lang.Exception("Form must be instance of zinox.ui.controls.Form!", {
                  form: fo,
                  source: this
                }, null, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 108);
              };

              try {
                fo.initX(node);
                fo.parent.set(parent);
                fo.show();
              } catch (e) {
                throw new zino.lang.Exception("Error on rendering form.", {
                  node: node,
                  parent: parent,
                  source: this
                }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 124);
              }
              break;

            case "import-js":
              var async = node.getAttribute("async") ? eval(ea(node.getAttribute("async"), "Boolean")) : false;
              var ns = node.getAttribute("ns");
              var goNext = function renderEngine$renderNode$script$importjs() {
                try {
                  $t.renderNode(node.nextSibling, parent);
                } catch (e) {
                  throw new zino.lang.Exception("Error on Including File.", {
                    node: node,
                    parent: parent,
                    source: this
                  }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 2102);
                }
              };
              if (!async) _.ns.includeJs(ns, goNext);
              else {
                _.ns.includeJs(ns);
                goNext();
              }
              break;
            case "import":
              var req = node.getAttribute("required") && node.getAttribute("required").toBoolean() || true;
              if (req) {
                haveImportNodes = true;
                if (node.getAttribute("file")) {
                  _.ns.include(node.getAttribute("file"), false, function zino$core$RenderEngine$renderNode$script$include$file() {
                    var n = node.nextSibling;
                    try {
                      $t.renderNode(n, parent);
                    } catch (e) {
                      throw new zino.lang.Exception("Error on Including File.", {
                        node: node,
                        parent: parent,
                        source: this
                      }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 134);
                    }
                  });
                } else {
                  _.ns.includeC(node.getAttribute("ns"), function zino$core$RenderEngine$renderNode$include$ns() {
                    var n = node.nextSibling;
                    try {
                      $t.renderNode(n, parent);
                    } catch (e) {
                      throw new zino.lang.Exception("Error on Including Namespace.", {
                        node: node,
                        parent: parent,
                        source: this
                      }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 136);
                    }
                  });
                }
              } else {
                if (node.getAttribute("file")) {
                  _.ns.include(node.getAttribute("file"), false);
                } else {
                  _.ns.includeC(node.getAttribute("ns"));
                }
              }
              break;

            case "import-css":
              try {
                _.styles.load(node.getAttribute("url"));
              } catch (e) {
                throw new zino.lang.Exception("Error on import css file.", {
                  node: node,
                  parent: parent,
                  source: this
                }, e, "zino.core.RenderEngine", "zino.core.RenderEngine.js", 152);
              }
              break;

            case "import-element":
              var obj = eval(ea(node.getAttribute("object")));
              if (typeof obj != "object")
                throw new zino.lang.Exception("Cannot import " + node.getAttribute("object") + "!", {
                  object: obj,
                  node: node,
                  source: this
                }, e, "import-element", "zino.core.RenderEngine.js", 159);
              parent.element.get().appendChild(obj);
              break;

            case "import-control":
              var obj = eval(ea(node.getAttribute("object")));
              if (!(obj instanceof zinox.ui.Control))
                throw new zino.lang.Exception("Cannot import " + node.getAttribute("object") + "!", {
                  object: obj,
                  node: node,
                  source: this
                }, e, "import-control", "zino.core.RenderEngine.js", 166);
              obj.parent.set(parent);
              break;

            case "import-literal":
              var url = eval(ea(node.getAttribute("url")));
              _.langs.importLiteral(url, node.getAttribute("dynamic") ? node.getAttribute("dynamic").toBoolean() : true);
              break;

            case "import-node":

              var xp = node.getAttribute("select") || ".";

              var nsr = node.getAttribute("ns-resolver") ? eval(ea(node.getAttribute("ns-resolver"))) : false;

              var clone = node.getAttribute("clone") && node.getAttribute("clone").toBoolean() || false;

              var parentNode = node.parentNode;
              var url;
              if (url = node.getAttribute("url")) {
                var req = node.getAttribute("required") && node.getAttribute("required").toBoolean() || true;


                var xr = new zino.net.HTTPRequest(url);

                if (req) {
                  haveImportNodes = true;
                  var ol = function zino$core$RenderEngine$renderNode$import$node() {
                    if (nsr) setNSResolver(xr.response.XML, nsr);
                    var rn = zino.core.RenderEngine.importNode(parentNode, node, xr.response.XML, xp, clone);
                    node.parentNode.removeChild(node);
                    $t.renderNode(rn, parent);
                  };
                } else {
                  throw new zino.lang.Exception("`Not Required` import-node from url is not implemented yet!", {
                    url: url,
                    node: node,
                    source: this
                  }, e, "import-control", "zino.core.RenderEngine.js", 197);
                }


                xr.onLoad.add(ol);
                xr.load();

              } else {
                var doc = node.getAttribute("doc") ? eval(ea(node.getAttribute("doc"))) : node.parentNode;
                var haveImportNodes = false;
                if (nsr) setNSResolver(doc, nsr);
                var rn = zino.core.RenderEngine.importNode(parentNode, node, doc, xp, clone);
                node.parentNode.removeChild(node);
                $t.renderNode(rn, parent);
              }



              break;

            default:
              //throw new zino.lang.Exception("Unknown tag: "+node.namespaceURI+" : "+node.baseName,{node:node,source:this},null,"Unknown tag","zino.core.RenderEngine.js",218);
              break;
            }

            break;

          case "http://www.w3.org/1999/xhtml":
            //
            // XHTML Implementation & Normalization
            //
            switch (node.baseName.toLowerCase()) {

            case "html":
              object["html"] = node;

            case "head":
              object["head"] = node;

            case "body":
              object["body"] = node;

            case "tr":
              var tr = parent.element.get().insertRow(parent.element.get().rows.length);
              copyAtrributes(node, tr);
              var htmlControl = new zinox.ui.controls.HtmlControl(tr, parent);
              if (!htmlControl.element.get().baseName)
                htmlControl.element.get().baseName = node.baseName;
              var n = htmlControl.element.get();
              parent.controls.add(htmlControl);
              if (node.getAttribute("id")) parent[node.getAttribute("id")] = htmlControl;
              $t.renderNode(node.firstChild, htmlControl);
              break;

            case "td":
              var td = parent.element.get().insertCell(parent.element.get().cells.length);
              copyAtrributes(node, td);
              var htmlControl = new zinox.ui.controls.HtmlControl(td, parent);
              if (!htmlControl.element.get().baseName)
                htmlControl.element.get().baseName = node.baseName;
              var n = htmlControl.element.get();
              parent.controls.add(htmlControl);
              n.colSpan = node.getAttribute("colspan") || 1;
              n.rowSpan = node.getAttribute("rowspan") || 1;
              if (node.getAttribute("id")) parent[node.getAttribute("id")] = htmlControl;
              $t.renderNode(node.firstChild, htmlControl);
              break;

            default:
              var newNode = ce(node.baseName);
              copyAtrributes(node, newNode);
              var htmlControl = new zinox.ui.controls.HtmlControl(newNode);
              if (!htmlControl.element.get().baseName)
                htmlControl.element.get().baseName = node.baseName;
              htmlControl.initX(node);
              parent.controls.add(htmlControl);
              if (node.getAttribute("id")) parent[node.getAttribute("id")] = htmlControl;
              $t.renderNode(node.firstChild, htmlControl);
              break;
            }
            break;

          case "http://ns.partia.com/zinox/xml/ws":
            switch (node.baseName.toLowerCase()) {
            case "import":
              var url = eval(ea(node.getAttribute("url"))),
                wsonload = null,
                wsns = null,
                sns = null;
              if (sns = node.getAttribute("ns")) {
                _.ns.prepare(sns);
                wsns = eval(sns);
              };
              if (node.getAttribute('onload')) wsonload = eval(ea(node.getAttribute('onload'), "function"));

              //if(_.ws.ref && _.ws.ref.addNewServiceRefrence) _.ws.ref.addNewServiceRefrence(url,wsns,wsonload);
              //else _.ns.includeC("zinox.xml.ws.WSRef",function(){_.ws.ref.addNewServiceRefrence(url,wsns,wsonload);});

              wsImport(url, wsns, wsonload);

              break;
            default:
              break;
            }
            break;
          case "http://ns.partia.com/zinox/util/wf":
            switch (node.baseName.toLowerCase()) {
            case "process":
              var zwfp = new zinox.util.wf.ZWFProcess();
              zwfp.initX(node);
              break;
            }
          default:
            throw new zino.lang.Exception("Unknown namespace :" + node.namespaceURI + ", on" + node.xml, {
              node: node,
              source: this
            }, null, "Unknown namespace", "zino.core.RenderEngine.js", 266);
            break;
          }


          break;

        case 3: //Text Node
          parent.element.get().appendChild(ct(node.nodeValue));
          break;

        case 4: //CDATA
          parent.element.get().appendChild(node);
          break;

        case 7: //Proccessing Instructions
          break;

        case 8: //Comment
          break;

        default:
          throw new zino.lang.Exception("Unknown node type :" + node.nodeType + ":" + node.xml, {
            node: node,
            source: this
          }, null, "Unknown node type", "zino.core.RenderEngine.js", 288);

        }

      }

      if (renderNext && !haveImportNodes) {
        $t.renderNode(node.nextSibling, parent);
      }
      if ($t.lastChild !== undefined && node === $t.lastChild) {
        if ($t.onrendercomplete) $t.onrendercomplete();
        _.body.onRenderComplete.raise();
        delete $t.lastChild;
      }
      return true;
    } catch (e) {
      throw new zino.lang.Exception("Error on rendering.", {
        node: node,
        source: this
      }, e, "Error on rendering", "zino.core.RenderEngine.js", 301);
    }
  };

  zino.core.RenderEngine.importNode = function zino$core$RenderEngine$importNode(parent, node, doc, xp, clone) {
    var n = doc.selectNodes(xp);
    var r = null;
    for (var i = 0; i < n.length; i++) {
      var an = clone ? n[i].cloneNode(true) : n[i];
      an = parent.insertBefore(an, node);
      if (i == 0) r = an;
    }
    return r;
  };

  zino.core.RenderEngine.registerTag = function zino$core$RenderEngine$registerTag(ns, tag, fnc) {
    if (!fnc.inherits(zino.lang.Object))
      throw new zino.lang.Exception("Cannot register not zino.lang.Component classes!\n\rFor " + ns + ":" + tag + "\n\r" + fnc, {
        ns: ns,
        tag: tag,
        fnc: fnc,
        source: this
      }, {}, "zino.core.RenderEngine.registerTag", "zino.core.RenderEngine.js", 318);

    if (!_.tags[ns]) _.tags[ns] = [];
    _.tags[ns][tag] = fnc;
  };
  //End core.RenderEngine}
  _.r = new zino.core.RenderEngine();
  //{Start core.Logger
  _.ns.registerS("zino.core.Logger");
  zino.core.Logger = function zino$core$Logger() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.core.Logger';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/6/29';
    $t._MODIFIEDDATE = 'null';
    this.logs = new Array();
    this.onLog = new zino.util.Event();
  }.inherit(zino.lang.Object);

  zino.core.Logger.prototype.addLoading = function zino$core$Logger$addLoading(txt) {
    var $t = this;
    return this.add({
      type: "loading",
      text: txt,
      completed: function zino$core$Logger$addLoading$completed() {
        $t.addLoadingCom(this);
      }
    });
  };

  zino.core.Logger.prototype.addLoadingCom = function zino$core$Logger$addLoadingCom(o) {
    return this.add({
      type: "loadingCom",
      loading: o
    });
  };

  zino.core.Logger.prototype.add = function zino$core$Logger$add(o) {
    var i = this.logs[this.logs.length] = {
      o: o,
      date: new Date()
    };
    //new zino.util.DateTime( (new Date()).valueOf() ) };
    this.onLog.raise(i);
    return i;
  };
  //End core.Logger}
  _.log = new zino.core.Logger();
  //{Start core.MessageViewer
  _.ns.registerS("zino.core.MessageViewer");
  zino.core.MessageViewer = function zino$MessageViewer(node, obj, v) {
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zino.core.MessageViewer';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/6/25';
    $t._MODIFIEDDATE = 'null';

    this.node = node;
    this._parent = v;
    this.ph = obj;

    this.messageBoxes = [];
    this.messages = [];
    this.checkAll = [];
    this.render();
    this.opacity = 70;
    this.fadeStep = 5;
    this.timeoutStep = 20;
    this.isFinished = false;
    _.log.onLog.add(function zino$MessageViewer$onLog(log) {
      switch (log.o.type) {
      case "loading":
        log.o._msg = $t.showMessage({
          text: log.o.text,
          type: "loading"
        });
        break;

      case "loadingCom":
        log.o.loading._msg.finish();
        break;

      }
    });
  }.inherit(zino.lang.Object);

  zino.core.MessageViewer.prototype = {

    render: function zino$MessageViewer$render() {
      var $t = this;
      $t._e = gel("loadingMainPanel"); //ce("DIV","loadingMainPanel");

      $t.logElement = gel("loadingMainPanelLog");
      //$t._e.innerHTML = '<style>.loadingMainPanel{filter:alpha(opacity=100);-moz-opacity:1;opacity:1;background-color:#FFFFFF; vertical-align: middle; width: 100%; height: 100%; position: absolute;} .fs{width:100%;height:100%;} .fw{width:100%;} .cm{vertical-align:middle;text-align:center;} .loadingText{font-family: Arial,Helvetica,sans-serif;font-size: 11px;color:#333333;text-align: left;}</style>';
      //$t._e.innerHTML +='<table class="fs"><td class="cm"><table cellspacing="5" cellpadding="0" align="center"><tr><td><img src="../_images/ZINO.jpg"/></td></tr><tr><td class="loadingText">Loading...</td></tr></table></td></tr></table>';
      //$t.ph.appendChild($t._e);
    },
    onEndLoad: function zino$MessageViewer$onEndLoad() {
      var $t = this;
      $t.checkAll.pop();
      if ($t.checkAll.length == 0) {
        if (!_.config.defaultTheme || $t.checkThemeIsLoaded()) {
          $t.onFinish();
        } else {
          _.themes.onfirstthemeload.add(function zino$MessageViewer$Theme$onLoad() {
            $t.onFinish();
          });
        };
      };
    },
    checkThemeIsLoaded: function zino$MessageViewer$checkThemeIsLoaded() {
      return (_.themes.current != null);
    },
    onFinish: function zino$MessageViewer$onFinish() {
      //this._e.style.display = "none";
      //var mInterval = setInterval("this.crossFade()",10);
      this.isFinished = true;
      this.fadeHide();
    },
    onStart: function zino$MessageViewer$onStart() {
      this.isFinished = false;
      if (this.opacity < 10) {
        this.fadeShow();
      }
    },
    fadeHide: function zino$MessageViewer$crossFadeHide() {
      //filter:alpha(opacity=90);-moz-opacity:0.9;opacity:0.9;
      var $t = _.mv;
      $t.opacity = $t.opacity - $t.fadeStep;
      $t._e.style.opacity = $t._e.style.MozOpacity = $t.opacity / 100;
      $t._e.style.filter = "alpha(opacity=" + $t.opacity + ")";
      if ($t.opacity < 10) {
        $t._e.style.display = "none";
        /*$t.opacity = 100;
                $t._e.style.opacity = $t._e.style.MozOpacity = $t.opacity/100;
                $t._e.style.filter = "alpha(opacity=" + $t.opacity + ")";*/
      } else {
        setTimeout($t.fadeHide, $t.timeoutStep);
      }
    },
    fadeShow: function zino$MessageViewer$crossFadeShow() {
      //filter:alpha(opacity=90);-moz-opacity:0.9;opacity:0.9;
      //this._e.style.display = "";
      var $t = _.mv;
      if ($t._e.style.display == "none") {
        $t._e.style.display = "";
      }
      $t.opacity = $t.opacity + $t.fadeStep;
      $t._e.style.opacity = $t._e.style.MozOpacity = $t.opacity / 100;
      $t._e.style.filter = "alpha(opacity=" + $t.opacity + ")";
      if ($t.opacity < 90 && !$t.isFinished) {
        setTimeout($t.fadeShow, $t.timeoutStep);
      } else if ($t.isFinished)
        $t.fadeHide();
    },
    showMessage: function zino$MessageViewer$showMessage(obj) {
      var $t = this;
      this.onStart();
      this.checkAll.push(this.checkAll.length - 1);
      var row = $t.logElement.insertRow($t.logElement.rows.length);
      var cell = row.insertCell(row.cells.length);
      cell.setAttribute("nowrap", "nowrap");
      msg = new zino.core.Message(obj, cell, $t);
      return msg;
    }

  };
  zino.core.Message = function zino$core$Message(node, obj, v) {
    /*<init class="zino.core.Message"
                version="0.1.1a"
                author="Shayan Nojedehi"
                createdate="2006/6/25" />*/
    var $t = this;
    $t.node = node;
    $t._parent = v;
    $t.ph = obj;

    this.delay = 250;
    this.node = node;
    this.render();
  };

  zino.core.Message.prototype = {

    render: function zino$core$Message$render() {
      var $t = this;

      $t._e = ce("DIV", "mesMain");
      $t._e.appendChild(ct($t.node.text));

      $t._e.appendChild(ct(" "));
      $t.stat = ce("SPAN");
      $t.stat.appendChild(ct(" ..."));

      $t._e.appendChild($t.stat);

      $t.ph.appendChild($t._e);
    },

    finish: function zino$core$Message$finish() {
      var $t = this;

      $t.stat.removeChild($t.stat.firstChild);
      $t.stat.className = "mvDone";
      $t.stat.appendChild(ct("Done"));

      setTimeout(function zino$core$Message$finish$setTimeout() {
        $t.hide();
      }, $t.delay);
    },

    hide: function zino$core$Message$hide(a) {
      this._e.style.display = "none";
      this._parent.onEndLoad();
    }

  };
  //End core.MessageViewer}
  _.mv = new zino.core.MessageViewer(null, _.body.element.get());
  //{Start lang.Property
  _.ns.registerS("zino.lang.Property");
  zino.lang.Property = function zino$lang$Property(type, getter, setter, readOnly) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.lang.Property';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.4a';
    $t._CREATEDATE = '2006/10/31';
    $t._MODIFIEDDATE = '2007/08/14';
    setType($t, type || zino.Variant);

    $t.bindTarget = {
      property: null,
      index: -1
    };
    $t.bindedProperties = [];
    $t.readOnly = readOnly || false;
    $t.onset = $t.onchange = new zino.util.Event($t);
    $t.onbeforeset = new zino.util.Event($t);
    $t.setter = setter || zino.lang.Property.defaultSetter;
    $t.getter = getter || zino.lang.Property.defaultGetter;
    $t.value = null;
    $t.toString = function zino$lang$Property$toString() {
      return $t.get.apply($t, arguments) + "";
    };
  }.inherit(zino.lang.Object);

  zino.lang.Property.prototype.get = function zino$Property$get() {
    return this.getter.apply(this, arguments);
    //return this.getter(arguments);
  };
  zino.lang.Property.prototype.set = function zino$lang$Property$set(value) {
    var $t = this;
    if (value && $t.__type__ === String && typeof (value) == "object" && value.resource) {
      carr("_resjp_");
      _resjp_.push(value);
      var ctrl = value.resource;
      if (ctrl instanceof Object) {
        var pg = value.form || ctrl.getPage();
        if (!pg.resJ) pg = ctrl.getForm();
        $t.valueField = ctrl.id;
        if (ctrl.text && $t === ctrl.text) $t.valueField += ".text";
        else if (ctrl.value && $t === ctrl.value) $t.valueField += ".value";
        else $t.valueField += ".text";
      } else {
        var pg = value.form;
        if (!(pg instanceof zinox.ui.controls.Form) && !pg.resJ) {
          pg = pg.getPage()
          if (!pg.resJ) pg = pg.getForm();
        }
        $t.valueField = ctrl;
      }
      pg.resJ.propList.push($t);
      eval("value=pg.resJ.documentElement." + $t.valueField);
      if (!value || typeof (value) != "string") return void(0);
    }
    if ($t.readOnly || ($t.value == value && (($t.value instanceof zino.lang.Property && value instanceof zino.lang.Property) || (!($t.value instanceof zino.lang.Property) && !(value instanceof zino.lang.Property)))))
      return void(0);

    var oldValue = $t.value;
    // Raise Events Before Set
    $t.onbeforeset.raise(oldValue, value);

    $t.value = value;
    if (value instanceof zino.lang.Property && !(value instanceof zinox.data.DataProperty)) {
      if (arguments.length > 1)
        throw new zino.lang.Exception("Wrong number of argument in setter or wrong return type for indexer.\r\nreturn type of indexer getters must be zino.lang.Property.", {
          args: arguments,
          source: this
        }, null, "zino.lang.Property.set", "zino.lang.Property.js", 30);
      // Bind to Property
      $t.bindTo(value);
    } else {
      // Set Value
      $t.setter.apply($t, arguments);

      if ($t.bindTarget.property)
        $t.bindTarget.property.set.apply($t.bindTarget.property, arguments);

      // Set Value to Binded Properties
      for (var i = 0; i < $t.bindedProperties.length; i++) {
        $t.bindedProperties[i].set(value);
      }
    }
    // Raise events after set value
    $t.onset.raise(oldValue, value);
    return void(0);
  };

  zino.lang.Property.prototype.unbind = function zino$lang$Property$unbind() {
    // Unbind from Property
    if (this.bindTarget.property != null) {
      this.bindTarget.property.bindedProperties.splice(this.bindTarget.index, 1);
      this.bindTarget = {
        property: null,
        index: -1
      };
    }
  };

  zino.lang.Property.prototype.bindTo = function zino$lang$Property$bindTo(bindTargetProperty) {
    var $t = this;
    // Bind to Property
    if (!(bindTargetProperty instanceof zino.lang.Property))
      throw new zino.lang.Exception("Cannot bind to none Propery objects.", {
        bindTarget: bindTarget,
        args: arguments,
        source: this
      }, null, "zino.lang.Property.bindTo", "zino.lang.Property.js", 58);
    if (!isInstanceOf(bindTargetProperty, getType($t)))
      throw new zino.lang.Exception("Type Mismatch! Cannot " + getType(bindTargetProperty) + " Proprty bind to " + getType($t) + " Property.", {
        bindTargetProperty: bindTargetProperty,
        args: arguments,
        source: this
      }, null, "zino.lang.Property.bindTo", "zino.lang.Property.js", 68);
    $t.unbind();
    $t.bindTarget.property = bindTargetProperty;

    $t.bindTarget.index = bindTargetProperty.bindedProperties.push($t);

    $t.set(bindTargetProperty.get());
  };

  zino.lang.Property.defaultSetter = function zino$lang$Property$defaultSetter(value) {
    this.value = value;
  };

  zino.lang.Property.defaultGetter = function zino$lang$Property$defaultGetter() {
    if (this.value) return (this.bindTarget.property) ? (this.value.get ? this.value.get() : this.value) : this.value;
    else null;
  };
  //End lang.Property}

  _.ns.prepare("zinox.data");
  //Start zinox.data.DataProperty
  _.ns.registerS("zinox.data.DataProperty");
  zinox.data.DataProperty = function zinox$data$DataProperty(_type) {
    arguments.callee.superClass.apply(this, arguments);
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zinox.data.DataProperty';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2007/09/01';
    $t._MODIFIEDDATE = '2007/09/01';

    setType(this, _type ? _type : zino.Variant);

    var _status = zino.util.BindStatus.Pending;
    $t.status = new zino.lang.Property(zino.util.BindStatus,
      function zinox$data$DataProperty$$status$$getter() {
        return _status;
      },
      function zinox$data$DataProperty$$status$$setter(value) {
        _status = value;
      }
    );

  }.inherit(zino.lang.Property);
  //End zinox.data.DataProperty

  //Start zino.util._base
  _.ns.registerS("zino.util._base");
  zino.util.ABindStatus = new zino.lang.Enum({
    ok: "Ok",
    loading: "Loading",
    updating: "Updating",
    invalid: "Invalid",
    failed: "Failed",
    pending: "Pending"
  });
  zino.util.BindStatus = new zino.lang.Enum({
    Ok: "Ok",
    Loading: "Loading",
    Updating: "Updating",
    Invalid: "Invalid",
    Failed: "Failed",
    Pending: "Pending"
  });
  zino.util.BindableStatus = {
    Ok: "Ok",
    Loading: "Loading",
    Updating: "Updating",
    Invalid: "Invalid",
    Failed: "Failed"
  };
  //End zino.util._base

  //{Start lang.Component
  _.ns.registerS("zino.lang.Component");
  zino.lang.Component = function zino$lang$Component() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.lang.Component';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.4a';
    $t._CREATEDATE = '2007/07/16';
    $t._MODIFIEDDATE = '2007/08/08';
    $t.id = null;
    $t.form = null;
    var parent = false;
    $t.parent = new zino.lang.Property(zino.lang.Component,
      function parent$$getter() {
        return parent;
      },
      function parent$$setter(value) {
        parent = value;
      }
    );
    $t.onrender = new zino.util.Event();
  }.inherit(zino.lang.Object);
  zino.lang.Component.prototype.jctor = function zino$Jacy$jctor(node, parent) {
    this.form = parent.form;
    this.parent.set(parent);
    this.initX(node);
  };
  zino.lang.Component.prototype.initX = function zino$Jacy$initX(node) {
    setNSResolver(node, {
      zino: "http://ns.partia.com/zino"
    });
    if (node.getAttribute("id")) this.id = node.getAttribute("id");
  };
  //End lang.Component}
  //{Start zino.io.File
  zino.io.File = function zino$io$File( /*String*/ pathOrNs, /*String*/ ext) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.io.File';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.4a';
    $t._CREATEDATE = '2007/07/16';
    $t._MODIFIEDDATE = '2007/08/08';
    $t.onload = new zino.util.Event($t);
    $t.onerror = new zino.util.Event($t);
    var path = _.ns.getPath(pathOrNs || "", ext || null);
    if (pathOrNs && path == false) path = pathOrNs;
    $t.path = new zino.lang.Property(String, function path$$getter() {
      return path;
    }, function path$$setter(value) {
      path = value;
    });
    var separator = false;
    $t.separator = new zino.lang.Property(String, function separator$$getter() {
      return separator;
    });
    var name = false;
    $t.name = new zino.lang.Property(name, function name$$getter() {
      return name;
    });
    $t.contentText = null;
    $t.contentXml = null;
    $t.load();
  }.inherit(zino.lang.Object);
  zino.io.File.prototype.load = function zino$io$File$load() {
    var $t = this,
      path = $t.path.get();
    if (path) {
      var req = new zino.net.HTTPRequest(path);
      req.onLoad.add(function () {
        $t.onload.raise($t.contentText = this.response.text, $t.contentXml = this.response.XML);
      });
      req.onHTTPError.add(function () {
        $t.onerror.raise();
      });
      req.load();
    }
  };
  //End zino.io.File}
  //{Start core.LiteralManager
  _.ns.registerS("zino.core.LiteralManager");
  zino.core.LiteralManager = function zino$core$LiteralManager() {
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zino.LanguageManager';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2008/02/26';
    $t._MODIFIEDDATE = 'null';
    $t.literalUrls = {};
    $t.langs = {};
    $t.dynamicLiterals = [];
    $t.literals = {};
    $t.currentLang = null;
  }.inherit(zino.lang.Object);
  zino.core.LiteralManager.prototype.importLiteral = function zino$core$LiteralManager$importLiteral(url, dynamic) {
    var $t = this;
    if (!$t.literalUrls[url]) {
      $t.literalUrls[url] = true;
      if (dynamic) $t.dynamicLiterals.push(url);
      $t._loadFromUrl(url);
    }
  };
  zino.core.LiteralManager.prototype.refreshLiterals = function zino$core$LiteralManager$refreshLiterals() {
    var $t = this;
    for (var i = 0; i < $t.dynamicLiterals.length; i++) $t._loadFromUrl($t.dynamicLiterals[i]);
  };
  zino.core.LiteralManager.prototype._loadFromUrl = function zino$core$LiteralManager$_loadFromUrl(url) {
    var $t = this,
      x = new zino.net.HTTPRequest(mp(url));
    x.onLoad.add(function zino$LiteralManager$_loadFromUrl$onLoad() {
      var ln = x.response.XML.getAttribute("language");
      if (!ln) throw new zino.lang.Exception("literal-set problem on " + url, {
        source: $t
      }, null, "zino.core.LiteralManager.importLiteral", "zino.core.LiteralManager.js", 28);
      if (!$t.langs[ln]) $t.langs[ln] = {};
      $t._importLiteralFromNode(ln, x.response.XML, "");
    });
    x.load();
  };
  zino.core.LiteralManager.prototype._importLiteralFromNode = function zino$core$LiteralManager$_importLiteralFromNode(ln, node, pre) {
    var $t = this;
    for (var i = 0; i < node.childNodes.length; i++) {
      var cn = node.childNodes[i];
      if (cn.baseName == "literal-group") $t._importLiteralFromNode(ln, cn, (pre ? pre + "." : "") + cn.getAttribute("id"));
      else if (cn.baseName == "literal") {
        var n = pre + "." + cn.getAttribute("id");
        $t.langs[ln][n] = cn;
        if (!$t.literals[n]) $t.literals[n] = new zino.core.Literal();
        if (ln == $t.currentLang) $t.literals[n].setNode(cn);
      }
    }
  };
  zino.core.LiteralManager.prototype.applyLanguage = function zino$core$LiteralManager$applyLanguage(ln) {
    var $t = this;
    $t.currentLang = ln;
    for (var i in $t.literals) $t.literals[i].setNode(($t.langs[ln] && $t.langs[ln][i]) || null);
  };
  zino.core.LiteralManager.prototype.createElement = function zino$core$LiteralManager$createElement(ln) {
    var $t = this,
      e = ce("span");
    var l = this.literals[ln] || (this.literals[ln] = new zino.core.Literal());
    l.addElement(e);
    return e;
  };
  zino.core.Literal = function zino$core$Literal() {
    var $t = this;
    $t.elements = [];
    $t.node = null;
  };
  zino.core.Literal.prototype.setNode = function zino$core$Literal$setNode(node) {
    var $t = this;
    $t.node = node;
    for (var i = 0; i < $t.elements.length; i++) $t.elements[i].innerHTML = $t.getHTML();
  };
  zino.core.Literal.prototype.addElement = function zino$core$Literal$addElement(e) {
    var $t = this;
    $t.elements.push(e);
    if ($t.node) e.innerHTML = $t.getHTML();
  };
  zino.core.Literal.prototype.getHTML = function zino$core$Literal$getHTML() {
    var $t = this,
      s = "";
    if (!$t.node) return "";
    for (var j = 0; j < $t.node.childNodes.length; j++) s += $t.node.childNodes[j].xml;
    return s;
  };
  //End core.LiteralManager}
  _.langs = new zino.core.LiteralManager();
  //{Start collections.ArrayList
  _.ns.registerS("zino.collections.ArrayList");
  zino.collections.ArrayList = function zino$collections$ArrayList() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.collections.ArrayList';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.2a';
    $t._CREATEDATE = '2006/10/11';
    $t._MODIFIEDDATE = '2007/07/18';
    if (this instanceof arguments.callee) {
      this._type_ = arguments.callee._type_ || arguments[2] || zino.Variant;
      this.upperBound = arguments.callee.upperBound || arguments[1] || null;
      this.ArrayList.apply(this, arguments);
    } else {
      var newArrayList = function () {
        this.ArrayList.apply(this, arguments);
      }.inherit(zino.collections.ArrayList);
      newArrayList.upperBound = arguments[0] || null;
      newArrayList._type_ = arguments[1] || zino.Variant;
      return newArrayList;
    }
  }.inherit(zino.lang.Object);
  zino.collections.ArrayList.prototype = {
    ArrayList: function (arr) {
      var $t = this;
      $t.onbeforeadd = new zino.util.Event($t);
      $t.onbeforeremove = new zino.util.Event($t);
      $t.onadd = new zino.util.Event($t);
      $t.onremove = new zino.util.Event($t);

      $t.handleIds = {};
      $t.idIndexes = {};
      $t.item = [];

      $t.length = 0;

      if (arr) $t.addArray(arr);
    },
    getId: function (id, newItem) {
      var $t = this;
      if (!id) {
        if (newItem && newItem instanceof zino.lang.Component) {
          id = newItem.id;
        }
        if (!id) {
          var i = $t.length * 1;
          while ($t.idIndexes[id = "item" + i] != undefined) {
            i++;
          }
        }
      } else {
        if (id.trim() == "" || !isNaN(id.trim().substring(0, 1) * 1))
          throw new zino.lang.Exception("Id of newItem cannot start with Number.", {
            id: id,
            newItem: newItem,
            source: this
          }, null, "zino.collections.ArrayList.add", "zino.collections.ArrayList.js", 36);
      }

      return id + "";
    },
    getItemInfo: function zino$collections$ArrayList$getItemInfo(i /* i = item or id or index */ ) {
      var index = -1,
        id = "",
        handle = -1,
        item = null;
      if (i != 0 && !i) return false;
      var t = typeof i;
      switch (t) {
      case "string":
        handle = zino.getHandle(item = this.item[index = this.idIndexes[id = i]]);
        break;
      case "number":
        id = this.handleIds[handle = zino.getHandle(item = this.item[index = i])];
        break;
      case "object":
        index = this.idIndexes[id = this.handleIds[handle = zino.getHandle(item = i)]];
        break;
      default:
        //throw new zino.lang.Exception("Item does not exist!",{t:t,i:i,source:this},null,"zino.collections.ArrayList.getItemInfo","zino.collections.ArrayList.js",58);
        return false;
      }

      return {
        "item": item,
        "index": index,
        "id": id,
        "handle": handle
      };
    },
    get: function zino$collections$ArrayList$get(i) {
      var itemInfo = this.getItemInfo(i);
      return itemInfo ? itemInfo.item : null;
    },
    forEach: function (f) {
      var $t = this;
      if (isFunc(f)) {
        for (var i = 0; i < $t.item.length; i++) {
          var itemInfo = this.getItemInfo(i);
          f.apply(this, [itemInfo.item, itemInfo.id, itemInfo.index, itemInfo.handle]);
        }
      } else return;
    },
    indexOf: function zino$collections$ArrayList$indexOf(i) {
      var itemInfo = this.getItemInfo(i);
      return (itemInfo.index !== undefined) ? itemInfo.index : -1;
    },
    repairIndexes: function zino$collections$ArrayList$repairIndexes(index) {
      var $t = this;
      index = index ? index : 0;
      for (var i = index; i < $t.item.length; i++) {
        $t.idIndexes[$t.handleIds[zino.getHandle($t.item[i])]] = i;
        $t[i] = $t.item[i];
      }
    },
    add: function zino$collections$ArrayList$add(newItem, id) {
      return this.addToIndex(newItem, false, id);
    },
    addToIndex: function zino$collections$ArrayList$addToIndex(newItem, index, id) {
      var $t = this;
      if ($t.length == $t.upperBound) {
        throw new zino.lang.Exception("You Cannot add item over bound!", {
          id: id,
          newItem: newItem,
          bound: $t.upperBound,
          source: this
        }, null, "zino.collections.ArrayList.add", "zino.collections.ArrayList.js", 96);
      }
      if (!newItem || (typeof newItem != "object") || !isInstanceOf(newItem, $t._type_))
        throw new zino.lang.Exception("Not valid Item.", {
          id: id,
          newItem: newItem,
          source: this
        }, null, "zino.collections.ArrayList.add", "zino.collections.ArrayList.js", 98);

      $t.onbeforeadd.raise(newItem, id);
      id = $t.getId(id);

      if ((typeof (index) == "number" || index instanceof Number) && index < $t.item.length && -1 < index)
        $t.item = Array.prototype.concat($t.item.slice(0, index), newItem, $t.item.slice(index));
      else
        $t.item.push(newItem);

      $t.idIndexes[$t.handleIds[zino.getHandle(newItem)] = id] = index;
      $t[id] = newItem;
      $t.length = $t.item.length;

      $t.repairIndexes(index);

      $t.onadd.raise(newItem, id, index);

      return newItem;
    },
    remove: function zino$collections$ArrayList$remove(i /* i = item or id or index */ ) {
      var $t = this;
      var itemInfo = $t.getItemInfo(i);
      if (!itemInfo)
        return false;
      if ($t.onbeforeremove.raise(itemInfo.item, itemInfo.id, itemInfo.index, itemInfo.handle) == false)
        return false;

      this.item.splice(itemInfo.index, 1);

      delete this[itemInfo.id];
      delete this[itemInfo.index];

      delete this.idIndexes[itemInfo.id];
      delete this.handleIds[itemInfo.handle];
      delete this[this.item.length];

      $t.repairIndexes(itemInfo.index);

      $t.length = $t.item.length;
      this.onremove.raise(itemInfo.item, itemInfo.id, itemInfo.index, itemInfo.handle);
    },
    addArrayToIndex: function zino$collections$ArrayList$addArrayToIndex(newArray, index, idArray) {
      try {
        for (var i = 0; i < newArray.length; i++) {
          if (idArray && idArray[i])
            this.addToIndex(newArray[i], index + i, idArray[i]);
          else
            this.addToIndex(newArray[i], index + i);
        }
      } catch (e) {
        throw new zino.lang.Exception("Not valid Array.", {
          arr: newArray,
          index: index,
          idArray: idArray,
          source: this
        }, null, "zino.collections.ArrayList.addArrayToIndex", "zino.collections.ArrayList.js", 122);
      }
      return this;
    },
    addArray: function zino$collections$ArrayList$addArray(newArray, idArray) {
      return this.addArrayToIndex(newArray, this.length, idArray);
    },
    removeArray: function zino$collections$ArrayList$removeArray(trashArray) {
      var $t = this;
      try {
        for (var i = 0; i < trashArray.length; i++)
          var r = $t.remove(trashArray[i]);
      } catch (e) {
        throw new zino.lang.Exception(null, {
          arr: arr,
          source: this
        }, null, "zino.collections.ArrayList.removeArray", "zino.collections.ArrayList.js", 135);
      }
      return r;
    },
    replace: function zino$collections$ArrayList$replace(i, newItem, newId) {
      var $t = this;
      var itemInfo = $t.getItemInfo(i);
      $t.remove(itemInfo.item);
      return $t.addToIndex(newItem, itemInfo.index, newId);
    },
    replaceArray: function zino$collections$ArrayList$replaceArray(oldArray, newArray, newIdArray) {
      var $t = this;
      var itemInfo = this.getItemInfo(oldArray[0]);

      $t.removeArray(oldArray);
      $t.addArrayToIndex(newArray, itemInfo.index, newIdArray);

      return this;
    },
    clear: function zino$collections$ArrayList$clear() {
      var $t = this;
      while ($t.item.length)
        $t.remove($t.item.length - 1);

      return this;
    },
    toArray: function zino$collections$ArrayList$toArray(arrayType) {
      arrayType = arrayType ? arrayType : zino.collections.ArrayList.ArrayType.value;
      switch (arrayType) {
      case zino.collections.ArrayList.ArrayType.key:
        return this.idIndexes.slice();
        break;
      case zino.collections.ArrayList.ArrayType.value:
        return this.item.slice();
        break;
      }
    },
    join: function zino$collections$ArrayList$join() {
      return this.item.join.apply(this.item, arguments);
    },
    clone: function zino$collections$ArrayList$clone() {
      var $t = this;
      var r = new zino.collections.ArrayList;
      r.addArray($t.item, $t.idItems);
      return r;
    },
    findObject: function zino$collections$ArrayList$find(ob) {
      var $t = this;
      var o = false;
      if (o = $t.idIndexes[$t.handleIds[zino.getHandle(ob)]])
        return o;
      else
        return o;

    }
  };
  zino.collections.ArrayList.ArrayType = {
    "key": 1,
    "value": 2
  };

  //End collections.ArrayList}

  //{Start core.DragManager
  _.ns.registerS("zino.core.DragManager");
  zino.core.DragManager = function zino$core$DragManager() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.core.DragManager';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1cccc';
    $t._CREATEDATE = '2008/12/10';
    $t._MODIFIEDDATE = 'null';
    zino.getHandle($t);
    $t.dragObj = {
      zIndex: 0,
      dropableControls: new zino.collections.ArrayList(),
      dropRegion: null
    };
    $t.resizeConf = {};
    $t.dragMode = 0;
    $t.dropMode = 0;
    $t.isDragging = false;
    $t.isDown = false;
    $t.isResizing = false;
    $t.rate = null;
    $t.vectorMode = 1; //1 both - 2 horizontal - 3 vertical
    $t.onDragStart = new zino.util.Event($t);
    $t.onDragStop = new zino.util.Event($t);
  }.inherit(zino.lang.Object);
  zino.core.DragManager.prototype.doResizeH = function zino$core$DragManager$doResize(event, obj, resobj, resizeMode) {
    var $t = this,
      resizeObj, mobj, oresizeObj = null;
    if (obj instanceof zinox.ui.Control) mobj = getEl(obj);
    if (resobj instanceof Array) {
      resizeObj = getEl(resobj[0]);
      oresizeObj = getEl(resobj[1]);
    } else resizeObj = getEl(resobj);
    var mleft = getRectangle(mobj).left,
      rorect = getRectangle(resizeObj);
    if (!resizeObj.style.width) resizeObj.style.width = px(rorect.width);
    if (oresizeObj) {
      var ororect = getRectangle(oresizeObj);
      if (!oresizeObj.style.width) oresizeObj.style.width = px(ororect.width);
    }
    $t.dragStart(event, obj, 1, null, 2);
    $t.dragObj.elProxy.className = "zino-horizontal-resize-proxy";
    $t.proxyOpacity.change(50);
    _.body.onmouseupclassic.remove($t.dstop);
    _.body.onmouseupclassic.add($t.resizeHUp = function (e) {
      if ($t.isDragging) {
        var lft = getRectangle($t.dragObj.elProxy).left,
          lftdif = lft - mleft;
        if (mleft < rorect.left) {
          resizeObj.style.width = px(rorect.width - lftdif);
        } else {
          resizeObj.style.width = px(rorect.width + lftdif);
        }
        if (oresizeObj) {
          if (mleft < ororect.left) {
            oresizeObj.style.width = px(ororect.width - lftdif);
          } else {
            oresizeObj.style.width = px(ororect.width + lftdif);
          }
        }
        $t.dstop(e);
        $t.dragObj.elProxy.className = "";
        $t.proxyOpacity.change(100);
        _.body.onmouseupclassic.remove($t.resizeHUp);
      }
    });
  };
  zino.core.DragManager.prototype.doResizeV = function zino$core$DragManager$doResize(event, obj, resobj, resizeMode) {
    var $t = this,
      resizeObj, mobj, oresizeObj = null;
    if (obj instanceof zinox.ui.Control) mobj = getEl(obj);
    if (resobj instanceof Array) {
      resizeObj = getEl(resobj[0]);
      oresizeObj = getEl(resobj[1]);
    } else resizeObj = getEl(resobj);
    var mtop = getRectangle(mobj).top,
      rorect = getRectangle(resizeObj);
    if (!resizeObj.style.height) resizeObj.style.height = px(rorect.height);
    if (oresizeObj) {
      var ororect = getRectangle(oresizeObj);
      if (!oresizeObj.style.height) oresizeObj.style.height = px(ororect.height);
    }
    $t.dragStart(event, obj, 1, null, 3);
    $t.dragObj.elProxy.className = "zino-vertical-resize-proxy";
    $t.proxyOpacity.change(50);
    _.body.onmouseupclassic.remove($t.dstop);
    _.body.onmouseupclassic.add($t.resizeVUp = function (e) {
      if ($t.isDragging) {
        var top = getRectangle($t.dragObj.elProxy).top,
          topdif = top - mtop;
        if (mtop < rorect.top) {
          resizeObj.style.height = px(rorect.height - topdif);
        } else {
          resizeObj.style.height = px(rorect.height + topdif);
        }
        if (oresizeObj) {
          if (mtop < ororect.top) {
            oresizeObj.style.height = px(ororect.height - topdif);
          } else {
            oresizeObj.style.height = px(ororect.height + topdif);
          }
        }
        $t.dstop(e);
        $t.dragObj.elProxy.className = "";
        _.body.onmouseupclassic.remove($t.resizeVUp);
        $t.proxyOpacity.change(100);
      }
    });
  };
  zino.core.DragManager.prototype.doResize = function zino$core$DragManager$doResize(event, obj, onresize, onendresize, rate, resizeMode) {
    var $t = this,
      pos;
    if (rate) $t.rate = rate;
    if (obj instanceof Array) {
      if (!obj.length) return;
      if (obj[0] instanceof zinox.ui.Control) {
        $t.resizeConf.zresizeObj = obj[0];
        $t.resizeConf.resizeObj = obj[0].element.get();
      } else $t.resizeConf.resizeObj = obj[0];

      if (obj[1] instanceof zinox.ui.Control) {
        $t.resizeConf.mzresizeObj = obj[1];
        $t.resizeConf.mresizeObj = obj[1].element.get();
      } else $t.resizeConf.mresizeObj = obj[1];
    } else {
      if (obj instanceof zinox.ui.Control) {
        $t.resizeConf.zresizeObj = obj;
        $t.resizeConf.resizeObj = obj.element.get();
      } else $t.resizeConf.resizeObj = obj;
    }
    if (onresize && isFunc(onresize)) $t.resizeConf.onresize = onresize;
    if (onendresize && isFunc(onendresize)) $t.resizeConf.onendresize = onendresize;
    $t.resizeConf.resizeObj.style.height = px($t.resizeConf.fHeight = $t.resizeConf.resizeObj.clientHeight);
    if ($t.resizeConf.mresizeObj)
      $t.resizeConf.mresizeObj.style.height = px($t.resizeConf.mHeight = $t.resizeConf.mresizeObj.clientHeight);

    $t.resizeConf.cursorStartX = (pos = getCursorPosition(event)).x;
    $t.resizeConf.cursorStartY = pos.y;

    $t.resizeConf.orect = getRectangle($t.resizeConf.resizeObj);
    if ($t.resizeConf.mresizeObj) $t.resizeConf.morect = getRectangle($t.resizeConf.mresizeObj);
    var ii = 0;
    if (!$t.disableSelect) {
      $t.disableSelect = function () {
        return false;
      }
      document.onmousedown = $t.disableSelect.add(document.onmousedown);
    }
    if ($t.rego) _.body.onmousemove.remove($t.rego);
    _.body.onmousemove.add($t.rego = function (moveEvent) {
      if ($t.resizeConf.orect) {
        var npos;
        $t.isResizing = true;
        var cursorX = (npos = getCursorPosition(moveEvent)).x,
          cursorY = npos.y;
        var hdif = cursorY - $t.resizeConf.cursorStartY;
        var wdif = cursorX - $t.resizeConf.cursorStartX;
        window.status = "HDIF = " + hdif;
        var newh, dif, mnewh, mdif;
        if ($t.rate) {
          if (hdif < $t.rate) dif = 0;
          else if (hdif == $t.rate) dif = $t.rate;
          else {
            dif = parseInt((hdif - $t.resizeConf.orect.height) / $t.rate) * $t.rate;
            dif2 = parseInt((wdif - $t.resizeConf.orect.width) / $t.rate) * $t.rate;
          }
          newh = $t.resizeConf.orect.height + dif;
          neww = $t.resizeConf.orect.width + dif;
          if ($t.resizeConf.mresizeObj) mnewh = $t.resizeConf.morect.height - dif;
          if ($t.resizeConf.mresizeObj) mneww = $t.resizeConf.morect.width - dif;
        } else {
          newh = $t.resizeConf.orect.height + hdif;
          neww = $t.resizeConf.orect.width + hdif;
          if ($t.resizeConf.mresizeObj) mnewh = $t.resizeConf.morect.height - hdif;
          if ($t.resizeConf.mresizeObj) mneww = $t.resizeConf.morect.width - wdif;
        }
        window.status += " | Resize";
        $t.resizeConf.resizeObj.style.height = px(newh);
        $t.resizeConf.resizeObj.style.width = px(neww);
        if ($t.resizeConf.mresizeObj) $t.resizeConf.mresizeObj.style.height = px(mnewh);
        if ($t.resizeConf.mresizeObj) $t.resizeConf.mresizeObj.style.width = px(mneww);
        if ($t.resizeConf.onresize) $t.resizeConf.onresize();
      }
    });
    _.body.onmouseup.remove($t.reup);
    _.body.onmouseup.add($t.reup = function (upEvent) {
      $t.isResizing = false;
      _.body.onmousemove.remove($t.rego);
      _.body.onmouseup.remove($t.reup);
      if ($t.resizeConf.onendresize) $t.resizeConf.onendresize();
    });
  };
  zino.core.DragManager.prototype.dragStart = function zino$core$DragManager$dragStart(event, obj, dragMode, dropMode, vectorMode, dragParent) {
    var $t = this,
      el, pos;
    if ($t.isDown) return;
    $t.onDragStart.raise.apply(this, arguments);
    $t.isDown = true;
    $t.dragMode = dragMode;
    if (dropMode) $t.dropMode = dropMode;
    if (vectorMode) $t.vectorMode = vectorMode;
    //if(dragParent) $t.dragParent=dragParent; else $t.dragParent=null;
    if (dragParent) _.dragger.bodyRect = getRectangle(dragParent.element.get())
    else _.dragger.bodyRect = getRectangle(_.body.element.get())

    window.status = "2930 : dropMode=" + $t.dropMode;
    if (obj && obj instanceof zinox.ui.Control) $t.dragObj.elNode = ($t.dragObj.data = obj).element.get();
    else throw new zino.lang.Exception("Can not start drag cause drag object is not set!", {
      event: event
    }, null, "zino.core.DragManager.dragStart", "zino.core.DragManager.js", 26);

    $t.dragObj.data.dragStartTimestamp = (new Date()).valueOf();

    var dhtmNode = $t.dragObj.elNode,
      orect;
    $t.dragObj.parent = obj.parent.get();
    if (dhtmNode.className.split("zinox-ui-controls-dialog-panel").length > 1) orect = getRectangle(dhtmNode.childNodes[0]);
    else orect = getRectangle(dhtmNode);
    $t.dragObj.orect = orect;
    $t.dragObj.cursorStartX = (pos = getCursorPosition(event)).x;
    $t.dragObj.cursorStartY = pos.y;
    $t.dragObj.elStartLeft = parseInt(orect.left, 10);
    $t.dragObj.elStartTop = parseInt(orect.top, 10);
    if (isNaN($t.dragObj.elStartLeft)) $t.dragObj.elStartLeft = 0;
    if (isNaN($t.dragObj.elStartTop)) $t.dragObj.elStartTop = 0;
    dhtmNode.style.zIndex = ++$t.dragObj.zIndex;

    if ($t.dragMode == 1) {
      var objProxy = null;
      if ($t.dragObj.elProxy) {
        removeChilds(objProxy = $t.dragObj.elProxy);
      } else objProxy = $t.dragObj.elProxy = ce(dhtmNode.tagName);
      dhtmNode.parentNode.appendChild(objProxy);

      objProxy.style.borderStyle = "dashed";
      objProxy.style.borderWidth = px(1);
      objProxy.style.borderColor = "#000";
      objProxy.style.position = "absolute";
      $t.dragObj.parent.controls.add($t.dragObj.dataProxy = new zinox.ui.Control($t.dragObj.elProxy));
      objProxy.style.width = px(orect.width);
      objProxy.style.height = px(orect.height);
      objProxy.style.left = px(orect.left);
      objProxy.style.top = px(orect.top);
      $t.dragObj.elMove = objProxy;
    } else if ($t.dragMode == 2) {
      var objProxy = null;
      if ($t.dragObj.elProxy) {
        removeChilds(objProxy = $t.dragObj.elProxy);
      } else objProxy = $t.dragObj.elProxy = ce(dhtmNode.tagName);
      dhtmNode.parentNode.appendChild(objProxy);

      objProxy.className = dhtmNode.className;
      objProxy.style.position = "absolute";
      moveChilds(dhtmNode, objProxy);

      $t.dragObj.oborderStyle = dhtmNode.style.borderStyle;
      $t.dragObj.oborderWidth = dhtmNode.style.borderWidth;
      $t.dragObj.oborderColor = dhtmNode.style.borderColor;
      dhtmNode.style.borderStyle = "dashed";
      dhtmNode.style.borderWidth = px(1);
      dhtmNode.style.borderColor = "#000";

      objProxy.style.width = px(orect.width);
      objProxy.style.height = px(orect.height);
      objProxy.style.left = px(orect.left);
      objProxy.style.top = px(orect.top);
      $t.dragObj.elMove = objProxy;
    } else if ($t.dragMode == 3) {
      var objProxy = null;
      if ($t.dragObj.elProxy) {
        removeChilds(objProxy = $t.dragObj.elProxy);
      } else objProxy = $t.dragObj.elProxy = ce(dhtmNode.tagName);
      dhtmNode.parentNode.appendChild(objProxy);

      objProxy.className = dhtmNode.className;
      objProxy.style.position = "absolute";
      objProxy.innerHTML = dhtmNode.innerHTML;
      objProxy.style.width = px(orect.width);
      objProxy.style.height = px(orect.height);
      objProxy.style.left = px(orect.left);
      objProxy.style.top = px(orect.top);
      $t.dragObj.elMove = objProxy;
    } else if ($t.dragMode == 4) {
      var objProxy = null;
      if ($t.dragObj.elProxy) {
        removeChilds(objProxy = $t.dragObj.elProxy);
        objProxy.style.width = "";
        objProxy.style.height = "";
        objProxy.style.left = "";
        objProxy.style.top = "";
        objProxy.style.borderStyle = "";
        objProxy.style.borderWidth = "";
        objProxy.style.borderColor = "";
      } else objProxy = $t.dragObj.elProxy = ce(dhtmNode.tagName);
      _.body.element.get().appendChild(objProxy);
      var sp = ce("span");
      if (!$t.ddtext) $t.ddtext = "Dragging Item";
      sp.appendChild(ct($t.ddtext));
      var cop = ce("table");
      var r0 = cop.insertRow(0),
        c0 = r0.insertCell(0),
        c1 = r0.insertCell(1),
        c2 = r0.insertCell(2);
      c0.className = "zino-dd-drop-icon";
      c1.className = "hidden";
      c2.appendChild(sp);
      objProxy.className = "zino-dd-drag-proxy zino-dd-drop-nodrop";
      objProxy.appendChild(cop);
      var sprect = getRectangle(cop);
      var ow = (!sprect.width || isNaN(sprect.width)) ? 170 : sprect.width;
      objProxy.style.width = px(ow);
      objProxy.style.left = px($t.dragObj.elStartLeft = $t.dragObj.cursorStartX - ow + 8);
      objProxy.style.top = px($t.dragObj.elStartTop = ($t.dragObj.cursorStartY + 20));
      $t.dragObj.elMove = objProxy;
    } else {
      dhtmNode.style.position = "absolute";
      $t.dragObj.elMove = dhtmNode;
    }
    $t.dragObj.elMove.style.zIndex = dhtmNode.style.zIndex;
    if (_.dragger.dragObj.elProxy)
      $t.proxyOpacity = new zino.ui.Opacity(_.dragger.dragObj.elProxy);

    if (!$t.disableSelect) {
      $t.disableSelect = function () {
        return false;
      }
      document.onmousedown = $t.disableSelect.add(document.onmousedown);
    }
    $t.dgo = function (e) {
      $t.dragGo(e);
    };
    $t.dstop = function (e) {
      $t.isDown = false;
      $t.dragStop(e);
    };
    $t.dragObj.elMove.style.display = "none";
    if (!$t.disableSelect) {
      $t.disableSelect = function () {
        return false;
      }
      document.onmousedown = $t.disableSelect.add(document.onmousedown);
    }
    _.body.onmousemoveclassic.add($t.dgo);
    _.body.onmouseupclassic.add($t.dstop);
  };
  zino.core.DragManager.prototype.dragGo = function zino$core$DragManager$dragGo(event) {
    var $t = this,
      pos = getCursorPosition(event);
    $t.dragObj.elMove.style.display = "";
    $t.isDragging = true;
    var prxw = $t.dragObj.elProxy["offsetWidth"],
      prxh = $t.dragObj.elProxy["offsetHeight"];

    if ($t.vectorMode == 1 || $t.vectorMode == 2) {
      var lft = $t.dragObj.elStartLeft + pos.x - $t.dragObj.cursorStartX;
      if (lft > $t.bodyRect.width - prxw) lft = $t.bodyRect.width - prxw;
      $t.dragObj.elMove.style.left = lft + "px";
    }
    if ($t.vectorMode == 1 || $t.vectorMode == 3) {
      var tp = $t.dragObj.elStartTop + pos.y - $t.dragObj.cursorStartY;
      if (tp > $t.bodyRect.height - prxh) tp = $t.bodyRect.height - prxh;
      $t.dragObj.elMove.style.top = tp + "px";
    }

  };
  zino.core.DragManager.prototype.dragStop = function zino$core$DragManager$dragStop(event) {
    var $t = this;
    $t.isDragging = false;
    if ($t.disableSelect) {
      document.onmousedown.remove($t.disableSelect);
      delete $t.disableSelect;
    }
    $t.updateDropables();
    _.body.onmousemoveclassic.remove(this.dgo);
    _.body.onmouseupclassic.remove(this.dstop);
    if ($t.dragMode == 1) {
      $t.dragObj.elNode.style.left = $t.dragObj.elProxy.style.left;
      $t.dragObj.elNode.style.top = $t.dragObj.elProxy.style.top;
      $t.dragObj.elProxy.parentNode.removeChild($t.dragObj.elProxy);
    } else if ($t.dragMode == 2) {
      $t.dragObj.elNode.style.borderStyle = $t.dragObj.oborderStyle;
      $t.dragObj.elNode.style.borderWidth = $t.dragObj.oborderWidth;
      $t.dragObj.elNode.style.borderColor = $t.dragObj.oborderColor;
      moveChilds($t.dragObj.elMove, $t.dragObj.elNode);
      $t.dragObj.elProxy.parentNode.removeChild($t.dragObj.elProxy);
    } else if ($t.dragMode == 3) {
      $t.dragObj.elNode.style.borderStyle = $t.dragObj.oborderStyle;
      $t.dragObj.elNode.style.borderWidth = $t.dragObj.oborderWidth;
      $t.dragObj.elNode.style.borderColor = $t.dragObj.oborderColor;
      $t.dragObj.elProxy.parentNode.removeChild($t.dragObj.elProxy);
    } else if ($t.dragMode == 4) {
      $t.dragObj.elProxy.parentNode.removeChild($t.dragObj.elProxy);
    }
    if ($t.dragObj.dropRegion) {
      $t.dragObj.dropRegion.ondragdrop.raise($t.dragObj.data);
      $t.dragObj.dropRegion = null;
      $t.updateDropables();
    } else {
      try {
        $t.onDragStop.raise.apply(this, arguments);
      } catch (er) {
        window.status = "ERROR [" + er.message + "]";
      }
    }
  };
  zino.core.DragManager.prototype.updateDropables = function zino$core$DragManager$updateDropables(e) {
    var $t = this;
    for (var i = 0; i < $t.dragObj.dropableControls.length; i++) {
      var ctrl = $t.dragObj.dropableControls[i];
      ctrl._dr_ = getDropRegion(ctrl);
      ctrl._dmr_ = getPosition(ctrl);
    }
  }
  zino.core.DragManager.prototype.raiseDragDropEvents = function zino$core$DragManager$raiseDragDropEvents(e) {
    var $t = this;
    if ($t.isDragging) {
      var pos = getCenterGravity($t.dragObj.elMove),
        mospos = getCursorPosition(e);
      var xP, yP;
      if ($t.dropMode == 0) xP = pos.x;
      yP = pos.y;
      if ($t.dropMode == 1) xP = mospos.x;
      yP = mospos.y;
      var len = $t.dragObj.dropableControls.length;
      var isover = false;
      var isovered = false;
      for (var i = 0; i <= (len - 1); i++) {
        var ctrl = $t.dragObj.dropableControls[i];
        if ($t.dragObj.data !== ctrl && !isParentOf($t.dragObj.data.element.get(), ctrl.element.get())) {
          var dregion;
          if ($t.dropMode == 0) dregion = ctrl._dr_;
          else if ($t.dropMode == 1) dregion = ctrl._dmr_;
          if ((yP > dregion.y.top && yP < dregion.y.bottom) && (xP > dregion.x.left && xP < dregion.x.right)) {
            $t.dragObj.elProxy.className = "zino-dd-drag-proxy zino-dd-drop-ok";
            if ($t.dragObj.dropRegion && $t.dragObj.dropRegion.overParent === ctrl) {
              var lastOver = $t.dragObj.dropRegion.overParent.overChild = $t.dragObj.dropRegion;
              $t.dragObj.dropRegion = null;
              lastOver.ondragleave.raise(lastOver, $t.dragObj);
              $t.dragObj.dropRegion = ctrl;
              lastOver._dvr_ = false;
            } else if (isovered && $t.dragObj.dropRegion !== ctrl) {
              var lastOver = ctrl.overParent = $t.dragObj.dropRegion;
              //$t.dragObj.dropRegion=null;
              lastOver.ondragleave.raise(lastOver, $t.dragObj);
              lastOver._dvr_ = false;
            }
            ctrl.ondragover.raise(ctrl, $t.dragObj);
            isovered = true;
            if (ctrl != _.body) isover = true;
            //break;
          }
        }
      }
      if (!isover) {
        for (var i = 0; i <= (len - 1); i++) {
          var ctrl = $t.dragObj.dropableControls[i];
          if (ctrl != _.body) {
            if (ctrl._dvr_ !== undefined && ctrl._dvr_ === true) {
              ctrl._dvr_ = false;
              $t.dragObj.elProxy.className = "zino-dd-drag-proxy zino-dd-drop-nodrop";
              ctrl.ondragleave.raise(ctrl, $t.dragObj);
              $t.dragObj.dropRegion = null;
              break;
            }
          }
        }
      }
    }
  };
  zino.core.DragManager.prototype.isDragOver = function zino$core$DragManager$isDragOver(ctrl, xP, yP, drMode) {
    var $t = this;
    switch ($t.dropMode) {
    case 0: //onMouse :

      break;
    case 1: //onGravity :
      var dregion = ctrl._dr_;

      break;
    }
    if ((yP > dregion.y.top && yP < dregion.y.bottom) && (xP > dregion.x.left && xP < dregion.x.right)) return true;
    else return false;
  };
  zino.core.DragManager.prototype.initDragEvents = function zino$core$DragManager$initDragEvents(ctrl) {
    var $t = this;
    ctrl.ondragover.add(function () {
      if ($t.isDragging) {
        if (ctrl._dvr_ === undefined || ctrl._dvr_ === false) {
          ctrl._dvr_ = true;
          $t.dragObj.dropRegion = ctrl;
          return ctrl.ondragenter.raise.apply(ctrl, arguments);
        }
      }
    });
  }

  //End core.DragManager}
  _.dragger = new zino.core.DragManager();
  //Start ui._base}
  _.ns.registerS("zino.ui._base");
  zino.ui.Arrangment = new zino.lang.Enum({
    Vertical: 0,
    Horizontal: 1
  });
  zino.ui.Position = new zino.lang.Enum({
    Top: 1,
    Right: 2,
    Bottom: 3,
    Left: 4
  });
  zino.ui.APosition = new zino.lang.Enum({
    "top": zino.ui.Position.Top,
    "right": zino.ui.Position.Right,
    "bottom": zino.ui.Position.Bottom,
    "left": zino.ui.Position.Left
  });
  zino.ui.HPosition = new zino.lang.Enum({
    "right": zino.ui.Position.Right,
    "left": zino.ui.Position.Left
  });
  zino.ui.VPosition = new zino.lang.Enum({
    "top": zino.ui.Position.Top,
    "bottom": zino.ui.Position.Bottom
  });
  zino.ui.RPosition = new zino.lang.Enum({
    "top": zino.ui.Position.Top,
    "left": zino.ui.Position.Left
  });

  zino.ui.ResizeMode = new zino.lang.Enum({
    Vertical: 0,
    Horizontal: 1,
    both: 2
  });
  //End ui.!}
  //Start ui.drawing.Size}
  _.ns.registerS("zino.ui.drawing.Size");
  zino.ui.drawing.Size = function zino$ui$drawing$Size(control) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.drawing.Size';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2008/09/03';
    $t._MODIFIEDDATE = 'null';
    var width = false;
    $t.width = new zino.lang.Property(Number,
      function width$$getter() {
        return width;
      },
      function width$$setter(value) {
        width = value;
        if ($t.control && $t.control.element.get) $t.control.element.get().style.width = width + "px";
      }
    );

    var height = false;
    $t.height = new zino.lang.Property(Number,
      function height$$getter() {
        return height;
      },
      function height$$setter(value) {
        height = value;
        if ($t.control && $t.control.element.get) $t.control.element.get().style.height = height + "px";
      }
    );

    $t.control = control;
  };
  //End ui.drawing.Size}
  //Start ui.Opacity
  zino.ui.Opacity = function zino$ui$Opacity(ctrl) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.Opacity';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2008/09/03';
    $t._MODIFIEDDATE = 'null';
    $t.timerList = [];
    zino.getHandle($t);
    var element = null;
    $t.element = new zino.lang.Property(HTMLElement, function element$$getter() {
      return element;
    }, function element$$setter(value) {
      element = value;
    });
    if (ctrl) {
      if (ctrl instanceof zinox.ui.Control) $t.element.set(ctrl.element.get());
      else $t.element.set(ctrl);
    }
    var fadeRate = 10;
    $t.fadeRate = new zino.lang.Property(Number, function fadeRate$$getter() {
      return fadeRate;
    }, function fadeRate$$setter(value) {
      fadeRate = value;
    });
  }.inherit(zino.lang.Object);
  zino.ui.Opacity.prototype.change = function (opac) {
    var els = this.element.get().style;
    els.opacity = (opac / 100);
    els.MozOpacity = (opac / 100);
    els.KhtmlOpacity = (opac / 100);
    els.filter = "alpha(opacity=" + opac + ")";
    if (opac == 0) els.visibility = 'hidden';
    else els.visibility = 'visible';
  };
  zino.ui.Opacity.prototype.fade = function (start, end, millisec, func) {
    var $t = this,
      frate = $t.fadeRate.get();
    if (func) $t.funcHId = zino.getHandle(func);
    if (start == end) {
      if (this.funcHId !== undefined) zino.getObject(this.funcHId)();
      return;
    };
    start = (start > end) ? (start - frate) : (start + frate);
    this.timer = setTimeout("zino.ui.Opacity.prototype.fade.call(zino.getObject(" + this.__HANDLE_ID__ + ")," + start + "," + end + "," + millisec + ")", millisec);
    this.change(start);
  };
  zino.ui.Opacity.prototype.fadeIn = function (milliSec, func) {
    this.fade(0, 100, (milliSec || 30), func);
  };
  zino.ui.Opacity.prototype.fadeOut = function (milliSec, func) {
    this.fade(100, 0, (milliSec || 30), func);
  };
  //end ui.Opacity
  //Start ui.drawing.Position}
  _.ns.registerS("zino.ui.drawing.Position");
  zino.ui.drawing.Position = function zino$ui$drawing$Position(control) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.drawing.Position';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2008/09/03';
    $t._MODIFIEDDATE = 'null';
    var left = 0;
    $t.left = new zino.lang.Property(Number,
      function left$$getter() {
        return left;
      },
      function left$$setter(value) {
        left = value;
        if ($t.control && $t.control.element.get) $t.control.element.get().style.left = left + "px"
      }
    );

    var top = 0;
    $t.top = new zino.lang.Property(Number,
      function top$$getter() {
        return top;
      },
      function top$$setter(value) {
        top = value;
        if ($t.control && $t.control.element.get) $t.control.element.get().style.top = top + "px";
      }
    );

    $t.control = control;
  };
  //End ui.drawing.Position}
  //
  //{Start util.ContextProvider
  _.ns.prepare('zinox.ui.controls');
  _.ns.prepare('zinox.util');
  _.ns.registerS("zinox.util.ContextProvider");
  zinox.util.ContextProvider = function zinox$ContextProvider(context) {
    arguments.callee.superClass.apply(this, arguments);
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zinox.util.ContextProvider';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.2a';
    $t._CREATEDATE = '2007/10/15';
    $t._MODIFIEDDATE = '2007/10/15';
    var isActive = true;
    $t.isActive = new zino.lang.Property(Boolean,
      function isActive$$getter() {
        return isActive;
      },
      function isActive$$setter(value) {
        isActive = value;
      }
    );
    $t.oncontextchange = new zino.util.Event($t);
    $t.context = null;
  }.inherit(zino.lang.Component);
  //End util.ContextProvider}
  //{Start ui.drawing.Rectangle
  _.ns.registerS("zino.ui.drawing.Rectangle");
  zino.ui.drawing.Rectangle = function zino$ui$drawing$Rectangle() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.drawing.Rectangle';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2007/08/08';
    $t._MODIFIEDDATE = '2007/08/08';

    $t.bottom = px(0);
    $t.top = px(0);
    $t.left = px(0);
    $t.right = px(0);

    $t.width = px(0);
    $t.height = px(0);
  };
  //End ui.drawing.Rectangle}
  //{Start ui.styling.Style
  _.ns.registerS("zino.ui.styling.Style");
  zino.ui.styling.Style = function zino$ui$styling$Style(url) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.styling.Style';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/09/01';
    $t._MODIFIEDDATE = '2007/09/01';
    $t.o = ce("link");
    $t.o.setAttribute("rel", "stylesheet");
    $t.o.setAttribute("type", "text/css");
    $t.o.setAttribute("href", url);
    document.getElementsByTagName("head").item(0).appendChild($t.o);
  };
  zino.ui.styling.Style.prototype.unload = function zino$ui$styling$Style$unload() {
    this.o.setAttribute("href", "");
  };
  //End ui.styling.Style}
  //{Start zino.ui.styling.Theme
  _.ns.registerS("zino.ui.styling.Theme");
  zino.ui.styling.Theme = function zino$ui$styling$Theme(tn) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.styling.Theme';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/09/01';
    $t._MODIFIEDDATE = '2007/09/01';
    $t.path = "_themes/" + tn;
    $t.url = $t.path + "/" + tn + ".theme.xml";
    $t.onLoad = new zino.util.Event($t);
    $t.load();
  };
  zino.ui.styling.Theme.prototype.load = function zino$ui$styling$Theme$load() {
    var $t = this;

    $t.x = new zino.net.HTTPRequest($t.url);

    $t.x.onLoad.add(function zino$ui$styling$Theme$load$onLoad() {
      $t._onLoad();
    });

    $t.x.load();
  };
  zino.ui.styling.Theme.prototype._onLoad = function zino$ui$styling$Theme$_onLoad() {
    var $t = this;
    $t.node = $t.x.response.XML.lastChild;
    setNSResolver($t.node, {
      zino: "http://ns.partia.com/zino"
    });
    $t.cssStyles = $t.node.selectNodes("//zino:css");
    var nLayouts = $t.node.selectNodes("//zino:layout");
    $t.layouts = {};
    for (var i = 0; i < nLayouts.length; i++) {
      $t.layouts[nLayouts[i].getAttribute("id")] = nLayouts[i];
    }
    /*	var nIcons = $t.node.selectNodes("//zino:icons/zino:icon")
            $t.icons = {};
            for(var i=0; i< nIcons.length; i++){
                $t.icons[nIcons[i].getAttribute("id")] = nIcons[i];
            }
        */
    _.env.theme_root = $t.path;
    $t.onLoad.raise();
  };
  zino.ui.styling.Theme.prototype.apply = function zino$ui$styling$Theme$apply() {
    for (var i = 0; i < this.cssStyles.length; i++) {
      var s = this.cssStyles[i];
      _.styles.load(mp(s.getAttribute("href")));
    }
  };
  zino.ui.styling.Theme.prototype.unload = function zino$ui$styling$Theme$unload() {
    for (var i = 0; i < this.cssStyles.length; i++) {
      var s = this.cssStyles[i];
      _.styles.unload(this.path + s.getAttribute("href"));
    }
  };
  //End zino.ui.styling.Theme}
  //{Start core.StyleManager
  _.ns.registerS("zino.core.StyleManager");
  zino.core.StyleManager = function zino$core$StyleManager() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.core.StyleManager';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/09/01';
    $t._MODIFIEDDATE = '2007/09/01';
    this.styles = [];
  }.inherit(zino.lang.Object);
  zino.core.StyleManager.prototype.load = function zino$core$StyleManager$load(url) {
    if (!this.styles[url]) {
      this.styles[url] = new zino.ui.styling.Style(url);
      return true;
    } else {
      return true;
    }
  };
  zino.core.StyleManager.prototype.unload = function zino$core$StyleManager$unload(url) {
    if (this.styles[url]) {
      this.styles[url].unload();
      delete this.styles[url];
    }
  };
  //End core.StyleManager}
  //{Start zino.core.ThemeManager
  _.ns.registerS("zino.core.ThemeManager");
  zino.core.ThemeManager = function zino$core$ThemeManager() {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.core.ThemeManager';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/09/01';
    $t._MODIFIEDDATE = '2007/09/01';
    this.themes = [];
    this.current = null;

    this.onchange = new zino.util.Event(); //function zino$core$ThemeManager$onchange(){};
    this.onthemeload = new zino.util.Event(); // function zino$core$ThemeManager$onthemeload(){};
    this.onfirstthemeload = new zino.util.Event(); //function zino$core$ThemeManager$onfirstthemeload(){};

    this._isFirst = true;

    $t._onThemeLoad = function zino$core$ThemeManager$_onThemeLoad() {
      if ($t._isFirst) {
        $t.onfirstthemeload.raise();
        $t._isFirst = false;
      }
      $t.onthemeload.raise();
    }

  }.inherit(zino.lang.Object);
  zino.core.ThemeManager.prototype.apply = function zino$core$ThemeManager$apply(url) {
    var $t = this;
    if (!this.themes[url]) {
      this.load(url);
      this.themes[url].onLoad.add(function zino$core$ThemeManager$apply$onLoad() {
        $t._apply(url)
      });
    } else {
      this._apply(url);
    }
  };
  zino.core.ThemeManager.prototype._apply = function zino$core$ThemeManager$_apply(url) {
    if (this.current) {
      this.current.unload();
    }
    this.current = this.themes[url];
    this.current.apply();
    this.onchange.raise();
  };
  zino.core.ThemeManager.prototype.load = function zino$core$ThemeManager$load(url) {
    this.themes[url] = new zino.ui.styling.Theme(url);
    this.themes[url].onLoad.add(this._onThemeLoad);
  };
  zino.core.ThemeManager.prototype.unload = function zino$core$ThemeManager$unload(url) {};
  //End zino.core.ThemeManager}
  //{Start ui.styling.ClassSet
  _.ns.registerS("zino.ui.styling.ClassSet");
  zino.ui.styling.ClassSet = function zino$ui$styling$ClassSet(initClassNames) {
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.styling.ClassSet';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.1a';
    $t._CREATEDATE = '2006/09/01';
    $t._MODIFIEDDATE = '2007/09/01';

    this.cn = "";

    this.onadd = new zino.util.Event;
    this.onremove = new zino.util.Event;
    this.onchange = new zino.util.Event;
    this.classes = [];
    this.handles = {};

    if (initClassNames) {
      if (initClassNames instanceof Array) {
        this.addArray(initClassNames);
      } else {
        this.add(initClassNames);
      }
    }
  };
  zino.ui.styling.ClassSet.prototype.add = function zino$ui$styling$ClassSet$add(classNS) {
    var $t = this;
    if (classNS instanceof zino.ui.styling.ClassSet) {
      if ($t.handles[zino.getHandle(classNS)])
        return void(0);

      classNS.onchange.add($t.handles[zino.getHandle(classNS)] = function (newCn, cn) {
        $t.remove(cn);
        $t.add(newCn);
      });
      $t.add(classNS.cn);
    } else
      $t.addArray((classNS + "").split(" "));
  };
  zino.ui.styling.ClassSet.prototype.addArray = function zino$ui$styling$ClassSet$addArray(classNames) {
    if (!(classNames && classNames instanceof Array))
      throw new zino.lang.Exception("Not valid classNames array!", {
        node: node,
        source: $t
      }, null, "zino.ui.styling.ClassSet.addArray", "zino.ui.styling.ClassSet.js", 39);

    this.cn += " " + classNames.join(" ");

    for (var i = 0; i < classNames.length; i++)
      if (!this.contains(classNames[i]))
        this.classes.push(classNames[i]);

    this.apply();
    this.onadd.raise();
  };
  zino.ui.styling.ClassSet.prototype.remove = function zino$ui$styling$ClassSet$remove(classNS) {
    var $t = this;
    if (classNS instanceof zino.ui.styling.ClassSet) {
      if (!$t.handles[zino.getHandle(classNS)])
        return void(0);

      classNS.onchange.remove($t.handles[zino.getHandle(classNS)]);
      delete $t.handles[zino.getHandle(classNS)];
      return $t.remove(classNS.cn);
    } else
      $t.removeArray(classNS.split(" "));
  };
  zino.ui.styling.ClassSet.prototype.removeArray = function zino$ui$styling$ClassSet$removeArray(classNames) {
    var i = false;

    for (var i = 0; i < classNames.length; i++) {
      var j = false;
      if (j = this.find(classNames[i])) {
        delete this.classes[j];
      }
    }
    this.apply();
    this.onremove.raise();
  };
  zino.ui.styling.ClassSet.prototype.replace = function zino$ui$styling$ClassSet$replace(classNS, newClassNS) {
    if (classNS instanceof zino.ui.styling.ClassSet) {
      var j;
      for (var i = 0; i < classNS.classes.length; i++)
        if (!(j = newClassNS.find(classNS.classes[i])))
          delete this.classes[this.find(classNS.classes[i])];

      for (var i = 0; i < newClassNS.classes.length; i++)
        if (!this.contains(newClassNS.classes[i]))
          this.classes.push(newClassNS.classes[i]);

      return this.apply();
    } else {
      var cls = false;
      if (cls = this.find(classNS)) {
        this.classes[cls] = newClassNS;
        return this.apply();
      }
      return false;
    }
  };
  zino.ui.styling.ClassSet.prototype.contains = zino.ui.styling.ClassSet.prototype.find = function zino$ui$styling$ClassSet$contains(className) {
    for (var i in this.classes) {
      if (this.classes[i] == className) {
        return i;
      }
    }
    return false;
  };
  zino.ui.styling.ClassSet.prototype.apply = function zino$ui$styling$ClassSet$apply() {
    var lastCn = this.cn + "";
    this.cn = this.classes.join(" ");
    this.onchange.raise(this.cn, lastCn);
  };
  //End ui.styling.ClassSet}
  //{Start ui.styling.ClassManager
  _.ns.registerS("zino.ui.styling.ClassManager");
  zino.ui.styling.ClassManager = function zino$ui$styling$ClassManager(element, initClassNames) {
    arguments.callee.superClass.apply(this, [initClassNames]);
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zino.ui.styling.ClassManager';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.4a';
    $t._CREATEDATE = '2006/05/27';
    $t._MODIFIEDDATE = '2007/09/15';
    this.element = element;
    if (this.element) {
      this.add(this.element.className);
      this.element.className = this.cn;
    }
  }.inherit(zino.ui.styling.ClassSet);
  zino.ui.styling.ClassManager.prototype.apply = function zino$ui$styling$ClassManager$apply() {
    var lastCn = this.cn + "";
    this.cn = this.classes.join(" ");
    if (this.element)
      this.element.className = this.cn;

    this.onchange.raise(this.cn, lastCn);
  };
  //End ui.styling.ClassManager}

  //{Start ui.Control
  _.ns.registerS("zinox.ui.Control");
  zinox.ui.Control = function zinox$ui$Control(defaultElement) {
    if (window._itit) alert("Start Control");
    arguments.callee.superClass.apply(this, arguments);
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zinox.ui.Control';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.2a';
    $t._CREATEDATE = '2007/07/31';
    $t._MODIFIEDDATE = '2007/09/05';
    $t.handles = [];
    $t.disposed = false;
    $t.rendered = false;
    $t.regions = new zino.collections.ArrayList();
    $t._dr_ = {};
    $t._dmr_ = {};
    /* Events */
    $t.onenter = new zino.util.Event($t);
    $t.onleave = new zino.util.Event($t);

    $t.onclickclassic = new zino.util.Event($t);
    $t.onclick = new zino.util.Event($t);

    $t.ondblclick = new zino.util.Event($t);
    $t.ondblclickclassic = new zino.util.Event($t);

    $t.onmouseover = new zino.util.Event($t);
    $t.onmouseoverclassic = new zino.util.Event($t);
    $t.onmouseout = new zino.util.Event($t);
    $t.onmouseoutclassic = new zino.util.Event($t);
    $t.onmousedown = new zino.util.Event($t);
    $t.onmousedownclassic = new zino.util.Event($t);
    $t.onmouseup = new zino.util.Event($t);
    $t.onmouseupclassic = new zino.util.Event($t);
    $t.onmousemove = new zino.util.Event($t);
    $t.onmousemoveclassic = new zino.util.Event($t);
    $t.onkeydown = new zino.util.Event($t);
    $t.onkeyup = new zino.util.Event($t);
    $t.onkeypress = new zino.util.Event($t);

    $t.onfocus = new zino.util.Event($t);
    $t.onblur = new zino.util.Event($t);

    $t.onshow = new zino.util.Event($t);
    $t.onhide = new zino.util.Event($t);

    $t.onrender = new zino.util.Event($t);
    $t.onscroll = new zino.util.Event($t);

    //Drag Events :
    $t.ondragdrop = new zino.util.Event($t);
    $t.ondragenter = new zino.util.Event($t);
    $t.ondragleave = new zino.util.Event($t);
    $t.ondragover = new zino.util.Event($t);
    /* Events */

    $t.controls = new zino.collections.ArrayList();
    $t.controls.onadd.add($t.__baseonaddlistener = function (control) {
      var tg = control.element.get().baseName.toLowerCase();
      switch (tg) {
      case "tr":
      case "td":
        break;
      default:
        try {
          if ($t.element.get()) $t.element.get().appendChild(control.element.get());
        } catch (err) {
          alert("dd " + e.message)
        }
        break;
      }

      control.parent.set($t);
      //control.parent.set($t,(tg=="tr"||tg=="td"));
      $t.element.onchange.add(function () {
        if ($t.element.get()) control.render($t.element.get());
      });
    });
    $t.controls.onremove.add(function (control) {
      if (control.element.get().parentNode) control.element.get().parentNode.removeChild(control.element.get());
      if (control.parent == $t) control.parent.set(null);
    });

    var currentDropRegion = null;
    $t.currentDropRegion = new zino.lang.Property(zinox.ui.controls.RegionControl,
      function currentDropRegion$$getter() {
        return currentDropRegion;
      },
      function currentDropRegion$$setter(value) {
        if ($t.regions.indexOf(value) == -1) $t.regions.add(value);
        currentDropRegion = value;
      }
    );

    var currentContext = null;
    $t.currentContext = new zino.lang.Property(zinox.ui.Control,
      function currentContext$$getter() {
        return currentContext;
      },
      function currentContext$$setter(value) {
        if (currentContext) {
          currentContext.currentContext.set(null);
          currentContext.onleave.raise();
        }
        currentContext = value;
        if (!!currentContext) {
          if ($t.parent.get())
            $t.parent.get().currentContext.set($t);
          currentContext.onenter.raise();
          if ($t.form) {
            $t.form.context = $t;
            $t.form.oncontextchange.raise();
          }
        }
      }
    );

    var htmlPosition = zinox.ui.HtmlPosition["static"];
    $t.htmlPosition = new zino.lang.Property(zinox.ui.HtmlPosition,
      function htmlPosition$$getter() {
        return htmlPosition;
      },
      function htmlPosition$$setter(value) {
        htmlPosition = value;
        $t.element.get().style.position = value;
      }
    );

    var hidden = false;
    $t.hidden = new zino.lang.Property(Boolean,
      function hidden$$getter() {
        return hidden;
      },

      function hidden$$setter(value) {
        if (hidden != value) {
          hidden = value;
          if (hidden) {
            $t.hide();
          } else {
            $t.show();
          }
        }
      }
    );

    /*var draggable = false;
        var draggable_mousedown = null;
        var draggable_mouseup = null;
        var draggable_mousemove = null;
        $t.draggable = new zino.lang.Property(Boolean,
            function draggable$$getter(){
                return draggable;
            },
            function draggable$$setter(value){

                draggable = value;
                if(draggable){
                    $t.onmousedown.add(draggable_mousedown = function(){});
                    $t.onmouseup.add(draggable_mouseup = function(){});
                }else{
                    if(draggable_mousedown)
                }
            }
        );*/

    var parent = null;
    $t.parent = new zino.lang.Property(zinox.ui.Control,
      function parent$$getter() {
        return parent;
      },
      function parent$$setter(value, noRender) {
        if (parent) parent.controls.remove($t);
        parent = value;
        if (parent && parent.element.get()) {
          if (parent.controls.findObject($t) === undefined) parent.controls.add($t);
          if (!noRender) $t.render(parent.element.get());
        }
      }
    );

    var __SHOWCONTEXTMENU;

    var contextMenu = null;
    $t.contextMenu = new zino.lang.Property(zinox.ui.controls.ContextMenu,
      function contextMenu$$getter() {
        return contextMenu;
      },
      function contextMenu$$setter(value) {
        if (contextMenu != value) {
          contextMenu = value;
          $t.oncontextmenudisplay.remove(__SHOWCONTEXTMENU);

          if (contextMenu) $t.oncontextmenudisplay.add(__SHOWCONTEXTMENU = function contextMenu$$setter$onmouseup(e) {
            contextMenu.source.set($t);
            contextMenu.show(e);
          });
        }
      }
    );

    var zIndex = 0;
    $t.zIndex = new zino.lang.Property(Number,
      function zIndex$$getter() {
        return zIndex;
      },
      function zIndex$$setter(value) {
        zIndex = value;
        if (!$t.slzIndexed) $t.element.get().style.zIndex = zIndex;
      }
    );

    var element = null;
    $t.element = new zino.lang.Property(HTMLElement,
      function element$$getter() {
        return element;
      },
      function element$$setter(value) {
        var parentElement = ($t.parent.get() && $t.parent.get().element.get());
        if (parentElement) {
          if (element)
            parentElement.insertBefore(value, element);
          else
            parentElement.appendChild(value);
          parentElement.removeChild(element);
        }

        element = value;
        if (element.style && element.style.zIndex && !$t.slzIndexed) {
          $t.slzIndexed = true;
          $t.zIndex.set(Number(element.style.zIndex));
          $t.slzIndexed = false;
        }
        //element.style.position="absolute";
        $t.mainClass = new zino.ui.styling.ClassManager(element, $t.mainClass ? $t.mainClass.cn : null);
        $t.onclickclassic.initFunction = function zinox$ui$Control$onclickclassic() {
          $t.element.get().onclick = function () {
            return $t.onclickclassic.raise.apply($t, arguments);
          }
        };
        $t.onclick.initFunction = function zinox$ui$Control$onclick() {
          $t.onclickclassic.add(function zinox$ui$Control$onclick$onclickclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.clicked == false) {
              _.modernEvents.clicked = true;
              $t.onclick.raise.apply($t, arguments);
              _.modernEvents.clicked = false;
            }
          });
        };
        $t.oncontextmenudisplay = new zino.util.Event($t);
        $t.oncontextmenudisplay.initFunction = function zinox$ui$Control$onclick() {
          $t.onmousedownclassic.add(function zinox$ui$Control$onclick$onclickclassic(e) {
            if (e.button == 2) {
              if (_.modernEvents.ContextMenuDisplayed == false) {
                _.modernEvents.ContextMenuDisplayed = true;
                $t.oncontextmenudisplay.raise.apply($t, arguments);
                _.modernEvents.ContextMenuDisplayed = false;
                return false;
              }
            }

          });
        };
        $t.onclickclassic.add(function zinox$ui$Control$onclick$onclickclassic() {
          if (_.modernEvents.onCurrentContexted == false) {
            _.modernEvents.onCurrentContexted = true;
            if ($t.parent.get()) {
              $t.parent.get().currentContext.set($t)
            }
          }
        });

        $t.onkeydown.initFunction = function zinox$ui$Control$onkeydown() {
          $t.element.get().onkeydown = $t.onkeydown.raise
        };
        $t.onkeyup.initFunction = function zinox$ui$Control$onkeyup() {
          $t.element.get().onkeyup = $t.onkeyup.raise
        };
        $t.onkeypress.initFunction = function zinox$ui$Control$onkeypress() {
          $t.element.get().onkeypress = $t.onkeypress.raise
        };
        $t.onfocus.initFunction = function zinox$ui$Control$onfocus() {
          return $t.element.get().onfocus = $t.onfocus.raise
        };
        $t.onblur.initFunction = function zinox$ui$Control$onblur() {
          return $t.element.get().onblur = $t.onblur.raise
        };
        $t.onblur.isFirst = false;
        $t.ondblclickclassic.initFunction = function zinox$ui$Control$ondblclick() {
          $t.element.get().ondblclick = function () {
            return $t.ondblclickclassic.raise.apply($t, arguments);
          }
        };
        $t.ondblclick.initFunction = function zinox$ui$Control$ondblclick() {
          $t.ondblclickclassic.add(function zinox$ui$Control$ondblclick$ondblclickclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.dblclicked == false) {
              _.modernEvents.dblclicked = true;
              $t.ondblclick.raise.apply($t, arguments);
              _.modernEvents.dblclicked = false;
            }
          });
        };
        $t.onmouseoverclassic.initFunction = function zinox$ui$Control$onmouseoverclassic() {
          $t.element.get().onmouseover = function () {
            return $t.onmouseoverclassic.raise.apply($t, arguments);
          }
        };
        $t.onmouseover.initFunction = function zinox$ui$Control$onmouseover() {
          $t.onmouseoverclassic.add(function zinox$ui$Control$onmouseover$onmouseoverclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.mouseovered == false) {
              _.modernEvents.mouseovered = true;
              $t.onmouseover.raise.apply($t, arguments);
              _.modernEvents.mouseovered = false;
            }
          });
        };
        $t.onmouseoutclassic.initFunction = function zinox$ui$Control$onmouseoutclassic() {
          $t.element.get().onmouseout = function () {
            return $t.onmouseoutclassic.raise.apply($t, arguments);
          }
        };
        $t.onmouseout.initFunction = function zinox$ui$Control$onmouseout() {
          $t.onmouseoutclassic.add(function zinox$ui$Control$onmouseout$onmouseoutclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.mouseOuted == false) {
              _.modernEvents.mouseOuted = true;
              $t.onmouseout.raise.apply($t, arguments);
              _.modernEvents.mouseOuted = false;
            }
          });
        };
        $t.onmousedownclassic.initFunction = function zinox$ui$Control$onmousedownclassic() {
          $t.element.get().onmousedown = function () {
            return $t.onmousedownclassic.raise.apply($t, arguments);
          }
        };
        $t.onmousedown.initFunction = function zinox$ui$Control$onmousedown() {
          $t.onmousedownclassic.add(function zinox$ui$Control$onmousedown$onmousedownclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.mouseDowned == false) {
              _.modernEvents.mouseDowned = true;
              $t.onmousedown.raise.apply($t, arguments);
              _.modernEvents.mouseDowned = false;
            }
          });
        };
        $t.onmouseupclassic.initFunction = function zinox$ui$Control$onmouseupclassic() {
          $t.element.get().onmouseup = function () {
            return $t.onmouseupclassic.raise.apply($t, arguments);
          }
        };
        $t.onmouseup.initFunction = function zinox$ui$Control$onmouseup() {
          $t.onmouseupclassic.add(function zinox$ui$Control$onmouseup$onmouseupclassic(e) {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.mouseUped == false) {
              _.modernEvents.mouseUped = true;
              $t.onmouseup.raise.apply($t, arguments);
              _.modernEvents.mouseUped = false;
            }
            if (e.button == 2) return false;
          });
        };
        $t.onmousemoveclassic.initFunction = function zinox$ui$Control$onmousemoveclassic() {
          $t.element.get().onmousemove = function () {
            return $t.onmousemoveclassic.raise.apply($t, arguments);
          }
        };
        $t.onmousemove.initFunction = function zinox$ui$Control$onmousemove() {
          $t.onmousemoveclassic.add(function zinox$ui$Control$onmousemove$onmousemoveclassic() {
            if ($t.disabledCheck()) return false;
            if (_.modernEvents.mouseMoved == false) {
              _.modernEvents.mouseMoved = true;
              $t.onmousemove.raise.apply($t, arguments);
              _.modernEvents.mouseMoved = false;
            }
          });
        };
        $t.onscroll.initFunction = function zinox$ui$Control$onscroll() {
          $t.element.get().onscroll = $t.onscroll.raise;
        };

        //Drag Events inits :

        $t.ondragenter.initFunction = function zinox$ui$Control$ondragenter() {
          _.dragger.initDragEvents($t);
        };
        /*$t.ondragleave.initFunction = function zinox$ui$Control$ondragleave(){
                    $t.ondragleave.add(function(){
                        if($t._dvr_ !== undefined){
                            $t._dvr_ = false;
                            return $t.ondragleave.raise.apply($t,arguments);
                        }
                    });
                }*/
        /*
                $t.ondragleave.initFunction = function zinox$ui$Control$ondragleave(){
                    $t.element.get().onmouseout=function(){ if(_.dragger.isDragging) return $t.ondragleave.raise.apply($t,arguments); }
                }
                $t.ondragover.initFunction = function zinox$ui$Control$ondragover(){
                    $t.element.get().onmousemove=function(){ if(_.dragger.isDragging) return $t.ondragover.raise.apply($t,arguments); }
                }

                */
        $t.onfocus.add(function () {
          if ($t.form && $t.form != $t) $t.form.HAS_ACTIVE_CONTEXT = true;
        });

        // making element focusable
        if (element.getAttribute && (element.getAttribute("tabindex") == null || element.getAttribute("tabindex") == 0)) {
          element.tabIndex = 1;
          element.setAttribute("tabindex", 1);
        }
      }
    );
    $t.element.set(defaultElement ? defaultElement : ce("div"));
    var checkFocus = function zinox$ui$Control$checkFocus(e) {
      _.focused = $t;
      _.body.onblur.add(function () {
        if (_.focused === $t) _.focused = null;
      })
    };
    $t.position = new zino.ui.drawing.Position($t);
    $t.size = new zino.ui.drawing.Size($t);
    /*var checkFocus = function zinox$ui$Control$checkFocus(e){
            if($t.form && $t.form != $t){
                $t.form.HAS_ACTIVE_CONTEXT = true;
                $t.form.context=$t;
                $t.form.oncontextchange.raise()
                if(!$t.form.context.stacks)
                    $t.form.context.stacks = [];
                $t.form.context.stacks.push($t);
                $t.form.context.activeContext = $t.form.context.stacks[0];

            }else if($t == $t.form && !$t.HAS_ACTIVE_CONTEXT){
                $t.context = null;
                $t.form.oncontextchange.raise();
            }else if($t == $t.form){
                $t.HAS_ACTIVE_CONTEXT = false;
                _.context.currentForm = $t;
            }
        }*/
    var focusable = false;
    $t.focusable = new zino.lang.Property(Boolean,
      function focusable$$getter() {
        return focusable;
      },
      function focusable$$setter(value) {
        if (value) {
          $t.onfocus.add(checkFocus);
        } else {
          $t.onfocus.remove(checkFocus);
        }
      }
    );

    var _toolTip = "";
    $t.toolTip = new zino.lang.Property(String,
      function toolTip$$getter() {
        return _toolTip;
      },

      function toolTip$$setter(value) {
        _toolTip = value;
        $t.element.get().title = _toolTip;
      }

    );
    $t.focusable.set(true);
    var allowDrop = false;
    $t.allowDrop = new zino.lang.Property(Boolean,
      function allowDrop$$getter() {
        return allowDrop;
      },
      function allowDrop$$setter(value) {
        allowDrop = value;
        if (value) {
          _.dragger.dragObj.dropableControls.add($t);
          $t._dr_ = getDropRegion($t);
          $t._dmr_ = getPosition($t);
        } else if (_.dragger.dragObj.dropableControls.indexOf($t) != -1) _.dragger.dragObj.dropableControls.remove($t);
      }
    );
    var disabled = false;
    $t.disabled = new zino.lang.Property(Boolean,
      function disabled$$getter() {
        return disabled;
      },
      function disabled$$setter(value) {
        if (disabled != value) {
          disabled = value;
          if (disabled) {
            $t.mainClass.add("disabled");
            element.disabled = "true";
          } else {
            element.disabled = false;
            $t.mainClass.remove("disabled");
          }
        }
      }
    );
    if (window._itit) alert("End Control");
  }.inherit(zino.lang.Component);
  zinox.ui.Control.prototype.show = function zinox$ui$Control$show() {
    var elm = this.element.get();
    elm.style.display = "";
    if (elm.style.visibility == "hidden") elm.style.visibility = "visible";
    this.onshow.raise();
  };
  zinox.ui.Control.prototype.hide = function zinox$ui$Control$hide() {
    this.element.get().style.display = "none";
    this.onhide.raise();
  };
  zinox.ui.Control.prototype.focus = function zinox$ui$Control$focus() {
    var $t = this;
    var e = $t.element.get();
    if (e.getAttribute("tabindex") == null || e.getAttribute("tabindex") == 0) {
      e.tabIndex = 1;
      e.setAttribute("tabindex", 1);
    }
    if (!$t.disabled.get() || zino.util.Browser.Compability.isFirefox)
      e.focus();
  };
  zinox.ui.Control.prototype.jctor = function zinox$ui$Control$jctor(node, parent) {
    this.form = parent.form;
    this.parent.set(parent, true);
    this.initX(node);
    this.render(parent.element.get());
  };
  zinox.ui.Control.prototype.initX = function zinox$ui$Control$initX(node) {
    var $t = this;
    zino.lang.Component.prototype.initX.apply(this, arguments);

    if (node.getAttribute("css-class")) $t.mainClass.add(eval(ea(node.getAttribute("css-class"))));
    if (node.getAttribute('tool-tip')) {
      $t.toolTip.set(eval(ea(node.getAttribute('tool-tip'))))
    };
    if (node.getAttribute("html-position")) $t.htmlPosition.set(zinox.ui.HtmlPosition[node.getAttribute("html-position")]);

    if (node.getAttribute("clayout")) {
      try {
        var cl = eval(ea(node.getAttribute('clayout')));
        if (cl && (cl instanceof zinox.ui.controls.Layout)) {
          cl.containers.add($t, (node.getAttribute('keyName') || "container_" + zino.getHandle($t)));
        }
      } catch (er) {}
    }
    if (node.getAttribute("onclickclassic")) {
      $t.onclickclassic.add(eval(ea(node.getAttribute("onclickclassic"), "function")));
    }
    if (node.getAttribute("onmouseoverclassic")) {
      $t.onmouseoverclassic.add(eval(ea(node.getAttribute("onmouseoverclassic"), "function")));
    }
    if (node.getAttribute("onmouseoutclassic")) {
      $t.onmouseoutclassic.add(eval(ea(node.getAttribute("onmouseoutclassic"), "function")));
    }
    if (node.getAttribute("onmousedownclassic")) {
      $t.onmousedownclassic.add(eval(ea(node.getAttribute("onmousedownclassic"), "function")));
    }
    if (node.getAttribute("onmouseupclassic")) {
      $t.onmouseupclassic.add(eval(ea(node.getAttribute("onmouseupclassic"), "function")));
    }
    if (node.getAttribute("onenter")) {
      $t.onenter.add(eval(ea(node.getAttribute("onenter"), "function")));
    }
    if (node.getAttribute("onleave")) {
      $t.onleave.add(eval(ea(node.getAttribute("onleave"), "function")));
    }
    if (node.getAttribute("onclick")) {
      $t.onclick.add(eval(ea(node.getAttribute("onclick"), "function")));
    }
    if (node.getAttribute("onkupwn")) {
      $t.onkeydown.add(eval(ea(node.getAttribute("onkeydown"), "function")));
    }
    if (node.getAttribute("onkeyup")) {
      $t.onkeyup.add(eval(ea(node.getAttribute("onkeyup"), "function")));
    }
    if (node.getAttribute("onkeypress")) {
      $t.onkeypress.add(eval(ea(node.getAttribute("onkeypress"), "function")));
    }
    if (node.getAttribute("ondblclick")) {
      $t.ondblclick.add(eval(ea(node.getAttribute("ondblclick"), "function")));
    }
    if (node.getAttribute("onhide")) {
      $t.onhide.add(eval(ea(node.getAttribute("onhide"), "function")));
    }
    if (node.getAttribute("onmousedown")) {
      $t.onmousedown.add(eval(ea(node.getAttribute("onmousedown"), "function")));
    }
    if (node.getAttribute("onmousemove")) {
      $t.onmousemove.add(eval(ea(node.getAttribute("onmousemove"), "function")));
    }
    if (node.getAttribute("onmouseout")) {
      $t.onmouseout.add(eval(ea(node.getAttribute("onmouseout"), "function")));
    }
    if (node.getAttribute("onmouseover")) {
      $t.onmouseover.add(eval(ea(node.getAttribute("onmouseover"), "function")));
    }
    if (node.getAttribute("onmouseup")) {
      $t.onmouseup.add(eval(ea(node.getAttribute("onmouseup"), "function")));
    }
    if (node.getAttribute("onshow")) {
      $t.onshow.add(eval(ea(node.getAttribute("onshow"), "function")));
    }
    if (node.getAttribute("onblur")) {
      $t.onblur.add(eval(ea(node.getAttribute("onblur"), "function")));
    }
    if (node.getAttribute("onchange")) {
      $t.onchange.add(eval(ea(node.getAttribute("onchange"), "function")));
    }
    if (node.getAttribute("onfocus")) {
      $t.onfocus.add(eval(ea(node.getAttribute("onfocus"), "function")));
    }

    if (node.getAttribute("onrender")) {
      $t.onrender.add(eval(ea(node.getAttribute("onrender"), "function")));
    }

    if (node.getAttribute("class")) $t.mainClass.add(node.getAttribute("class"));
    if (node.getAttribute("disabled")) $t.disabled.set(node.getAttribute("disabled"));


    if (node.getAttribute("allow-drop")) {
      $t.allowDrop.set(eval(ea(node.getAttribute("allow-drop"), "Boolean")))
    };

    if (node.getAttribute("style")) {
      $t.element.get().style.cssText = node.getAttribute("style");
    }
    if (node.getAttribute("context-menu")) {
      $t.contextMenu.set(eval(ea(node.getAttribute("context-menu"))));
    }
    if (node.getAttribute("z-index")) {
      $t.zIndex.set(eval(ea(node.getAttribute("z-index"))));
    }
    if (node.getAttribute("hidden")) {
      $t.hidden.set(eval(ea(node.getAttribute("hidden"), "Boolean")));
    }
  };
  zinox.ui.Control.prototype.render = function zinox$ui$Control$render(container) {
    var $t = this;
    $t.rendered = true;
    container.appendChild($t.element.get());
    if ($t.allowDrop.get()) {
      $t._dr_ = getDropRegion($t);
      $t._dmr_ = getPosition($t);
      $t.currentDropRegion.set(new zinox.ui.controls.RegionControl($t._dr_, $t));
    }
    this.onrender.raise();
  };
  zinox.ui.Control.prototype.doDragDrop = function zinox$ui$Control$doDragDrop(e, object, allowedEffects, dropEffects, vectorMode, dragParent) {
    var $t = this;
    _.dragger.dragStart(e, object, allowedEffects, dropEffects, vectorMode, dragParent);
  };
  zinox.ui.Control.prototype.dispose = function zinox$ui$Control$dispose() {
    var $t = this;
    $t.disposed = true;

    for (var i = 0; i < $t.handles.length; i++)
      $t.handles[i].dispose();

    $t.parent.get().removeChild($t.element.get());
  };
  zinox.ui.Control.prototype.disabledCheck = function zinox$ui$Control$disabledCheck() {
    var $t = this;
    while ($t && $t.disabled && !$t.disabled.get() && ($t = $t.parent.get()));
    return !!$t && !!$t.disabled;
  };
  zinox.ui.Control.prototype.findControl = function zinox$ui$Control$findControl(id) {
    var $t = this;
    var fc, fel;
    for (var i = 0; i < $t.controls.length; i++) {
      if ($t.controls[i].id == id || ((fel = $t.controls[i].element.get()) && fel.id == id)) return $t.controls[i];
      else if (fc = $t.controls[i].findControl(id)) return fc;
    }
    return false;
  };
  zinox.ui.Control.prototype.findControl2 = function zinox$ui$Control$findControl(id) {
    var $t = this;
    var fc;
    if ($t[id]) return $t[id];
    else {
      for (var i = 0; i < $t.controls.length; i++) {
        if (fc = $t.controls[i].findControl(id)) return fc;
      }
    }
    return false;
  };
  zinox.ui.Control.prototype.getPage = function zinox$ui$Control$getPage(f) {
    var $t = this,
      frm = $t.parent.get();
    if (frm == _.body) return _.body;
    if (f) {
      if (frm instanceof zinox.ui.controls.Form) return frm;
      else return frm.getPage(f);
    } else {
      if (frm instanceof zinox.ui.controls.Page) return frm;
      else return frm.getPage();
    }
    return false;
  };

  zinox.ui.Control.prototype.getForm = function zinox$ui$Control$getForm() {
    var $t = this;
    var frm;
    if ((frm = $t.parent.get()).toString() == "[object zinox.ui.controls.Form]") return frm;
    else return frm.getForm();
    return false;
  };
  zinox.ui.Control.prototype.isParentOf = function zinox$ui$Control$isParentOf(l) {
    while (l && (l = l.parent.get()) != this);
    return !!l;
  };
  zinox.ui.Control.prototype.isChildOf = function zinox$ui$Control$isChildOf(l) {
    return l.isParentOf(this);
  };
  zinox.ui.Control.prototype.getTrain = function zinox$ui$Control$getTrain(p) {
    var $t = this,
      l = this,
      pi = "",
      base;
    if ($t === _.win || $t === _.body) return 0;
    if (p) {
      if (p === _.win) base = _.body;
      else base = p;
    } else base = _.body;
    if (!base.isParentOf($t)) return -1;
    while (l && l != base) {
      var l0 = l;
      l = l.parent.get();
      pi += l.controls.indexOf(l0);
    }
    return new Number(parseInt("1" + pi.invert()));
  };
  zinox.ui.HtmlPosition = new zino.lang.Enum({
    "static": "static",
    "absolute": "absolute",
    "relative": "relative",
    "fixed": "fixed"
  });
  _.ns.prepare('zinox.ui.controls.RegionControl');
  _.ns.prepare('zinox.ui.controls.ContextMenu');
  //End ui.Control}
  //{Start ui.Bindable
  _.ns.registerS("zinox.ui.Bindable");
  zinox.ui.Bindable = function zinox$ui$BindableControl() {
    arguments.callee.superClass.apply(this, arguments);
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zinox.ui.Bindable';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.2a';
    $t._CREATEDATE = '2007/10/15';
    $t._MODIFIEDDATE = '2007/10/15';
    var _value = null;
    $t.value = new zino.lang.Property(String,
      function value$$getter() {
        return _value;
      },
      function value$$setter(value) {
        _value = value;
      }
    );
  }.inherit(zinox.ui.Control);
  //End ui.Bindable}
  //{Start zinox.ui.controls.Label
  _.ns.registerS("zinox.ui.controls.Label");
  zinox.ui.controls.Label = function zinox$ui$controls$Label(d) {
    var isspn = (d && d.nodeType == 1 && d.tagName == "span");
    arguments.callee.superClass.call(this, (isspn ? d : ce("span")));
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zinox.ui.controls.Label';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.1.4';
    $t._CREATEDATE = '2006/06/19';
    $t._MODIFIEDDATE = '2007/09/05';
    $t.mainClass.add("zinox-ui-controls-label");
    var text = "";
    $t.text = new zino.lang.Property(String,
      function text$$getter() {
        return text;
      },
      function text$$setter(value) {
        if (text == value) return void(0);
        en($t.element.get());
        $t.element.get().appendChild(ct(text = value));
      }
    );
    $t.value = $t.text;
    if (d) $t.text.set(isspn ? d.innerHTML : d);
  }.inherit(zinox.ui.Bindable);
  zinox.ui.controls.Label.prototype.initX = function zinox$ui$controls$Label$initX(node) {
    zinox.ui.Control.prototype.initX.apply(this, arguments);
    var $t = this;
    if (node.getAttribute("text")) $t.text.set(eval(ea(node.getAttribute("text"))));
  };
  zino.core.RenderEngine.registerTag('http://ns.partia.com/zino', 'label', zinox.ui.controls.Label);
  //End zinox.ui.controls.Label}
  //{Start zinox.ui.controls.Page
  _.ns.registerS("zinox.ui.controls.Page");
  zinox.ui.controls.Page = function zinox$ui$controls$Page(defaultText, hasUi) {
    arguments.callee.superClass.call(this);
    var $t = this;
    $t._AUTHOR = 'Shayan Nojedehi';
    var cl = 'zinox.ui.Bindable';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.2a';
    $t._CREATEDATE = '2007/10/15';
    $t._MODIFIEDDATE = '2007/10/15';
    $t.mainClass.add("zinox-ui-controls-page");
    $t.oncontextchange = new zino.util.Event($t);
    $t.context = null;
    $t.tabButtonIcon = null;
    $t.contentRendered = false;
    $t.rendered = false;
    $t.onload = new zino.util.Event($t);
    $t.onreload = new zino.util.Event($t);
    $t.onclose = new zino.util.Event($t);
    $t.onbeforenclose = new zino.util.Event($t);
    $t.onrendercomplete = null;
    $t.hide();
    $t.hasUi = (hasUi === undefined) ? true : hasUi;
    var _validators = [];
    $t.validators = new zino.lang.Property(Array,
      function validators$$getter() {
        return _validators;
      },
      function validators$$setter(value) {
        _validators.push(value);
      }
    );

    var text = "";
    $t.text = new zino.lang.Property(String,
      function text$$getter() {
        return text;
      },
      function text$$setter(value) {
        text = value;
      }
    );

    var closable = null;
    $t.closable = new zino.lang.Property(Boolean,
      function closable$$getter() {
        return closable;
      },
      function closable$$setter(value) {
        closable = value;
      }
    );

    var content = null;
    $t.content = new zino.lang.Property(HTMLElement,
      function content$$getter() {
        return content;
      },
      function content$$setter(value) {
        content = value;
        if ($t.contentRendered && $t.rendered) {
          $t.renderContent();
        }
      }
    );

    var layoutName = null;
    $t.layoutName = new zino.lang.Property(HTMLElement,
      function layoutName$$getter() {
        return layoutName;
      },
      function layout$$setter(value) {
        layoutName = value;
        if ($t.contentRendered)
          $t.applyLayout();
      }
    );

    var url = null;
    $t.url = new zino.lang.Property(String,
      function url$$getter() {
        return url;
      },
      function url$$setter(value) {
        $t.load(url = value);
      }
    );
    $t.changeUrl = function (newUrl) {
      url = newUrl;
    };
    var _codeBehind = null;
    $t.codeBehind = new zino.lang.Property(String,
      function codeBehind$$getter() {
        return _codeBehind;
      },
      function codeBehind$$setter(value) {
        _codeBehind = value;
      }
    );

    if (_.themes)
      _.themes.onchange.add(function zinox$ui$controls$Page$onchange() {
        $t.applyLayout();
      });

    if (defaultText) $t.text.set(defaultText);

  }.inherit(zinox.ui.Control);

  zinox.ui.controls.Page.prototype.queryString = function zinox$ui$controls$Page$queryString(value) {
    var $t = this;
    if ($t.url.get() && value) {
      if ($t.url.get().indexOf("?") > -1) {
        var qs = $t.url.get().split("?")[1];
        var list = qs.split("&");
        for (var i = 0; i < list.length; i++) {
          var ft = list[i].split("=");
          if (ft[0] == value) return ft[1];
        }
      }
    }
    return null;
  }

  zinox.ui.controls.Page.prototype.isValid = function zinox$ui$controls$Page$isValid(validationGroup) {
    var $t = this;
    var Validators = $t.validators.get();
    var returnValue = true;
    for (var indx = 0; indx < Validators.length; indx++) {
      if (Validators[indx].disabled.get() != true && Validators[indx].isValid && Validators[indx].validationGroup.get() == validationGroup && !Validators[indx].isValid()) returnValue = false;
    }
    return returnValue;
  }

  zinox.ui.controls.Page.prototype.render = function zinox$ui$controls$Page$render(container) {
    var $t = this;
    try {
      zinox.ui.Control.prototype.render.apply(this, arguments);
      $t.rendered = true;

      if ($t.__RENDERCONTENT_CALLED) {
        $t.renderContent();
      }
    } catch (e) {
      alertr(["zinox$ui$controls$Page$render", e]);
    }
  };
  zinox.ui.controls.Page.prototype.initX = function zinox$ui$controls$Page$initX(node) {
    var $t = this;
    zinox.ui.Control.prototype.initX.apply(this, arguments);
    if (node.getAttribute("code-behind")) $t.codeBehind.set(node.getAttribute("code-behind"));
    if (node.getAttribute("text")) $t.text.set(eval(ea(node.getAttribute("text"))));
    if (node.getAttribute("onrendercomplete")) $t.onrendercomplete = eval(ea(node.getAttribute("onrendercomplete"), "function"));
    if (node.getAttribute("url")) $t.url.set(eval(ea(node.getAttribute("url"))));
    if (node.getAttribute("closable")) $t.closable.set(eval(ea(node.getAttribute("closable"), "boolean")));
    if (node.getAttribute("layout")) $t.layoutName.set(eval(ea(node.getAttribute("layout"))));
    if (node.getAttribute("icon")) $t.tabButtonIcon = eval(ea(node.getAttribute("icon")));
    $t.content.set(node);
    if (node.getAttribute("url")) $t.url.set(eval(ea(node.getAttribute("url"))));
  };
  zinox.ui.controls.Page.prototype.load = function zinox$ui$controls$Page$load(url, method) {
    var $t = this;
    var xRequest = new zino.net.HTTPRequest(url, (method || "GET"));
    xRequest.onLoad.add(function zinox$ui$controls$Page$loadPage$$$xRequest$$$onLoad() {
      try {
        setNamespaces(xRequest.response.XML.lastChild);
        $t.contentRendered = true;
        if (!$t.hasUi) $t.rendered = true;
        // $t.content.set(xRequest.response.XML.lastChild.childNodes[0]);
        $t.initX(xRequest.response.XML.lastChild.childNodes[0]);
      } catch (e) {
        alert(e + "***");
      }
    });
    xRequest.load();
  };
  zinox.ui.controls.Page.prototype.renderContent = function zinox$ui$controls$Page$renderContent() {
    var $t = this;
    try {
      if ($t.rendered) {
        //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(1);
        if ($t.content.get()) {
          //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(2);
          if ($t.contentRendered) {
            en($t.element.get());
          }
          //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(3);
          var r = new zino.core.RenderEngine($t.onrendercomplete);
          //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(4);
          r.onrender.add(function zinox$ui$controls$Page$renderContent$onadd() {
            if ($t.layoutName.get()) $t.applyLayout();
            $t.onload.raise();
          });
          //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(5);
          //***************
          if ($t.codeBehind.get()) {
            var ns = $t.codeBehind.get();
            _.ns.includeC(ns, function () {
              try {
                ___pppp = [ns, $t];
                var oldFunc = $t.onrendercomplete;
                ns = eval(ns);
                ns.call($t);
                if (oldFunc && $t.onrendercomplete && $t.onrendercomplete != oldFunc)
                  r.onrendercomplete = oldFunc.add($t.onrendercomplete);
                else if (!oldFunc && $t.onrendercomplete)
                  r.onrendercomplete = $t.onrendercomplete;

                //$t.func__temp =  Function(xReq.response.text);
                // $t.func__temp();
                //delete $t.func__temp;
                r.renderNode($t.content.get().firstChild, $t);
              } catch (e) {
                alert(e + "***");
              }
            });
          } else
            r.renderNode($t.content.get().firstChild, $t);
          //if($t.url.get()=="/dario/DX-INF/classes/zino/com/partia/dario/home.zino" ) alert(6);
        }
      } else {
        $t.__RENDERCONTENT_CALLED = true;
      }
      $t.contentRendered = true;
      //__abc=$t;
      // alert($t.onrendercomplete)
      //$t.onrendercomplete.add(function(){alert('asdsa');});
      // $t.onrendercomplete.raise();
    } catch (e) {
      //alertr(["zinox$ui$controls$Page$renderContent",e]);
      ____e = e;
      throw new zino.lang.Exception(null, {
        source: this
      }, e, "zinox.ui.controls.Page.renderContent", "zinox.ui.controls.Page.js", 141);
    }
  };
  zinox.ui.controls.Page.prototype.applyLayout = function zinox$ui$controls$Page$applyLayout() {
    var layout = _.themes.current.layouts[this.layoutName.get()];
    if (layout) {
      en(this.element.get());
      var r = new zino.core.RenderEngine();
      r.renderNode(layout.firstChild, this);
    }
  };
  zinox.ui.controls.Page.prototype.show = function zinox$ui$controls$Page$show() {
    var $t = this;
    if (!$t.contentRendered) {
      $t.renderContent();
    }
    zinox.ui.Control.prototype.show.apply(this, arguments);
  };
  zinox.ui.controls.Page.prototype.reload = function zinox$ui$controls$Page$reload() {
    var $t = this;
    $t.load($t.url.get());
    $t.onreload.raise();
  };
  _.ns.prepare('zinox.ui.controls.PageSet');
  //End zinox.ui.controls.Page}
  //{Start zinox.ui.controls.HtmlControl
  _.ns.registerS("zinox.ui.controls.HtmlControl");
  zinox.ui.controls.HtmlControl = function zinox$ui$controls$HtmlControl(defaultElement) {
    arguments.callee.superClass.apply(this, arguments);
    var $t = this;
    $t._AUTHOR = 'Mehran Hatami';
    var cl = 'zinox.ui.controls.HtmlControl';
    setType($t, eval(cl), cl);
    $t._VERSION = '0.7.2a';
    $t._CREATEDATE = '2007/07/31';
    $t._MODIFIEDDATE = '2007/09/05';
  }.inherit(zinox.ui.Control);
  zinox.ui.controls.HtmlControl.prototype.render = function zinox$ui$controls$HtmlControl(container) {
    var $t = this;
    $t.rendered = true;
    if (($t.element.get().baseName.toLowerCase() != "tr") && ($t.element.get().baseName.toLowerCase() != "td")) {
      container.appendChild($t.element.get());
      if ($t.allowDrop.get()) {
        $t._dr_ = getDropRegion($t);
        $t._dmr_ = getPosition($t);
      }
    }
    this.onrender.raise();
  };
  //End zinox.ui.controls.HtmlControl}
  _.browser = new zino.util.BrowserCompabilityInspector();
  _.body = new zinox.ui.controls.HtmlControl(_.body.element.get());
  _.win = new zinox.ui.controls.HtmlControl(_.win.element.get());
  _.cmn.lmsg = new zinox.ui.controls.Label(gel("zino-loading-title"));

  var modernClick = function modernClick() {
    _.modernEvents.clicked = false;
    _.modernEvents.onCurrentContexted = false;
  };
  _.win.onclick.add(modernClick);
  _.body.onclick.add(modernClick);

  var moderndblClick = function moderndblClick() {
    _.modernEvents.dblclicked = false
  };
  _.win.ondblclick.add(moderndblClick);
  _.body.ondblclick.add(moderndblClick);

  var modernMouseDown = function modernMouseDown() {
    _.modernEvents.mouseDowned = false;
    _.modernEvents.ContextMenuDisplayed = false
  };
  _.win.onmousedown.add(modernMouseDown);
  _.body.onmousedown.add(modernMouseDown);

  var modernMouseUp = function modernMouseUp() {
    _.modernEvents.mouseUped = false;
  };
  _.win.onmouseup.add(modernMouseUp);
  _.body.onmouseup.add(modernMouseUp);

  var modernMouseMove = function modernMouseMove() {
    _.modernEvents.mouseMoved = false;
  };
  _.win.onmousemove.add(modernMouseMove);
  _.body.onmousemove.add(modernMouseMove);

  var bodyModernMouseMove = function $bodyModernMouseMove(e) {
    _.dragger.raiseDragDropEvents(e);
  };

  _.body.onmousemove.add(bodyModernMouseMove);

  var modernMouseOver = function modernMouseOver() {
    _.modernEvents.mouseOvered = false;
  };
  _.win.onmouseover.add(modernMouseOver);
  _.body.onmouseover.add(modernMouseOver);

  var modernMouseOut = function modernMouseOut() {
    _.modernEvents.mouseOuted = false;
  };
  _.win.onmouseout.add(modernMouseOut);
  _.body.onmouseout.add(modernMouseOut);

  var checkContext = function checkContext() {
    if (_.context.currentContextMenu) {
      _.context.lastContextMenu = _.context.currentContextMenu;
      _.context.currentContextMenu = null;
      return false;
    } else {
      if (_.context.lastContextMenu) _.context.lastContextMenu.hide();
    }
  };
  _.win.onclickclassic.add(checkContext);
  _.win.ondblclickclassic.add(function () {
    return false;
  });

  var tabPressed = function tabPressed(e) {
    if (e.keyCode == 9) {

      if (!_.context.current) return;
      alert(0)
      var index = _.context.current.tabIndex.get() + (e.shiftKey == true) ? -1 : 1;

      var nextControlIndex = _.tabIndexes[index] ? _.tabIndexes.orders[index] : (e.shiftKey) ? _.tabIndexes.orders[_.tabIndexes.orders.length - 1] : _.tabIndexes.orders[0];
      var nextControl = _.tabIndexes.controls[nextControlIndex];
      nextControl.parent.currentContext.set(nextControl);

    }
  };
  //firefox
  //_.win.onkeypress.add(tabPressed);_.body.onkeypress.add(tabPressed);
  //safari
  _.win.onkeydown.add(tabPressed);
  _.body.onkeypress.add(tabPressed);


  _.xMain.onLoad.add(function zino$core$ThemeManager$Run() {
    _.nMain = _.xMain.response.XML;
    _.body.onRenderComplete = new zino.util.Event(_.body);
    //_.r.lastChild = _.nMain.lastChild.lastChild;
    _.r.render(_.nMain, _.body);
    _.body.rendered = true;
    _.body._dr_ = getDropRegion(_.body);
    _.body._dmr_ = getPosition(_.body);
    _.dragger.bodyRect = getRectangle(_.body.element.get());
    _.win.onresize = new zino.util.Event(_.win);
    _.win.element.get().onresize = function (e) {
      _.win.onresize.raise(e || window.event);
      _.body._dr_ = getDropRegion(_.body);
      _.body._dmr_ = getPosition(_.body);
      if (_.dragger) _.dragger.bodyRect = getRectangle(_.body.element.get());
    };
    if (!_.config.defaultCulture) _.config.defaultCulture = "en-US";
    if (_.config.defaultCulture == "fa-IR") window.document.lastChild.setAttribute("dir", "rtl");
    if (_.config.defaultCulture) {
      _.ns.includeC("zino.core.CultureManager", zino.core.Loader.initincludes.cultureManager);
    } else {
      _.ns.includeC("zino.core.StyleManager", zino.core.Loader.initincludes.styleManager);
    };
  });
  _.xMain.load();
  if (isFunc(window.loadLocalization)) loadLocalization();
  if (isFunc(window.loadZinoX)) loadZinoX();
  if (isFunc(window.loadXmlAPIs)) loadXmlAPIs();
};
/**
 *
 *  MD5 (Message-Digest Algorithm)
 *  http://www.webtoolkit.info/
 *
 **/
var MD5 = function (string) {

  function RotateLeft(lValue, iShiftBits) {
    return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
  }

  function AddUnsigned(lX, lY) {
    var lX4, lY4, lX8, lY8, lResult;
    lX8 = (lX & 0x80000000);
    lY8 = (lY & 0x80000000);
    lX4 = (lX & 0x40000000);
    lY4 = (lY & 0x40000000);
    lResult = (lX & 0x3FFFFFFF) + (lY & 0x3FFFFFFF);
    if (lX4 & lY4) {
      return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
    }
    if (lX4 | lY4) {
      if (lResult & 0x40000000) {
        return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
      } else {
        return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
      }
    } else {
      return (lResult ^ lX8 ^ lY8);
    }
  }

  function F(x, y, z) {
    return (x & y) | ((~x) & z);
  }

  function G(x, y, z) {
    return (x & z) | (y & (~z));
  }

  function H(x, y, z) {
    return (x ^ y ^ z);
  }

  function I(x, y, z) {
    return (y ^ (x | (~z)));
  }

  function FF(a, b, c, d, x, s, ac) {
    a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
    return AddUnsigned(RotateLeft(a, s), b);
  };

  function GG(a, b, c, d, x, s, ac) {
    a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
    return AddUnsigned(RotateLeft(a, s), b);
  };

  function HH(a, b, c, d, x, s, ac) {
    a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
    return AddUnsigned(RotateLeft(a, s), b);
  };

  function II(a, b, c, d, x, s, ac) {
    a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
    return AddUnsigned(RotateLeft(a, s), b);
  };

  function ConvertToWordArray(string) {
    var lWordCount;
    var lMessageLength = string.length;
    var lNumberOfWords_temp1 = lMessageLength + 8;
    var lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
    var lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
    var lWordArray = Array(lNumberOfWords - 1);
    var lBytePosition = 0;
    var lByteCount = 0;
    while (lByteCount < lMessageLength) {
      lWordCount = (lByteCount - (lByteCount % 4)) / 4;
      lBytePosition = (lByteCount % 4) * 8;
      lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount) << lBytePosition));
      lByteCount++;
    }
    lWordCount = (lByteCount - (lByteCount % 4)) / 4;
    lBytePosition = (lByteCount % 4) * 8;
    lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
    lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
    lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
    return lWordArray;
  };

  function WordToHex(lValue) {
    var WordToHexValue = "",
      WordToHexValue_temp = "",
      lByte, lCount;
    for (lCount = 0; lCount <= 3; lCount++) {
      lByte = (lValue >>> (lCount * 8)) & 255;
      WordToHexValue_temp = "0" + lByte.toString(16);
      WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
    }
    return WordToHexValue;
  };

  function Utf8Encode(string) {
    string = string.replace(/\r\n/g, "\n");
    var utftext = "";

    for (var n = 0; n < string.length; n++) {

      var c = string.charCodeAt(n);

      if (c < 128) {
        utftext += String.fromCharCode(c);
      } else if ((c > 127) && (c < 2048)) {
        utftext += String.fromCharCode((c >> 6) | 192);
        utftext += String.fromCharCode((c & 63) | 128);
      } else {
        utftext += String.fromCharCode((c >> 12) | 224);
        utftext += String.fromCharCode(((c >> 6) & 63) | 128);
        utftext += String.fromCharCode((c & 63) | 128);
      }

    }

    return utftext;
  };

  var x = Array();
  var k, AA, BB, CC, DD, a, b, c, d;
  var S11 = 7,
    S12 = 12,
    S13 = 17,
    S14 = 22;
  var S21 = 5,
    S22 = 9,
    S23 = 14,
    S24 = 20;
  var S31 = 4,
    S32 = 11,
    S33 = 16,
    S34 = 23;
  var S41 = 6,
    S42 = 10,
    S43 = 15,
    S44 = 21;

  string = Utf8Encode(string);

  x = ConvertToWordArray(string);

  a = 0x67452301;
  b = 0xEFCDAB89;
  c = 0x98BADCFE;
  d = 0x10325476;

  for (k = 0; k < x.length; k += 16) {
    AA = a;
    BB = b;
    CC = c;
    DD = d;
    a = FF(a, b, c, d, x[k + 0], S11, 0xD76AA478);
    d = FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
    c = FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
    b = FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
    a = FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
    d = FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
    c = FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
    b = FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
    a = FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
    d = FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
    c = FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
    b = FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
    a = FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
    d = FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
    c = FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
    b = FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
    a = GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
    d = GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
    c = GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
    b = GG(b, c, d, a, x[k + 0], S24, 0xE9B6C7AA);
    a = GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
    d = GG(d, a, b, c, x[k + 10], S22, 0x2441453);
    c = GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
    b = GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
    a = GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
    d = GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
    c = GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
    b = GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
    a = GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
    d = GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
    c = GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
    b = GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
    a = HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
    d = HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
    c = HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
    b = HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
    a = HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
    d = HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
    c = HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
    b = HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
    a = HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
    d = HH(d, a, b, c, x[k + 0], S32, 0xEAA127FA);
    c = HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
    b = HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
    a = HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
    d = HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
    c = HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
    b = HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
    a = II(a, b, c, d, x[k + 0], S41, 0xF4292244);
    d = II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
    c = II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
    b = II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
    a = II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
    d = II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
    c = II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
    b = II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
    a = II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
    d = II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
    c = II(c, d, a, b, x[k + 6], S43, 0xA3014314);
    b = II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
    a = II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
    d = II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
    c = II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
    b = II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
    a = AddUnsigned(a, AA);
    b = AddUnsigned(b, BB);
    c = AddUnsigned(c, CC);
    d = AddUnsigned(d, DD);
  };

  var temp = WordToHex(a) + WordToHex(b) + WordToHex(c) + WordToHex(d);

  return temp.toLowerCase();
};