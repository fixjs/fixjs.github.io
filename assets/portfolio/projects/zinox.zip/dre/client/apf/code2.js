function rotateElement(turn) {
    if(!wfExample.selected) {
        alert("Select element.");
    }
    else{
        var sel = wfExample.selected;

        var rotation = !sel.getAttribute("rotation") ? 0 : parseInt(sel.getAttribute("rotation"));

        if(turn == 1) {
            rotation +=90;
            if(rotation>270) {
                rotation = 0;
            }
        }
        else if (turn == 0) {
            rotation -=90;
            if(rotation<0) {
                rotation = 270;
            }
        }
        wfExample.rotate(sel, rotation);
    }
}

function flipv() {
    if(!wfExample.selected) {
        alert("Select element.");
    }
    else {
        var sel = wfExample.selected;
        wfExample.flipVertical(sel, parseInt(sel.getAttribute("flipv")) == "true" ? false : true);
    }   
}

function fliph() {
    if(!wfExample.selected) {
        alert("Select element.");
    }
    else {
        var sel = wfExample.selected;
        wfExample.flipHorizontal(sel, parseInt(sel.getAttribute("fliph")) == "true" ? false : true);
    }   
}

function lockToggleSelected(){
    if(!wfExample.selected){
        alert("Select element.");
    } 
    else{
        var sel = wfExample.selected;
        var lock = sel.getAttribute("lock") == "true" ? true : false;
        wfExample.setLock(sel, lock ? false : true);
    }
}

function zindex(){
    if(!wfExample.selected){
        alert("Select element.");
    } 
    else{
        var sel = wfExample.selected;
        var zindex = parseInt(sel.getAttribute("zindex"));
        wfExample.setZindex(sel, (zindex-1));
    }
}

function addBlock() {
    wfExample.addBlock(
        MainList.selected.getAttribute("type"),
        20,
        20,
        MainList.selected.getAttribute("caption")
    );
}