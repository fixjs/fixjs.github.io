/*!
	require zinox.ui.controls.Panel;
*/
com.partia.examples.DesignControl = function com$partia$zino$componentexplorer$Lab$DesignPage$DesignControl(){
	arguments.callee.superClass.apply(this,arguments);
	/*<init class="zinox.ui.controls." 
			version="0.1.1a"
			ns="http://ns.partia.com/zino1/comexp"
			tag="design-control"
			author="Shayan Nojedehi" 
			createdate="2007/10/23" />*/

	$t.element.set(ce("span"));
}.inherit(zinox.ui.controls.Panel);