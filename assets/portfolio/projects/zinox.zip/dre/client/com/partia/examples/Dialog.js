/*!
 	import zinox.ui.controls.dialog.Panel; 
 */
com.partia.Dialog = function com$partia$dario$dialog(caption, page,
		onrendercomplete, QueryString, shortKeyFunction) {
	var url = _.ns.getPath(page, "zino");
	if (QueryString)
		url = url + "?" + QueryString + "";
	if (!_.isVisible) {
		_.dialog.isVisible = true;
		_.body.controls.add(_.dialog.dialog = new zinox.ui.controls.dialog.Panel());
		// _.dario.dialog.dialog.mainClass.add("main_loading_panel");
		_.dialog.dialog.mainClass.add("dario-dialog-panel");
		__caption = caption;
		_.dialog.dialog.caption.set(caption);
		if (arguments[4] && typeof(arguments[4]) == "number")
			_.dialog.dialog.element.get().style.width = px(arguments[4]);

		_.dialog.dialog.onhide.add(function() {
					delete _.dialog.isVisible;
				});
		if (!window[page])
			_.dialog.page = new zinox.ui.controls.Page();
		_.dialog.dialog.contentContainer.controls.add(_.dialog.page);
		_.ns.prepare(page);
		if (onrendercomplete)
			_.dialog.page.onrendercomplete = onrendercomplete;
		if (shortKeyFunction)
			_.dialog.dialog.onkeypress.add(shortKeyFunction);
		_.dialog.page.url.set(url);
		_.dialog.page.show();
		//_.dialog.dialog.show(_.mainTabeView);
		_.dialog.page.focus();
	}
};

com.partia.Dialog.clearDialog = function(time, focusElement) {
	focusElement = focusElement;// || _.dario.mainTabView.current.get();
	if (_.dialog.isVisible) {
		var t = time || 2000;
		setTimeout(function() {
					try {
						if (_.dialog.isVisible) {
							_.dialog.dialog.hide();
							focusElement.focus();
						}
					} catch (e) {
					}
				}, t);
	}
};
_.dialog = {};