/*!
 	require zinox.ui.controls.PathNavigatorItem;
 */
com.partia.examples.PathNavigator = function com$partia$zino$componentexplorer$ObjectViewer(){

}

com.partia.examples.PathNavigator.prototype = {
	
	addItems : function $showObject(obj){
		var pn = Partia.Zino1.PathNavigator.pathNavigator;
		for ( var i = 0 ; i < 4 ; i++)
		{
			var item = new zinox.ui.controls.PathNavigatorItem();
			item.text.set(i + "caption");
			item.itemValue.set(i );
			pn.addNewPath(item);
		}
	}
}
