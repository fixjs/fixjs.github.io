/*!
 	require System.Data.DataSet.Table.Field;
 	require System.Data.DataSet.Table;
 	require System.Data.DataSet;
 	require System.Data.DataAdapter;
 */
com.partia.examples.Form2 = function com$partia$library$ui$bs$bsLibrary(){

}

com.partia.examples.Form2.prototype = {
	
	select : function $select(status,bookName,startIndex,pageSize){
		var $t = this;
		var tbl = new System.Data.DataSet.Table;
		tbl.id = "tbl2";
		$t.createSchema(tbl);
		var url;
		//alert("status=" + status + " bookName=" + bookName + " startIndex=" + startIndex + " pageSize=" + pageSize)
		if ( status.toLocaleLowerCase() == "search")
			url = "../examples/BookList3.xml";
		else
		{
			if ( startIndex == 0 )
				 url = "../examples/BookList.xml";
			else 
				url = "../examples/BookList2.xml";
		}
			
		var dataAdapter = new System.Data.DataAdapter(url);
		dataAdapter.action(tbl,dataAdapter.commands[0])
		
		return tbl;
	},
	selectCount : function $selectCount(status,bookName){
		if ( status.toLocaleLowerCase() == "search")
			 return 4;
		else 
			return 48;
	},
	createSchema : function $createSchema(tbl){
		var PkField = new System.Data.DataSet.Table.Field;
		PkField.id = "bookId"; 
		PkField.type = System.Data.DataSet.Table.FieldType.Number;	
		tbl.fields.add(PkField,PkField.id);
		
		tbl.primaryKey.set(PkField);

		var field = new System.Data.DataSet.Table.Field;
		field.id = "bookName"; 
		field.type = System.Data.DataSet.Table.FieldType.String;	
		tbl.fields.add(field,field.id);
		
		var field = new System.Data.DataSet.Table.Field;
		field.id = "writer"; 
		field.type = System.Data.DataSet.Table.FieldType.String;	
		tbl.fields.add(PkField,PkField.id);
		
		var field = new System.Data.DataSet.Table.Field;
		field.id = "publisher"; 
		field.type = System.Data.DataSet.Table.FieldType.String;	
		tbl.fields.add(PkField,PkField.id);
		
		var field = new System.Data.DataSet.Table.Field;
		field.id = "content"; 
		field.type = System.Data.DataSet.Table.FieldType.String;	
		tbl.fields.add(PkField,PkField.id);
		
		var field = new System.Data.DataSet.Table.Field;
		field.id = "flag"; 
		field.type = System.Data.DataSet.Table.FieldType.Boolean;	
		tbl.fields.add(PkField,PkField.id);
		
	}
}
