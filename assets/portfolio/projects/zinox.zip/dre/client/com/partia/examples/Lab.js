/*!
	include zinox.ui.controls.TextBox;
	include System.Collections.ArrayList;
	include zinox.ui.controls.Form;
	include zinox.ui.controls.Button;
	include zinox.ui.controls.Page;
	include zinox.ui.controls.Label;
	include zinox.ui.controls.TabView;
	include System.XML.Document;
	include com.partia.examples.DesignPage;
	require System.Ui.Control;
*/
com.partia.examples.Lab = function com$partia$zino$componentexplorer$Lab(){
	arguments.callee.superClass.apply(this,arguments);
	/*<init class="com.partia.examples.Lab" 
			version="0.1.1a"
			ns="http://ns.partia.com/zino1/comexp"
			tag="lab"
			author="Shayan Nojedehi" 
			createdate="2007/9/3" />*/
	
	$t.mainClass.add("Partia-Zino1-ComponentExplorer-Lab");
	
	/* Start Design */
	
	$t.mainClass.add("Partia-Zino1-ComponentExplorer-Lab");
	$t.doc = new System.XML.Document;
	$t.node = $t.doc.createNode(1,"zino","http://ns.partia.com/zino");
	$t.controlsType = {};
	$t.controls = new System.Collections.ArrayList;
	$t.controls.onbeforeadd.add(function(ctrl,id){
			if(!$t.controlsType[id]){
				var node=$t.doc.createNode(1,"import","http://ns.partia.com/zino");
				node.setAttribute("ns",ctrl._TYPE);
				$t.node.insertBefore(node,$t.node.firstChild);
				$t.controlsType[id] = true;
			}
			id += $t.controls.length;
			$t.mainform.node.appendChild($t.doc.createNode(1,"text-box","http://ns.partia.com/zino"));
			$t.mainform.node.setAttribute("object","Partia.design")
			$t.ibSource.text.set($t.node.xml);
		return true;
	});
	
	var currentControl = null; 
	$t.currentControl = new System.Property(System.Ui.Control,
		function currentControl$getter(){
			return currentControl;
		},
		function currentControl$setter(value){
			currentControl = value;
		}
	);
	
	var currentForm = null;
	$t.currentForm = new System.Property(System.Ui.Control,
		function currentForm$getter(){
			return currentForm;
		},
		function currentForm$setter(value){
			currentForm = value;
		}
	);
	
	var currentContainer = null;
	$t.currentContainer = new System.Property(System.Ui.Control,
		function currentContainer$getter(){
			return currentContainer;
		},
		function currentContainer$setter(value){
			currentContainer = value;
		}
	);

	
	$t.mainform= new zinox.ui.controls.Form;
	$t.node.appendChild($t.mainform.node = $t.doc.createNode(1,"form","http://ns.partia.com/zino"));
	
	/* End Design */
	
	var tvMain=$t.tvMain = new zinox.ui.controls.TabView;
	tvMain.render($t.element.get());	
	
	
	var pView = new zinox.ui.controls.Page("View");
	
	pView.mainClass.add("page-view")
	var pTestArea = new zinox.ui.controls.Page;
	
	pTestArea.show();

	var pCode = new zinox.ui.controls.Page("Code");
		
	var ibSource = $t.ibSource = new zinox.ui.controls.TextBox;
	ibSource.mainClass.add("textarea");
	
	ibSource.multiline.set(true);
	ibSource.render(pCode.element.get());
	tvMain.pages.add(pCode);
	tvMain.pages.add(pView);
	
	
	$t.btnApply = new zinox.ui.controls.Button("apply");
	$t.btnApply.mainClass.add("applybutton");
	
	$t.btnReset= new zinox.ui.controls.Button("reset");
	$t.btnReset.mainClass.add("applybutton");
	
	$t.btnReset.onclick.add(function(){
		if($t.url.get())
			$t.url.set($t.url.get())
		
	});
	var applyHolder=ce("div");
	var table=ce("table");
	
	table.width="40px"
	$t.element.get().appendChild(applyHolder);
	applyHolder.appendChild(table);
	applyHolder.className="apply-holder";
	var row=table.insertRow(table.rows.length);
	var cell=row.insertCell(row.cells.length);
	$t.btnApply.render(cell);
	var cell=row.insertCell(row.cells.length);
	$t.btnReset.render(cell);
	
	$t.btnApply.onclick.add( function(){
		$t.applyCode();	
	});
	var read;
	
	var url = null;
	$t.url = new System.Property(String,
		function url$$getter(){
			return url;
		},
		
		function code$$setter(value){
			url = value;
			try{
				read = new System.Net.HTTPRequest();	
				read.onLoad=function(){$t.code.set(read.response.XML);}
				read.load(url);
				
			}catch(e){_.mv.fadeHide();}
		}
	);	
	
	
	var code = null;
	$t.code = new System.Property(String,
		function code$$getter(){
			return code;
		},
		
		function code$$setter(value){
			code = value;
			$t.ibSource.text.set(code);
			try{
				var doc = System.XML.Document.parseXML(code);
				pTestArea.content.set(doc);
			}catch(e){
				var doc = System.XML.Document.parseXML('<div xmlns="http://www.w3.org/1999/xhtml">Error:<div>'+(e.message || e)+'</div></div>');
				pTestArea.content.set(doc);
			}
		}
	);
	
	var pSplit = new zinox.ui.controls.Page("Split");
	__a=pSplit;
	var ibSplit = new zinox.ui.controls.TextBox;
	ibSplit.text.set($t.ibSource.text)
	ibSplit.mainClass.add("textarea");
	
	var textareaHolder=ce("div");
	textareaHolder.className="stextareaHolder"
	pSplit.element.get().appendChild(textareaHolder)
	ibSplit.multiline.set(true);
	ibSplit.render(textareaHolder);
	$t.spliterDiv=ce("div");
	textareaHolder.appendChild($t.spliterDiv);
	spliterDivClass = new System.Ui.Styling.ClassManager($t.spliterDiv,"spliterDiv");
	pTestArea.render(pSplit.element.get());
	pTestArea.mainClass.add("page-view");
	tvMain.pages.add(pSplit);
	

	
	tvMain.tabButtons[0].onclick.add(function(){
		textareaHolder.style.display=""
		tvMain.tabButtons[1].tHolderClass.remove(tvMain.tabButtons[1].selectedClass);
		tvMain.tabButtons[1].tHolderClass.add('normal');
		
	}
	);
	
	
	tvMain.tabButtons[2].onclick.add(function(){
		textareaHolder.style.display=""
		tvMain.tabButtons[1].tHolderClass.remove(tvMain.tabButtons[1].selectedClass);
		tvMain.tabButtons[1].tHolderClass.add('normal');
		tvMain.tabButtons[2].tHolderClass.add(tvMain.tabButtons[2].selectedClass);
		
	}
	);
	var pViewClick=function() {
		tvMain.current.set(tvMain.pages.item[2]);
		textareaHolder.style.display="none"
		tvMain.tabButtons[2].tHolderClass.remove(tvMain.tabButtons[2].selectedClass);
		tvMain.tabButtons[2].tHolderClass.add('normal');
		tvMain.tabButtons[1].tHolderClass.add(tvMain.tabButtons[1].selectedClass);
		tvMain.tabButtons[1].tHolderClass.remove('normal');
		
	}
	tvMain.tabButtons[1].onclick.add(pViewClick); 
	$t.tvMain.current.set($t.tvMain.pages[1]);
	pViewClick()
}.inherit(System.Ui.Control);


com.partia.examples.Lab.prototype.applyCode = function com$partia$zino$componentexplorer$Lab$applyCode(){
	var $t = this;
	$t.btnApply.text.set("LOADING...");
	$t.code.set($t.ibSource.text.get());
	$t.btnApply.text.set("apply");
}

com.partia.examples.Lab.prototype.initX = function com$partia$zino$componentexplorer$Lab$initX(node){
	var $t = this;
	System.Ui.Control.prototype.initX.apply(this, arguments);
	
	if(node.firstChild){
		$t.ibSource.text.set( node.firstChild.xml );
		$t.applyCode();		
	}
	
}
	
