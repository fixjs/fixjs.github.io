
var frm = Partia.Zino1.Library;
var pageSet = frm.LibTabView.controls[0].controls[0];
var listPage = pageSet.controls[0];
var detailsPage = pageSet.controls[1];
var onItemCommand = function(command){ alert(command)
	
}
//frm.LibTabView.tabButtons[___ff.pages[0].id].onclickclassic.add

_.bindDataForm = function(){

var list = listPage.controls[0];
pageSet.current.set(detailsPage);
var dataform = detailsPage.controls[0];
var currentValue = list.selectedItem.get();
dataform.currentItem.set(currentValue);
dataform.dataBind();
___ff =list;
}
_.back = function()
{
	pageSet.current.set(listPage);
}

_.search = function(){
	
}
alert("***")
_.showSearch = function(){alert("sss " + this)
	if ( !this.showUrl )
	{
		this.url.set("LibrarySearch.zino");
		this.showUrl =true;
	}
}

var load = function(){
	var list = listPage.controls[0];
	list.totalRecord.set(46);
	var tbl = Partia.Zino1.Library.ds2.tbl2;
	var dataAdapter = Partia.Zino1.Library.da;//("../examples/BookList.xml");
	__yy = dataAdapter.commands[0];
	dataAdapter.action(tbl,dataAdapter.commands[0])
	var list = listPage.controls[0];
	list.dataBind();
	___ff=list;
}

load();
