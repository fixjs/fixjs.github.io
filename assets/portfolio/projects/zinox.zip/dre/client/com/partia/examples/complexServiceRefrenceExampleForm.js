el = function(id){ return document.getElementById(id); }
var refCounter=0;

createRefName = function(url){
	var arr , ref , refName; 
	ref = ((arr = url.split("/"))[arr.length-1].split(".")[0])+"Refrence";
	if(window[ref]) for(var i=1;;i++){ refName=ref+i; if(!window[refName]) break; }
	else refName=ref;
	return refName;
}
addRef = function(isDefault){
	var url;
	if(isDefault){
		var arr = el("selectWsdl").childNodes;				
		for(var i=0;i<arr.length;i++){ 
			if(arr[i].selected){
				addRuntimeRefrense(arr[i].value);
				break;
			} 
		}
	}
	else if(url = el("txtServiceUrl").value){	
		addRuntimeRefrense(url);
	}	
}

addRuntimeRefrense = function(url){
	el("loading-panel").style.display="";					
	var refName = createRefName(url);
	var ns = window[refName] || (window[refName]={}); 
	System.Services.RefrenceGenerator.addNewServiceRefrence(url,ns,function(rp){
		refCounter++;						
		var refLink=null , showref;
		(refLink = document.createElement("div")).innerHTML = refName;
		refLink.style.padding="5px 5px 5px 5px";
		refLink.style.cursor="pointer";		
		if(refCounter>1) refLink.style.borderTop="solid 1px #fff";
		refLink.style.backgroundColor="#E7E7F1";
		refLink.style.color="#376FA6";
		refLink.onmouseover = function(){
			refLink.style.backgroundColor="#DBDBEA";
			refLink.style.color="#16387C";
		}
		refLink.onmouseout = function(){
			refLink.style.backgroundColor="#E7E7F1";
			refLink.style.color="#376FA6";
		}
		showref = function(){			
			var ref = window[el("refName").innerHTML = refName];
			var clName = null;
			for(var x in ref){ 
				if(ref[x].superClass && ref[x].superClass === System.Services.PortType){
					clName=x; 
					break; 
				}
			}
			if(clName){
				el("clientContentTbl").style.display="";
				el("clientName").innerHTML = clName;
				var tbl = getObjectTable(ref[clName].prototype);
				el("clientContent").appendChild(tbl);
			}
			el("refContent").appendChild(getObjectTable(window[refName]) , "610px");
			el("rootsContent").appendChild(getObjectTable(rp) , "610px");
			el("loading-panel").style.display="none";			
		}
		refLink.onclick = function(){
			el("loading-panel").style.display="";
			showref();
		}
		el("refList").appendChild(refLink);
		showref();
		el("refContentTbl").style.display="";
		el("rootContentTbl").style.display="";
		el("refListTbl").style.display="";
		
	});
}		
addServiceRefrence = function(n){
	var RpcServiceUrl = "http://dev101-pc.hq.partia.com/serviceServer/RpcService.asmx?WSDL";
	var testUrl = "http://dev101-pc.hq.partia.com/Soap1.1/wsdl/test.wsdl";
	
	if(!n) $r.addNewServiceRefrence(RpcServiceUrl,"myRef",function(){alert("LoadServiceRefrence Complete!");});				
	else $r.addNewServiceRefrence(testUrl,"myRef2",function(){alert("LoadServiceRefrence2 Complete!");});
}