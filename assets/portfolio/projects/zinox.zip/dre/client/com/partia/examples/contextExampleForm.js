/*!
	require zinox.ui.controls.Form;
	require zinox.util.ContextProvider;
*/
var $ = com.partia.examples.contextExampleForm = new zinox.ui.controls.Form();

$.ContextProviderControl = function(){
	arguments.callee.superClass.apply(this,arguments);
	var $t = this;
	var checkContext = function(){
		//$t.context = $.context;
		if($.context instanceof zinox.ui.controls.TabButton){
			$t.isActive.set(true);
		}else
			$t.isActive.set(false);
		$t.oncontextchange.raise();
	}
	
	$.oncontextchange.add(checkContext);

	checkContext();
}.inherit(zinox.util.ContextProvider);

$.ItemContextProviderControl = function(){
	arguments.callee.superClass.apply(this,arguments);
	var $t = this;
	
	var currentHandle;
	
	var checkCurrent = function(){
		$t.isActive.set($t.context.current.get()?true:false);
		$t.oncontextchange.raise();
	}
	
	var checkContext = function(){
		$t.context = $.context;
		if($.context instanceof zinox.ui.controls.PageSet){
			if(currentHandle) $t.context.current.onchange.remove(currentHandle);			
			 $t.context.current.onchange.add(currentHandle=checkCurrent);			
			$t.isActive.set($.context.current.get()!=null);
		}else{
			$t.isActive.set(false);
		}
			
		$t.oncontextchange.raise();
	}
	
	$.oncontextchange.add(checkContext);
	
	checkContext();
}.inherit(zinox.util.ContextProvider);

/*$.contextProviderControl = function(){
	if($.context instanceof zinox.ui.controls.PageSet){
		return $.context;
	}
}*/

$.onload.add(function(){

	
	$.ac.onmouseup.add(function(){$.currentContext=$.ac});
	$.tv.onmouseup.add(function(){$.currentContext=$.tv}); 
	 
})

$.addCommand=function(){
	this.contextProvider.get().context.pages.add(new zinox.ui.controls.Page(this.value.get())) 
}
$.deleteCommand=function(){
	var context = this.contextProvider.get().context;
	var index = context.pages.indexOf(context.current.get());
	
	context.pages.remove(index);
	context.current.set(context.pages.item[index>=context.pages.length?index-1:index]);
}


$.closableCommand=function(){
	var context = this.contextProvider.get().context;
	this.checked.set(!this.checked.get());
	context.current.get().closable.set(this.checked.get());
	
}


