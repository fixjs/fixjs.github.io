/*!
 	require zinox.ui.controls.ObjectViewer;
 */
com.partia.examples.ObjectViewer = function com$partia$zino$componentexplorer$ObjectViewer(){

}

com.partia.examples.ObjectViewer.prototype = {
	showObject : function $showObject(obj){
		___ff = obj;
		var test = {};
		test.id="id1";
		test.method = function(){return 101;};
		test.arr = [];
		test.ss = "salam";		
		var objViewer = frm.findControl("objViewer");
		//objViewer.ClearObjectViewer();
		objViewer.object.set()
	}
}
