/*!
	require zinox.ui.controls.Form;
	require zinox.util.ContextProvider;
*/
var $ = com.partia.examples.complexDataExampleForm = new zinox.ui.controls.Form();

$.ContextProviderControl = function(){
	arguments.callee.superClass.apply(this,arguments);
	var $t = this;
	
	var checkContext = function(){
		$t.context = $.context;
		if($.context instanceof zinox.ui.controls.DataView){
			$t.isActive.set(true);
		}else
			$t.isActive.set(false);
		$t.oncontextchange();
	}
	
	$.oncontextchange.add( checkContext);

	checkContext();
	
}.inherit(zinox.util.ContextProvider);


$.onload = function(){
}
