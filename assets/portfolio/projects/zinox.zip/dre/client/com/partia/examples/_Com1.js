/*!
	require zinox.ui.controls.Button; 
 */com.partia.examples
com.partia.examples.Com1 = function com$partia$zino$componentexplorer$Com1(){
	arguments.callee.superClass.apply(this,arguments);
	/*<init class="com.partia.examples.Com1" 
			version="0.1.1a"
			ns="http://ns.partia.com/zino1/comexp"
			tag="com1"
			author="Shayan Nojedehi" 
			createdate="2006/6/27" />*/
	
	this.text.set("com1");
	
}.inherit(zinox.ui.controls.Button);
