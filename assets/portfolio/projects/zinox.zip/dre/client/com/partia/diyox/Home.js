com.partia.diyox.Home = function com$partia$diyox$Home(){
    /*<init class="com.partia.diyox.Home"
			version="0.0.1a"
			author="Mehran Hatami"
			modifiedBy="Mehran Hatami"
			createdate="2007/07/16"
			modifieddate="2007/08/08" />*/
    var $t = this;
}.inherit(zino.lang.Object);
com.partia.diyox.Home.prototype = {
    helloWorld : function(){
        wsImport("http://tech-server/SampleService/Service.asmx?WSDL",null,function(){
            var soapMsg = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">';
            soapMsg+= '<soap:Body><HelloWorld xmlns="http://diyox.partia.com/wstest" /></soap:Body></soap:Envelope>';
            var soapDoc = zinox.xml.dom.Document.parseXML(soapMsg);
            var client = new com.partia.diyox.wstest.ServiceSoapClient();
            client.onHelloWorld.add(function(){
                _.dx.dataTable = _resEE.helloWorldResult.get().person.table.get();
                _.body.findControl("wsDataView").dataSource.set(_.dx.dataTable);
            });
            try{
                client.invoke(soapDoc,"HelloWorld");
            }catch(err){
                alertr(err)
            };
        });
    },
    getAllSchema : function(){
        _.ns.prepare("Partia.Dario.FormDesigner.Services.ServiceContract");
        _.ws.ref.zxb.typeFactory("http://tech-server/dario/formdesigner/ws/xsd2.xsd",Partia.Dario.FormDesigner.Services.ServiceContract,function(){
            wsImport("http://tech-server/dario/formdesigner/ws/Service.wsdl",Partia.Dario.FormDesigner.Services.ServiceContract,function(){
                store.rootParams.getAllSchemaData.__type__ = Partia.Dario.FormDesigner.Services.ServiceContract.GetSchemaList;
                Partia.Dario.FormDesigner.Services.ServiceContract.GetSchemaList.prototype.__type__ = Partia.Dario.FormDesigner.Services.ServiceContract.GetSchemaData;
            });
        });
    }
};
_.dx = new com.partia.diyox.Home();

_.dx.getAllSchema();