/*!
	require zinox.ui.controls.Page;
	include System.Collections.ArrayList;
	include zinox.ui.controls.Form;
	include zinox.ui.controls.Button;
	include com.partia.examples.DesignControl;
*/
com.partia.examples.DesignPage = function com$partia$zino$componentexplorer$Lab$DesignPage(){
	arguments.callee.superClass.apply(this,arguments);
	/*<init class="com.partia.examples.DesignPage" 
			version="0.1.1a"
			ns="http://ns.partia.com/zino1/comexp"
			tag="DesignPage"
			author="Arash Soleimani" 
			createdate="2007/9/3" />*/

	
	var content = null;
	$t.content = new System.Property(HTMLElement,
		function content$$getter(){
			return content;
		},
		function content$$setter(value){
			content = $t.getContentinDesign(value);
			if($t.contentRendered && $t.rendered){
				$t.renderContent();
			}
		}
	);
	
}.inherit(zinox.ui.controls.Page);
com.partia.examples.DesignPage.prototype.getContentinDesign = function com$partia$zino$componentexplorer$Lab$getContentinDesign(node){
	var $t = this;
	//node = node.cloneNode(true);
	var dc=$t.parent.doc.createNode(1,"design-control","http://ns.partia.com/zino");
	dc.appendChild(node);
	for( var i = 0; i< node.childNodes.length;i++ )
		node.appendChild($t.getContentinDesign( node.childNodes[i] ));
	
	return dc;
}
com.partia.examples.DesignPage.prototype.initX = function com$partia$zino$componentexplorer$Lab$initX(node){
	zinox.ui.controls.Page.prototype.initX.apply(this, arguments);
	var $t = this;
	 
	
}
	
