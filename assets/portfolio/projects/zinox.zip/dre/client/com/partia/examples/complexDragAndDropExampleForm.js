
myinitForm = function $myinitForm(){
	var mainForm = com.partia.examples.complexDragDropExampleForm;
	var lbl = mainForm.findControl("lbl");
	pnl = mainForm.findControl("panel");
	inpnl = mainForm.findControl("inner-panel");
	pnl2 = mainForm.findControl("panel2");
	pnl3 = mainForm.findControl("panel3");
	pnl4 = mainForm.findControl("panel4");
	pnl5 = mainForm.findControl("panel5");
	pnl6 = mainForm.findControl("panel6");
	pnl7 = mainForm.findControl("panel7");
    
	lbl.onmousedownclassic.add(function(e){ this.doDragDrop(e , pnl , 1) });
	
	pnl2.onmousedownclassic.add(function(e){ this.doDragDrop(e , pnl2 , 4 , 1) });
	
	var left = com.partia.examples.complexDragDropExampleForm.findControl("lefttxt");
	var top = com.partia.examples.complexDragDropExampleForm.findControl("toptxt");
	
	dEnter = function(ctrl){ var el = ctrl.element.get(); el.style.borderStyle = "solid"; el.style.borderWidth = "2px"; el.style.borderColor = "#000"; var top = parseInt(el.style.top); el.style.top = px(top-2); }
	dLeave = function(ctrl){ var el = ctrl.element.get(); el.style.borderStyle = "none"; el.style.borderWidth = "0px"; var top = parseInt(el.style.top); el.style.top = px(top+2); }
	
	inpnl.ondragenter.add(function(){ dEnter(inpnl); });
	pnl2.ondragenter.add(function(){ dEnter(pnl2); });
	pnl3.ondragenter.add(function(){ dEnter(pnl3); });
	pnl4.ondragenter.add(function(){ dEnter(pnl4); });
	pnl5.ondragenter.add(function(){ dEnter(pnl5); });
	pnl6.ondragenter.add(function(){ dEnter(pnl6); });
	pnl7.ondragenter.add(function(){ dEnter(pnl7); });

	inpnl.ondragleave.add(function(){ dLeave(inpnl); });
	pnl2.ondragleave.add(function(){ dLeave(pnl2); });
	pnl3.ondragleave.add(function(){ dLeave(pnl3); });
	pnl4.ondragleave.add(function(){ dLeave(pnl4); });
	pnl5.ondragleave.add(function(){ dLeave(pnl5); });
	pnl6.ondragleave.add(function(){ dLeave(pnl6); });
	pnl7.ondragleave.add(function(){ dLeave(pnl7); });
	
	pnl5.ondragdrop.add(function(data){
		if(data instanceof zinox.ui.Control){
			if(pnl5.controls.indexOf( data )==-1){
				pnl5.controls.add(data);
				var el = data.element.get();
				var rect = getRectangle(pnl5.element.get());
				
				el.style.left = px(parseInt(el.style.left)-rect.left);
				el.style.top = px(parseInt(el.style.top)-rect.top);
			}
        }
	});
	pnl7.ondragdrop.add(function(data){
		if(data instanceof zinox.ui.Control){
            pnl7.element.get().appendChild(ct(data.id));
        }
	});
	inpnl.ondragdrop.add(function(data){
		if(inpnl.controls.indexOf( data )==-1){
			inpnl.controls.add(data);
			var el = data.element.get();
			var rect = getRectangle(inpnl.element.get());
			
			el.style.left = px(parseInt(el.style.left)-rect.left);
			el.style.top = px(parseInt(el.style.top)-rect.top);
		}
	});
}